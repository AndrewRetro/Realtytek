import React from 'react';
import {View, StyleSheet, Text} from 'react-native';
import moment from 'moment';

import {ShadowHeader} from '../../components';
import {
  FlatListHandler,
  ButtonView,
  ImageHandlerUpdated,
} from '../../reuseableComponents';
import {pop} from '../../services/NavigationService';
import {AppStyles, Colors, Metrics} from '../../theme';
import {onNotificationOpened} from '../../reuseableFunctions';

import apis from '@apis';
import {request} from '@serviceAction';

import {NOTIFICATIONS} from '@actionTypes';
import {useDispatch, useSelector} from 'react-redux';
import {handleBadgeCount} from '../../reuseableFunctions';

export default function () {
  const dispatch = useDispatch();

  const notifications = useSelector(({notifications}) => notifications);

  React.useEffect(() => {
    fetchNotifications();
    handleBadgeCount({badge_count: 0});
  }, []);

  const fetchNotifications = (isConcat = false, page = 1) =>
    dispatch(
      request(
        apis.notification,
        apis.serviceTypes.GET,
        {page, limit: 10},
        NOTIFICATIONS,
        false,
        isConcat,
        null,
        null,
      ),
    );

  const onNotification =
    ({identifier, reference_slug, custom_data}) =>
    () =>
      onNotificationOpened({
        additionalData: {
          custom_data: {
            identifier,
            data: {
              slug: reference_slug,
              id: custom_data.data.id,
            },
          },
        },
      });

  const NotificationItem = ({data}) => {
    const {title, description, actor_image_url: uri, created_at} = data;
    return (
      <ButtonView style={styles.containerItem} onPress={onNotification(data)}>
        <ImageHandlerUpdated
          source={{
            uri,
          }}
          style={styles.imgProfile}
        />
        <View style={styles.containerDesc}>
          <Text style={styles.txtTitle}>{title}</Text>
          <Text style={styles.txtDesc}>{description}</Text>
        </View>
        <Text style={styles.txtCreatedAt}>
          {moment.utc(created_at).fromNow()}
        </Text>
      </ButtonView>
    );
  };

  const renderNotification = ({item}) => <NotificationItem data={item} />;

  return (
    <View style={styles.container}>
      <ShadowHeader onBack={pop} useShadows title="Notification" />
      <FlatListHandler
        fetchRequest={fetchNotifications}
        data={notifications.data}
        isFetching={notifications.isFetching}
        meta={notifications.meta}
        renderItem={renderNotification}
        contentContainerStyle={{marginTop: Metrics.baseMargin}}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.primary.palegrey,
  },
  containerItem: {
    flexDirection: 'row',
    padding: Metrics.baseMargin,
    marginBottom: Metrics.baseMargin,
    marginHorizontal: Metrics.baseMargin,
    backgroundColor: Colors.primary.white,
    borderRadius: Metrics.smallMargin,
    ...AppStyles.lightShadow,
  },
  imgProfile: {
    width: Metrics.widthRatio(50),
    height: Metrics.widthRatio(50),
    borderRadius: Metrics.widthRatio(25),
  },
  containerDesc: {flex: 1, marginHorizontal: Metrics.baseMargin},
  containerSearch: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.primary.white,
    padding: Metrics.smallMargin * 1.5,
    margin: Metrics.baseMargin,
    marginTop: Metrics.smallMargin,
    ...AppStyles.heavyShadow,
    borderRadius: Metrics.widthRatio(4),
  },
  txtSearch: {
    flex: 1,
    ...AppStyles.gbRe(14, Colors.primary.darkslateblue),
    marginLeft: Metrics.baseMargin,
  },
  txtTitle: AppStyles.gbRe(15, Colors.primary.darkslateblue),
  txtDesc: {
    ...AppStyles.gbRe(13, Colors.primary.blueyGrey),
    marginTop: Metrics.widthRatio(4),
  },
  txtCreatedAt: AppStyles.gbRe(12, Colors.primary.darkslateblue),
});
