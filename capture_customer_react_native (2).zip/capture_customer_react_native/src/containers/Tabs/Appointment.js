import React from 'react';
import {View, StyleSheet} from 'react-native';
import ScrollableTabView from 'react-native-scrollable-tab-view';

import Pending from '@containers/Appointments/Pending';
import Confirmed from '@containers/Appointments/Confirmed';
import Rejected from '@containers/Appointments/Rejected';
import {BackHeader} from '@components';
import {CustomTabBar} from '@reuseableComponents';

export default function () {
  return (
    <View style={styles.container}>
      <BackHeader useDrawer title="Appointments" />
      <ScrollableTabView renderTabBar={props => <CustomTabBar {...props} />}>
        <Pending tabLabel="Pending" />
        <Confirmed tabLabel="Confirmed" />
        <Rejected tabLabel="Rejected" />
      </ScrollableTabView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
