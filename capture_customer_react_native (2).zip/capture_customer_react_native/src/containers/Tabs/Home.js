import React, {useEffect} from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import {EventBusSingleton} from 'light-event-bus';
import _ from 'lodash';

import {ButtonView} from '../../reuseableComponents';
import {handleBadgeCount} from '../../reuseableFunctions';

import {Colors, Fonts, Metrics} from '../../theme';
import {navigate} from '../../services/NavigationService';
import {AgentCard, BackHeader} from '../../components';
import {RandomRecommendedHomes} from '@containers';
import MyListings from '../MyListings';
import {request} from '@serviceAction';
import apis from '@apis';
import {useDispatch, useSelector} from 'react-redux';
import {USER} from '@actionTypes';

export default () => {
  const dispatch = useDispatch();
  const user = useSelector(({user}) => user.data);
  useEffect(() => {
    fetchUser();
    setTimeout(fetchBadgeCount, 5000);
  }, []);

  const fetchUser = () => {
    dispatch(
      request(
        `${apis.updateUser}/${user.slug}`,
        apis.serviceTypes.GET,
        {},
        USER,
        false,
        false,
      ),
    );
  };

  const fetchBadgeCount = () => {
    dispatch(
      request(
        apis.fetchBadgeCount,
        apis.serviceTypes.GET,
        {},
        null,
        false,
        false,
        ({notification_count}) =>
          handleBadgeCount({badge_count: notification_count}),
      ),
    );
  };

  const Agents = () => {
    return (
      <View>
        <Text style={styles.txtAgentTitle}>Agent</Text>
        <AgentCard />
      </View>
    );
  };

  const onViewAllListing = () => {
    navigate('Selling');
    setTimeout(() => EventBusSingleton.publish('showListingTab', true), 500);
  };

  const Listings = () => {
    return (
      <View
        style={{
          paddingBottom: Metrics.smallMargin,
          marginTop: Metrics.widthRatio(14),
        }}>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
          <Text style={styles.txtAgentTitle}>Listings</Text>
          <ButtonView onPress={onViewAllListing}>
            <Text style={styles.showMoreTxt}>View All</Text>
          </ButtonView>
        </View>
        <MyListings isHorizontal />
      </View>
    );
  };

  const onRecommendedHomes = () => {
    navigate('RandomRecommendedHomes');
  };

  return (
    <View style={styles.container}>
      <BackHeader
        useDrawer
        title="Home"
        onNotification={() => navigate('Notification')}
        useNotification
      />
      <ScrollView
        bounces={false}
        alwaysBounceVertical={false}
        showsVerticalScrollIndicator={false}
        nestedScrollEnabled={true}
        contentContainerStyle={styles.content}>
        <Agents />

        <View style={styles.listHeaderWrapper}>
          <Text style={styles.heading}>Recommended Homes</Text>
          <ButtonView onPress={onRecommendedHomes} style={styles.showMoreBtn}>
            <Text style={styles.showMoreTxt}>View all</Text>
          </ButtonView>
        </View>
        <RandomRecommendedHomes isHorizontal />

        <Listings />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginLeft: Metrics.baseMargin,
  },
  listHeaderWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  heading: {
    ...Fonts.font({
      type: Fonts.Type.SemiBold,
      size: 16,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: Metrics.widthRatio(12),
    marginBottom: Metrics.smallMargin,
  },
  showMoreTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.vermillion,
    }),
    marginRight: Metrics.smallMargin,
  },
  showMoreBtn: {
    padding: Metrics.baseMargin,
    paddingRight: 0,
  },
  listCardStyle: {
    marginTop: 0,
    marginLeft: 0,
    width: Metrics.screenWidth * 0.8,
  },
  txtAgentTitle: {
    flex: 1,
    ...Fonts.font({
      type: Fonts.Type.SemiBold,
      size: 16,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: Metrics.smallMargin,
    marginBottom: Metrics.widthRatio(12),
  },
});
