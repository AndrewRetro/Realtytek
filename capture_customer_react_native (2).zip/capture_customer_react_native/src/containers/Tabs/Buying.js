import React, {useState, useRef} from 'react';
import {View, StyleSheet} from 'react-native';
import ScrollableTabView from 'react-native-scrollable-tab-view';

import BuyingQueries from '../BuyingQueries';
import UnderContractQueries from '../UnderContractQueries';
import {BackHeader, BigCard, SmallBtn} from '../../components';
import {CustomTabBar, FlatListHandler} from '../../reuseableComponents';

import {navigate} from '../../services/NavigationService';
import {Colors, Metrics} from '../../theme';

export default function () {
  const scrollableTabView = useRef();

  return (
    <View style={{flex: 1}}>
      <BackHeader
        useDrawer
        rightBtn={() => navigate('AddBuyingQuery')}
        title="Buying"
      />
      <ScrollableTabView
        ref={scrollableTabView}
        renderTabBar={props => <CustomTabBar {...props} />}>
        <BuyingQueries tabLabel="Buying Queries" />
        <UnderContractQueries tabLabel="Under Contract" />
      </ScrollableTabView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  btn: {
    width:
      (Metrics.screenWidth - 2 * Metrics.baseMargin - Metrics.smallMargin) / 2,
  },
  btnContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Metrics.doubleBaseMargin,
    marginHorizontal: Metrics.baseMargin,
    marginBottom: Metrics.doubleBaseMargin,
  },
});
