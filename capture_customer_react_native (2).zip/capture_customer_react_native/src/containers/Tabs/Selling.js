import React, {useRef} from 'react';
import {View, StyleSheet} from 'react-native';
import {EventBusSingleton} from 'light-event-bus';
import ScrollableTabView from 'react-native-scrollable-tab-view';

import {BackHeader} from '../../components';
import {CustomTabBar} from '../../reuseableComponents';
import {navigate} from '../../services/NavigationService';
import MyListings from '../MyListings';
import SellingUnderContractList from '../SellingUnderContractList';

export default function ({route}) {
  const scrollableTabView = useRef();

  React.useEffect(() => {
    const subscription = EventBusSingleton.subscribe('showListingTab', arg => {
      scrollableTabView.current.goToPage(0);
    });
    () => subscription.unsubscribe();
  }, []);

  return (
    <View style={styles.container}>
      <BackHeader
        useDrawer
        rightBtn={() =>
          navigate('SellingStack', {
            screen: 'SellingQuery',
          })
        }
        title="Selling"
      />
      <ScrollableTabView
        ref={scrollableTabView}
        renderTabBar={props => <CustomTabBar {...props} />}>
        <MyListings tabLabel="My Listings" />
        <SellingUnderContractList tabLabel="Under Contract" />
      </ScrollableTabView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
