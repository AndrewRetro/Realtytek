import React from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';

import {BackHeader} from '../../components';
import {
  ImageHandler,
  ButtonView,
  ImageHandlerUpdated,
} from '../../reuseableComponents';

import {AppStyles, Colors, Fonts, Images, Metrics} from '../../theme';
import {navigate} from '../../services/NavigationService';
import {useSelector} from 'react-redux';
import utility from '@utils';

export default function () {
  const user = useSelector(({user}) => user.data);
  const {agent} = user;
  const {
    name,
    mobile_no,
    email,
    license_number,
    licence_state,
    image_url,
    website,
    about_us,
    logo_url,
    company_name,
  } = agent;

  const onPreApproved = () =>
    navigate('BrokerStack', {
      screen: 'BrokerDisclosure',
      params: {isFromDrawer: false},
    });

  const onCalender = () => navigate('Calendar', {isFromDrawer: false});

  const License = () => (
    <View style={styles.headerWrapper}>
      {!!license_number && (
        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt}>License Number</Text>
          <Text style={styles.tileDesc}>{license_number}</Text>
        </View>
      )}
      {!!licence_state && (
        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt}>License Issued in (State)</Text>
          <Text style={styles.tileDesc}>{licence_state}</Text>
        </View>
      )}
    </View>
  );

  const Website = () => (
    <View>
      {!!website && (
        <ButtonView onPress={() => utility.openLink(website)}>
          <Text style={styles.tileTxt}>Website</Text>
          <Text style={{...styles.tileDesc, color: Colors.primary.clearblue}}>
            {website}
          </Text>
        </ButtonView>
      )}
    </View>
  );

  const About = () =>
    !!about_us && (
      <View>
        <Text style={styles.tileTxt}>About Us</Text>
        <Text style={styles.tileDesc}>{about_us}</Text>
      </View>
    );

  return (
    <View style={styles.container}>
      <BackHeader title="Broker" useDrawer />
      <ScrollView
        alwaysBounceVertical={false}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}>
        <View style={styles.headerWrapper}>
          <View style={styles.wrapperProfileImg}>
            <ImageHandlerUpdated
              source={{uri: image_url}}
              style={AppStyles.roundImg(105)}
              isProfileImage
              isZoomViewerEnabled
            />
          </View>
          <View style={styles.wrapperLogo}>
            <ImageHandlerUpdated
              source={{uri: logo_url}}
              style={styles.wrapperLogo}
              isZoomViewerEnabled
            />
          </View>
        </View>

        <Text style={styles.tileTxt}>Name</Text>
        <Text style={styles.tileDesc}>{name}</Text>

        {!!company_name && (
          <View>
            <Text style={styles.tileTxt}>Comapny name</Text>
            <Text style={styles.tileDesc}>{company_name}</Text>
          </View>
        )}

        <View style={styles.tileWrapper}>
          <ImageHandler style={styles.img} source={Images.icPhoneTile} />
          <Text style={styles.desc}>{mobile_no}</Text>
        </View>
        <View style={styles.tileWrapper}>
          <ImageHandler style={styles.img} source={Images.icEmailTile} />
          <Text style={styles.desc}>{email}</Text>
        </View>
        <ButtonView style={styles.tileWrapper} onPress={onCalender}>
          <ImageHandler style={styles.img} source={Images.icCalenderTile} />
          <Text style={styles.desc}>View Calendar</Text>
        </ButtonView>
        <ButtonView style={styles.tileWrapper} onPress={onPreApproved}>
          <ImageHandler style={styles.img} source={Images.icSellingTile} />
          <Text style={styles.desc}>Pre Approved</Text>
        </ButtonView>
        <License />
        <Text style={styles.headingTwo}>ABC Realtor</Text>
        <Text style={[styles.tileDesc, {fontStyle: 'italic'}]}>
          Where you can find your perfect home
        </Text>
        <Website />
        <About />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
  },
  headerWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  heading: {
    ...Fonts.font({
      size: 18,
      color: Colors.primary.darkTwo,
    }),
    marginTop: Metrics.baseMargin,
  },
  img: {
    height: Metrics.heightRatio(36),
    width: Metrics.heightRatio(36),
  },
  desc: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginLeft: Metrics.smallMargin,
  },
  tileWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: Metrics.baseMargin,
  },
  tileTxt: {
    ...Fonts.font({
      size: 12,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: Metrics.doubleBaseMargin,
  },
  tileDesc: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginTop: 8,
  },
  headingTwo: {
    ...Fonts.font({
      type: Fonts.Type.SemiBold,
      size: 18,
      color: Colors.primary.darkTwo,
    }),
    marginTop: Metrics.doubleBaseMargin,
  },
  wrapperProfileImg: {
    ...AppStyles.roundImg(105),
    backgroundColor: 'white',
    ...AppStyles.darkShadow,
  },
  wrapperLogo: {
    width: Metrics.widthRatio(105),
    height: Metrics.widthRatio(105),
    borderRadius: Metrics.baseMargin,
    ...AppStyles.darkShadow,
  },
});
