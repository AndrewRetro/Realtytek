import React, {useState} from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';

import {
  AbsoluteHeader,
  SmallBtn,
  ContractInfo,
  LendersInfo,
  PropertyDetailsContract,
} from '@components';
import {Colors, Images, Metrics, Fonts, AppStyles} from '../../theme';
import {ImageHandler, ImageHandlerUpdated} from '@reuseableComponents';
import {useSelector} from 'react-redux';
import utility from '@utils';

const dummyData = [
  {
    heading: 'Property Detail',
    tab: 'Details',
  },
  {
    heading: 'Listing Contract Details',
    tab: 'Contract Status',
  },
  {
    heading: 'Listing Contract Details',
    tab: 'Lenders Info',
  },
];

export default function ({route}) {
  const user = useSelector(({user}) => user.data);
  const {agent} = user;

  const [state, setState] = useState({
    activeTab: 0,
    data: route.params?.data,
  });

  const Profile = () => {
    return (
      <View style={styles.personalDetails}>
        <View style={styles.wrapperRow}>
          <View style={styles.wrapperProfile}>
            <ImageHandlerUpdated
              source={{uri: agent.image_url}}
              style={styles.imgProfile}
            />
          </View>
          <View style={styles.personalDetailsWrapper}>
            <Text style={styles.nameTxt}>{agent.name}</Text>
            {!!agent.address && (
              <View style={styles.wrapperAddress}>
                <ImageHandler
                  style={{tintColor: Colors.primary.white}}
                  source={Images.iclocation1}
                />
                <Text style={styles.txtAddress}>{agent.address}</Text>
              </View>
            )}
          </View>
        </View>
        <View style={styles.wrapperContractStatus}>
          <View>
            <Text style={styles.txtStatusTitle}>Contract Status</Text>
            <Text style={styles.txtStatus}>Active</Text>
          </View>
          <View style={{flexDirection: 'row'}}>
            <SmallBtn
              title="Call"
              tintColor={Colors.primary.clearblue}
              txtColor={Colors.primary.clearblue}
              bgColor={Colors.primary.white}
              icon={Images.icPhone}
              onPress={utility.call(agent.mobile_no)}
            />
            <SmallBtn
              title="Chat"
              style={{marginLeft: Metrics.smallMargin}}
              tintColor={Colors.primary.clearblue}
              txtColor={Colors.primary.clearblue}
              bgColor={Colors.primary.white}
              icon={Images.icChat}
              onPress={utility.chat(agent.mobile_no)}
            />
            <SmallBtn
              style={{marginLeft: Metrics.smallMargin}}
              bgColor={Colors.primary.darkslateblue}
              icon={Images.icEmail}
              title="Email"
              onPress={utility.email(agent.email)}
            />
          </View>
        </View>
      </View>
    );
  };

  const {activeTab} = state;
  return (
    <ScrollView bounces={0} showsVerticalScrollIndicator={false}>
      <ImageHandlerUpdated
        style={styles.cover}
        source={
          state.data?.image_url ? {uri: state.data.image_url} : Images.icPlace
        }
      />
      <AbsoluteHeader title="Property Details" showRight={false} />

      <Profile />

      <View style={styles.content}>
        <View style={styles.btnContainer}>
          {dummyData.map((ele, index) => (
            <SmallBtn
              key={ele.tab}
              useBold
              useRegularTxt
              style={styles.btn}
              title={ele.tab}
              txtSize={14}
              txtColor={
                activeTab === index
                  ? Colors.primary.white
                  : `${Colors.primary.slate}`
              }
              bgColor={
                activeTab === index
                  ? Colors.primary.clearblue
                  : Colors.primary.white
              }
              onPress={() =>
                setState(prevState => ({...prevState, activeTab: index}))
              }
              disabled={index == 0 ? false : true}
            />
          ))}
        </View>
        {activeTab === 0 ? (
          <PropertyDetailsContract data={state.data} />
        ) : activeTab === 1 ? (
          <ContractInfo property={state.data} />
        ) : (
          <LendersInfo property={state.data} />
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  cover: {
    width: Metrics.screenWidth,
    height: Metrics.heightRatio(308),
  },
  personalDetails: {
    paddingVertical: Metrics.smallMargin,
    paddingHorizontal: Metrics.baseMargin,
    backgroundColor: Colors.primary.clearblue,
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
    marginTop: Metrics.baseMargin,
    marginBottom: Metrics.xDoubleBaseMargin,
  },
  nameTxt: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.white,
    }),
  },
  personalDetailsWrapper: {
    marginLeft: Metrics.baseMargin,
    flex: 1,
  },
  tileHeader: {
    ...Fonts.font({
      size: 12,
      color: Colors.primary.white,
    }),
    opacity: 0.5,
  },
  tileDesc: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.white,
    }),
    marginTop: Metrics.heightRatio(9),
  },

  btnContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionBtn: {
    marginVertical: Metrics.xDoubleBaseMargin,
    width: (Metrics.screenWidth - Metrics.xDoubleBaseMargin) / 2,
  },
  btn: {
    height: 38,
    borderRadius: 4,
    alignItems: 'center',
    justifyContent: 'center',
    width:
      Metrics.screenWidth / 3 -
      (2 * Metrics.baseMargin + 2 * Metrics.smallMargin) / 3,
  },
  wrapperProfile: {
    width: Metrics.widthRatio(80),
    height: Metrics.widthRatio(80),
    borderRadius: Metrics.widthRatio(4),
    backgroundColor: 'white',
    ...AppStyles.heavyShadow,
  },
  imgProfile: {
    width: Metrics.widthRatio(80),
    height: Metrics.widthRatio(80),
    borderRadius: Metrics.widthRatio(4),
  },
  wrapperRow: {flexDirection: 'row', flex: 1},
  wrapperAddress: {
    flexDirection: 'row',
    marginTop: Metrics.smallMargin,
    alignItems: 'center',
  },
  txtAddress: {
    ...Fonts.font({
      size: 12,
      color: Colors.primary.white,
    }),
    marginLeft: Metrics.smallMargin,
  },
  wrapperContractStatus: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Metrics.smallMargin,
    alignItems: 'center',
  },
  txtStatusTitle: {
    ...Fonts.font({
      size: 13,
      color: Colors.primary.white,
    }),
  },
  txtStatus: {
    ...Fonts.font({
      size: 15,
      color: Colors.primary.white,
    }),
    marginTop: 6,
  },
});
