import React, {useState} from 'react';
import {View, Text, StyleSheet, ScrollView, Image} from 'react-native';

import {
  AbsoluteHeader,
  SmallBtn,
  ContractInfo,
  ContractStatus,
  LendersInfo,
  BuyingDetails,
} from '../../components';
import {Colors, Images, Metrics, Fonts} from '../../theme';
import {ImageHandlerUpdated, Rating} from '../../reuseableComponents';

import {useSelector} from 'react-redux';
import utility from '@utils';

export default function ({route}) {
  const {
    buyingQuery,
    isFromUnderContract = false,
    isFromBuyingUnderContract = false,
  } = route.params;

  const dummyData = [
    {
      heading: 'Property Detail',
      tab: 'Details',
    },
    {
      heading: 'Listing Contract Details',
      tab: isFromUnderContract ? 'Contract Info' : 'Contract Status',
    },
    {
      heading: 'Listing Contract Details',
      tab: isFromUnderContract ? 'Contract Status' : 'Lenders Info',
    },
  ];

  const [state, setState] = useState({
    activeTab: 0,
  });
  const {activeTab} = state;

  const {property} = buyingQuery.initiate_buyer_property;
  const {agent} = useSelector(({user}) => user.data);
  const {name, image_url, address, email, mobile_no} = agent;

  return (
    <ScrollView bounces={0} showsVerticalScrollIndicator={false}>
      <Image style={styles.cover} source={Images.icPlace} />
      <AbsoluteHeader title="Contract Details" showRight={false} />
      <View style={styles.personalDetails}>
        <View style={{flexDirection: 'row', flex: 1}}>
          <ImageHandlerUpdated
            source={{uri: image_url}}
            style={{
              width: Metrics.widthRatio(75),
              height: Metrics.widthRatio(80),
              borderRadius: Metrics.widthRatio(4),
            }}
          />
          <View style={styles.personalDetailsWrapper}>
            <Text style={styles.nameTxt}>{name}</Text>
            <View
              style={{
                flexDirection: 'row',
                marginTop: Metrics.smallMargin,
                alignItems: 'center',
              }}>
              <Image
                style={{tintColor: Colors.primary.white}}
                source={Images.iclocation1}
              />
              <Text
                style={{
                  ...Fonts.font({
                    size: 12,
                    color: Colors.primary.white,
                  }),
                  marginLeft: Metrics.smallMargin,
                }}>
                {address}
              </Text>
            </View>
          </View>
        </View>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            marginTop: Metrics.smallMargin,
            alignItems: 'center',
          }}>
          <View>
            <Text
              style={{
                ...Fonts.font({
                  size: 13,
                  color: Colors.primary.white,
                }),
              }}>
              Contract Status
            </Text>
            <Text
              style={{
                ...Fonts.font({
                  size: 15,
                  color: Colors.primary.white,
                }),
                marginTop: 6,
              }}>
              Active
            </Text>
          </View>
          <View style={{flexDirection: 'row'}}>
            <SmallBtn
              title="Call"
              tintColor={Colors.primary.clearblue}
              txtColor={Colors.primary.clearblue}
              bgColor={Colors.primary.white}
              icon={Images.icPhone}
              onPress={utility.call(mobile_no)}
            />
            <SmallBtn
              title="Chat"
              style={{marginLeft: Metrics.smallMargin}}
              tintColor={Colors.primary.clearblue}
              txtColor={Colors.primary.clearblue}
              bgColor={Colors.primary.white}
              icon={Images.icChat}
              onPress={utility.chat(mobile_no)}
            />
            <SmallBtn
              style={{marginLeft: Metrics.smallMargin}}
              bgColor={Colors.primary.darkslateblue}
              icon={Images.icEmail}
              title="Email"
              onPress={utility.email(email)}
            />
          </View>
        </View>
      </View>

      <View style={styles.content}>
        <View style={styles.btnContainer}>
          {dummyData.map((ele, index) => (
            <SmallBtn
              key={ele.tab}
              useBold
              useRegularTxt
              style={styles.btn}
              title={ele.tab}
              txtSize={14}
              txtColor={
                activeTab === index
                  ? Colors.primary.white
                  : `${Colors.primary.slate}`
              }
              bgColor={
                activeTab === index
                  ? Colors.primary.clearblue
                  : Colors.primary.white
              }
              onPress={() =>
                setState(prevState => ({...prevState, activeTab: index}))
              }
            />
          ))}
        </View>
        {activeTab === 0 ? (
          isFromBuyingUnderContract ? (
            <BuyingDetails property={property} />
          ) : (
            <>
              <Text style={styles.tileTxt2}>Address</Text>
              <Text style={styles.tileDesc2}>
                235 Elm Street, Los Angeles, CA
              </Text>

              <Text style={styles.tileTxt2}>Asking Price</Text>
              <Text style={styles.tileDesc2}>$375,000</Text>

              <Text style={styles.tileTxt2}>MLS Details</Text>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginTop: 8,
                }}>
                <Image source={Images.icLink} />
                <Text style={styles.linkTxt}>
                  http://235 Elm Street, Los Angeles, CA
                </Text>
              </View>

              <Text style={styles.tileTxt2}>Sell by Date</Text>
              <Text style={styles.tileDesc2}>12/08/2020</Text>

              <Text style={styles.tileTxt2}>Listing/CMA appointment</Text>
              <Text style={styles.tileDesc2}>Yes</Text>
            </>
          )
        ) : activeTab === 1 ? (
          isFromBuyingUnderContract ? (
            <ContractStatus property={property} />
          ) : (
            <ContractInfo />
          )
        ) : isFromBuyingUnderContract ? (
          <LendersInfo property={property} />
        ) : (
          <ContractStatus />
        )}
      </View>
    </ScrollView>
  );
}

const Tag = ({t1, d1, t2, d2, rating}) => (
  <View style={{flexDirection: 'row'}}>
    <View style={{flex: 0.5}}>
      <Text style={styles.tileTxt2}>{t1}</Text>
      <Text style={styles.tileDesc2}>{d1}</Text>
    </View>

    <View style={{flex: 0.5}}>
      <Text style={styles.tileTxt2}>{t2}</Text>
      {!!d2 && <Text style={styles.tileDesc2}>{d2}</Text>}
      {rating !== 'null' && rating !== undefined && (
        <Rating useBig style={styles.tileDesc2} rating={rating} />
      )}
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  cover: {
    width: Metrics.screenWidth,
    height: Metrics.heightRatio(308),
  },
  personalDetails: {
    paddingVertical: Metrics.smallMargin,
    paddingHorizontal: Metrics.baseMargin,
    backgroundColor: Colors.primary.clearblue,
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
    marginTop: Metrics.baseMargin,
    marginBottom: Metrics.xDoubleBaseMargin,
  },
  nameTxt: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.white,
    }),
  },
  personalDetailsWrapper: {
    marginLeft: Metrics.baseMargin,
    flex: 1,
  },
  tileHeader: {
    ...Fonts.font({
      size: 12,
      color: Colors.primary.white,
    }),
    opacity: 0.5,
  },
  tileDesc: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.white,
    }),
    marginTop: Metrics.heightRatio(9),
  },
  tileTxt2: {
    ...Fonts.font({
      size: 12,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: Metrics.doubleBaseMargin,
  },
  tileDesc2: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginTop: 8,
  },
  linkTxt: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.Italic,
      color: Colors.primary.clearblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
  btnContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionBtn: {
    marginVertical: Metrics.xDoubleBaseMargin,
    width: (Metrics.screenWidth - Metrics.xDoubleBaseMargin) / 2,
  },
  btn: {
    height: 38,
    borderRadius: 4,
    alignItems: 'center',
    justifyContent: 'center',
    width:
      Metrics.screenWidth / 3 -
      (2 * Metrics.baseMargin + 2 * Metrics.smallMargin) / 3,
  },
});
