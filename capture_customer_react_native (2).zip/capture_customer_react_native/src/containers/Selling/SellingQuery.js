import React from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import moment from 'moment';
import {ActionSheetCustom as ActionSheet} from 'react-native-actionsheet';

import {ShadowHeader, SmallBtn} from '../../components';
import {
  ButtonView,
  FormHandlerUpdated,
  MaterialTextField,
  ImageHandlerUpdated,
  BottomActionSheet,
} from '@reuseableComponents';
import {INPUT_TYPES} from '../../reuseableComponents/FormHandler/Constants';
import {pop} from '@services/NavigationService';
import {Colors, AppStyles, Fonts, Images, Metrics} from '@theme';
import {useRef} from 'react';
import {selectSingleImage, selectCameraImage} from '@services/MultipickerUtils';
import {useDispatch, useSelector} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';
import {generalSaveAction} from '@serviceAction';
import {MY_PROPERTIES} from '@actionTypes';
import constant from '@constants';
import defaultStyles from '@reuseableComponents/BottomActionSheet/DefaultStyles';

export default function () {
  const formHandler = useRef();
  const actionSheet = useRef();
  const dateFieldRef = useRef();
  const appointmentFieldRef = useRef();
  const actionSheetPropertyType = useRef();
  const propertyTypeFieldRef = useRef();
  const imageBottomSheetRef = useRef();

  const dispatch = useDispatch();
  const user = useSelector(({user}) => user.data);

  let focusByRefCollectorKeyRef = null;
  const [state, setState] = React.useState({
    pickedDate: new Date(),
    isShowDatePicker: false,
    isDatePicked: false,
    img: {path: null},
    appointment: null,
    isFormSubmitted: false,
  });

  const APPOINTMENT_OPTIONS = {
    0: 'Yes',
    1: 'No',
  };

  const onCreateProperty = () => {
    setState(s => ({...s, isFormSubmitted: true}));
    const data = formHandler.current.onSubmitForm();
    if (!state.isDatePicked)
      dateFieldRef.current.setError(true, 'Sell by date is required');

    if (state.appointment == null)
      appointmentFieldRef.current.setError(
        true,
        'Appointment status is required',
      );

    // if property type not selected show error
    if (state.propertyType == null)
      propertyTypeFieldRef.current.setError(true, 'Property type is required');

    if (
      data &&
      state.appointment !== null &&
      state.isDatePicked &&
      state.img.path !== null &&
      state.propertyType !== null
    ) {
      const payload = new FormData();
      Object.keys(data).map(key => payload.append(key, data[key]));
      payload.append('image_url', {
        uri: state.img.path,
        type: state.img.mime,
        name: 'img',
      });
      payload.append('cma_appointment', APPOINTMENT_OPTIONS[state.appointment]);
      payload.append(
        'sell_date',
        moment(state.pickedDate).format('YYYY-MM-DD'),
      );
      payload.append('customer_id', user.id);
      payload.append('prototype_type', '');
      payload.append('property_status', '');
      payload.append(
        'property_type',
        constant.PROPERTY_TYPES[state.propertyType],
      );
      dispatch(
        request(
          apis.createProperty,
          apis.serviceTypes.POST,
          payload,
          null,
          true,
          false,
          data => {
            dispatch(
              generalSaveAction(MY_PROPERTIES.ADD, {
                isAddAtZero: true,
                ...data,
              }),
            );
            pop();
          },
        ),
      );
    }
  };

  const onSelectImg = index =>
    index == 1
      ? setTimeout(
          () =>
            selectCameraImage().then(res => {
              setState(s => ({...s, img: res, isImgPicked: true}));
            }),
          400,
        )
      : setTimeout(
          () =>
            selectSingleImage().then(res =>
              setState(s => ({...s, img: res, isImgPicked: true})),
            ),
          400,
        );

  const cbOnImageSelection = () =>
    imageBottomSheetRef.current.showActionSheet();

  cbImageOptionSelected = index => {
    index && onSelectImg(index);
  };

  return (
    <View style={styles.container}>
      <ShadowHeader onBack={pop} title="Seller Information" useShadows />
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}>
        <FormHandlerUpdated ref={formHandler}>
          {(refCollector, onSubmitEditing, focusByRefCollectorKey) => {
            focusByRefCollectorKeyRef = focusByRefCollectorKey;
            const {text, number, website} = FormHandlerUpdated.INPUTS(
              refCollector,
              onSubmitEditing,
            );
            return (
              <>
                <MaterialTextField
                  style={{width: '100%'}}
                  label="Agent"
                  placeholder="Agent name"
                  value={user.agent.name}
                  editable={false}
                  rightIcon={Images.icContactList}
                />
                <MaterialTextField
                  {...text({identifier: 'title'})}
                  style={{width: '100%'}}
                  label="Community/Building"
                  placeholder="Enter title"
                  error="Title is required"
                  onSubmitEditing={cbOnImageSelection}
                />
                <View>
                  <ButtonView
                    style={styles.imgWrapper}
                    onPress={cbOnImageSelection}>
                    <ImageHandlerUpdated
                      source={
                        state.img.path
                          ? {uri: state.img.path}
                          : Images.icPlaceHolderProperty
                      }
                      style={{
                        width: Metrics.widthRatio(80),
                        height: Metrics.widthRatio(80),
                        borderRadius: Metrics.smallMargin,
                      }}
                    />
                    <Text style={styles.imgTxt}>Add Property Image</Text>
                  </ButtonView>
                  {state.isFormSubmitted && !state.img.path && (
                    <Text style={styles.imgErr}>
                      Property image is required
                    </Text>
                  )}
                </View>

                <MaterialTextField
                  {...text({identifier: 'address'})}
                  style={{width: '100%'}}
                  label="Address"
                  placeholder="Enter address"
                  error="Address is required"
                />
                <MaterialTextField
                  {...text({identifier: 'city'})}
                  style={{width: '100%'}}
                  label="City"
                  placeholder="Enter city"
                  error="City is required"
                />
                <MaterialTextField
                  {...text({identifier: 'state'})}
                  style={{width: '100%'}}
                  label="State"
                  placeholder="Enter state"
                  error="State is required"
                />
                <MaterialTextField
                  {...text({identifier: 'zipcode'})}
                  style={{width: '100%'}}
                  label="Zip Code"
                  placeholder="Enter zip code"
                  error="Zip code is required"
                />
                <MaterialTextField
                  {...website({identifier: 'mls_detail'})}
                  style={{width: '100%'}}
                  label="MLS Link URL"
                  placeholder="Enter url"
                  error="Url is required"
                />
                <MaterialTextField
                  {...number({identifier: 'asking_price'})}
                  style={{width: '100%'}}
                  label="Asking Price"
                  placeholder="Enter price"
                  error="Price is required"
                  onSubmitEditing={() => focusByRefCollectorKeyRef('sell_date')}
                  isPriceInput
                />
                <MaterialTextField
                  ref={dateFieldRef}
                  identifier="sell_date"
                  style={{width: '100%'}}
                  label="What’s your “Sell by” date?"
                  type={INPUT_TYPES.TEXT}
                  placeholder={moment(state.pickedDate).format('DD/mm/yyyy')}
                  rightIcon={Images.icCalendarField}
                  editable={false}
                  onRightPress={() =>
                    setState(s => ({...s, isShowDatePicker: true}))
                  }
                  value={
                    state.isDatePicked
                      ? moment(state.pickedDate).format('DD/mm/yyyy').toString()
                      : undefined
                  }
                  error="Sell by date is required"
                />
                <MaterialTextField
                  ref={appointmentFieldRef}
                  style={{width: '100%'}}
                  label="Request Listing/CMA appointment"
                  type={INPUT_TYPES.TEXT}
                  placeholder="Do you want an appointment"
                  rightIcon={Images.icDropdown}
                  editable={false}
                  onRightPress={() => actionSheet.current.show()}
                  value={
                    state.appointment !== 'null'
                      ? APPOINTMENT_OPTIONS[state.appointment]
                      : undefined
                  }
                  error="Appointment status is required"
                />
                <MaterialTextField
                  ref={propertyTypeFieldRef}
                  style={{width: '100%'}}
                  label="Property type"
                  type={INPUT_TYPES.TEXT}
                  placeholder="Select a property type"
                  rightIcon={Images.icDropdown}
                  editable={false}
                  onRightPress={() => actionSheetPropertyType.current.show()}
                  value={
                    state.propertyType !== 'null'
                      ? constant.PROPERTY_TYPES[state.propertyType]
                      : undefined
                  }
                  error="Appointment status is required"
                />
              </>
            );
          }}
        </FormHandlerUpdated>
        <SmallBtn
          style={{width: '48%', marginTop: Metrics.xDoubleBaseMargin}}
          bgColor={Colors.primary.darkslateblue}
          useBold
          title="Cancel"
          onPress={pop}
        />
        <SmallBtn
          style={{width: '48%', marginTop: Metrics.xDoubleBaseMargin}}
          bgColor={Colors.primary.clearblue}
          useBold
          title="Add"
          onPress={onCreateProperty}
        />
      </ScrollView>

      <DateTimePickerModal
        date={state.pickedDate}
        isVisible={state.isShowDatePicker}
        mode="date"
        onConfirm={date => {
          setState(s => ({
            ...s,
            isDatePicked: true,
            isShowDatePicker: false,
            pickedDate: date,
          }));
          dateFieldRef.current.setError(false, '');
        }}
        onCancel={() => setState(s => ({...s, isShowDatePicker: false}))}
        minimumDate={new Date()}
      />

      <ActionSheet
        ref={actionSheet}
        // title={'Appointment?'}
        options={['Yes', 'No', 'Cancel']}
        cancelButtonIndex={2}
        destructiveButtonIndex={2}
        onPress={index => {
          if (index !== 2) setState(s => ({...s, appointment: index}));
          appointmentFieldRef.current.setError(false, '');
        }}
        styles={defaultStyles(false)}
        tintColor={'#000'}
      />

      <ActionSheet
        ref={actionSheetPropertyType}
        // title={'Property Type?'}
        options={constant.PROPERTY_TYPES_OPTIONS}
        cancelButtonIndex={constant.PROPERTY_TYPES_OPTIONS.length - 1}
        destructiveButtonIndex={constant.PROPERTY_TYPES_OPTIONS.length - 1}
        onPress={index => {
          if (index !== constant.PROPERTY_TYPES_OPTIONS.length - 1) {
            setState(s => ({...s, propertyType: index}));
            propertyTypeFieldRef.current.setError(false, '');
          }
        }}
        styles={defaultStyles(false)}
        tintColor={'#000'}
      />

      <BottomActionSheet
        ref={imageBottomSheetRef}
        options={['Cancel', 'Camera', 'Photo Album']}
        cbOnPressActionSheet={cbImageOptionSelected}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
    paddingBottom: Metrics.xDoubleBaseMargin,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  imgTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginLeft: Metrics.baseMargin,
  },
  imgWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: Metrics.doubleBaseMargin,
  },
  imgErr: {
    paddingTop: Metrics.widthRatio(4),
    ...AppStyles.gbRe(10, Colors.primary.vermillion),
  },
});
