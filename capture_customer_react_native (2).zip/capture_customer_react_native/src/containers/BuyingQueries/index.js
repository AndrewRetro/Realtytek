import React, {useEffect} from 'react';

import {BigCard} from '@components';
import {FlatListHandler} from '@reuseableComponents';

import {useDispatch, useSelector} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';
import {BUYING_QUERIES} from '@actionTypes';
import constant from '@constants';
import {Metrics} from '@theme';
import {navigate} from '@nav';

export default BuyingQueries = () => {
  const dispatch = useDispatch();
  const {buyingQueries, user} = useSelector(({buyingQueries, user}) => ({
    buyingQueries,
    user: user.data,
  }));

  const {agent} = user;

  useEffect(() => {
    fetchBuyingQueries();
  }, []);

  const fetchBuyingQueries = (isConcat = false, page = 1) => {
    dispatch(
      request(
        apis.createBuyer,
        apis.serviceTypes.GET,
        {page, limit: 10, buyer_type: constant.BUYERS},
        BUYING_QUERIES,
        false,
        isConcat,
      ),
    );
  };

  const onBuyingQueryDetail = buyingQuery => () =>
    navigate('BuyingQuery', {buyingQuery});

  const renderBuyingQuries = ({item}) => (
    <BigCard
      onPress={onBuyingQueryDetail(item)}
      item={item}
      useFullWidth
      agent={agent}
    />
  );

  return (
    <FlatListHandler
      style={styles.list}
      fetchRequest={fetchBuyingQueries}
      data={buyingQueries.data}
      meta={buyingQueries.meta}
      isFetching={buyingQueries.isFetching}
      renderItem={renderBuyingQuries}
    />
  );
};

const styles = {
  list: {marginTop: Metrics.smallMargin},
};
