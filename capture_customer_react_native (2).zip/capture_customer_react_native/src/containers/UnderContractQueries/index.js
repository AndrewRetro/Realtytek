import React, {useEffect} from 'react';
import {View} from 'react-native';

import {FlatListHandler} from '@reuseableComponents';
import {BigCard} from '@components';

import {useDispatch, useSelector} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';
import constant from '@constants';
import {UNDER_CONTRACT} from '@actionTypes';
import {push} from '@nav';
import {Metrics} from '@theme';

export default SellingUnderContractList = () => {
  const dispatch = useDispatch();

  const {underContract, user} = useSelector(({underContract, user}) => ({
    underContract,
    user: user.data,
  }));

  const {agent} = user;

  useEffect(() => {
    fetchUnderContractProperties();
  }, []);

  const fetchUnderContractProperties = (isConcat = false, page = 1) => {
    dispatch(
      request(
        apis.createBuyer,
        apis.serviceTypes.GET,
        {
          page,
          limit: 10,
          buyer_type: constant.UNDER_CONTRACT,
        },
        UNDER_CONTRACT,
        false,
        isConcat,
      ),
    );
  };

  const onProperties = buyingQuery => () => {
    push('UnderContract', {
      isFromUnderContract: false,
      isFromBuyingUnderContract: true,
      buyingQuery,
    });
  };

  const renderProperties = ({item}) => (
    <BigCard
      onPress={onProperties(item)}
      item={item}
      useFullWidth
      isUnderContractCard
      agent={agent}
    />
  );

  return (
    <View style={styles.container}>
      <FlatListHandler
        fetchRequest={fetchUnderContractProperties}
        data={underContract.data}
        isFetching={underContract.isFetching}
        meta={underContract.meta}
        renderItem={renderProperties}
      />
    </View>
  );
};

const styles = {
  container: {
    flex: 1,
    paddingTop: Metrics.smallMargin,
  },
};
