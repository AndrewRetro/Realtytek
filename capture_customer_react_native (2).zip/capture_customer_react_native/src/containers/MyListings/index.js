import React, {useEffect} from 'react';
import {View} from 'react-native';
import {FlatListHandler} from '@reuseableComponents';
import {BigCardTwo, ListingCards} from '@components';

import {Metrics} from '@theme';
import {navigate} from '@services/NavigationService';

import {useDispatch, useSelector} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';
import {MY_PROPERTIES} from '@actionTypes';
import ListEmpty from '@reuseableComponents/FlatListHandler/ListEmpty';

export default MyListings = ({isHorizontal}) => {
  const dispatch = useDispatch();
  const myProperties = useSelector(({myProperties}) => myProperties);

  useEffect(() => fetchMyProperties(), []);

  const fetchMyProperties = (isConcat = false, page = 1) => {
    dispatch(
      request(
        apis.createProperty,
        apis.serviceTypes.GET,
        {page, limit: 10},
        MY_PROPERTIES,
        false,
        isConcat,
        null,
        null,
        MY_PROPERTIES,
      ),
    );
  };

  const renderItem = ({item}) =>
    isHorizontal ? (
      <BigCardTwo
        onPress={() => {
          navigate('PropertyContractDetails', {
            isFromUnderContract: false,
            data: item,
          });
        }}
        item={item}
      />
    ) : (
      <ListingCards item={item} isMyProperty />
    );

  if (isHorizontal && !myProperties.isFetching && !myProperties.data.length) {
    return (
      <View style={styles.containerEmpty}>
        <ListEmpty />
      </View>
    );
  }

  const containerStyle = isHorizontal
    ? myProperties.data.length
      ? {}
      : {height: Metrics.screenHeight / 4}
    : {flex: 1};

  return (
    <View style={containerStyle}>
      <FlatListHandler
        fetchRequest={isHorizontal ? null : fetchMyProperties}
        horizontal={isHorizontal}
        meta={myProperties.meta}
        data={myProperties.data}
        isFetching={myProperties.isFetching}
        showsHorizontalScrollIndicator={false}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        bounces={isHorizontal ? false : true}
      />
    </View>
  );
};

const styles = {
  containerEmpty: {
    height: Metrics.widthRatio(200),
  },
};
