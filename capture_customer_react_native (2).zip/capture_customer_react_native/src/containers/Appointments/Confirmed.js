import React, {useEffect} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {View} from 'react-native';

import {AppointmentCard} from '@components';
import {FlatListHandler} from '@reuseableComponents';

import apis from '@apis';
import {request} from '@serviceAction';
import {Metrics} from '@theme';
import {AppointmentStatus} from '@constants';
import {APPOINTMENTS_CONFIRMED} from '@actionTypes';

const Confirmed = () => {
  const dispatch = useDispatch();

  const appointmentsConfirmed = useSelector(
    ({appointmentsConfirmed}) => appointmentsConfirmed,
  );

  useEffect(() => {
    fetchConfirmedAppointments();
  }, []);

  fetchConfirmedAppointments = (isConcat = false, page = 1) => {
    dispatch(
      request(
        apis.createAppointment,
        apis.serviceTypes.GET,
        {
          status: AppointmentStatus.ACCEPT,
          page,
          limit: 10,
        },
        APPOINTMENTS_CONFIRMED,
        false,
        isConcat,
      ),
    );
  };

  const renderAppointments = ({item}) => <AppointmentCard item={item} />;

  return (
    <FlatListHandler
      fetchRequest={fetchConfirmedAppointments}
      data={appointmentsConfirmed.data}
      isFetching={appointmentsConfirmed.isFetching}
      meta={appointmentsConfirmed.meta}
      renderItem={renderAppointments}
    />
  );
};

export default Confirmed;

const styles = {
  separator: {height: Metrics.baseMargin},
};
