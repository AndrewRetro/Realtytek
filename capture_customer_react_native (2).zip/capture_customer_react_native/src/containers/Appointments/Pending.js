import React, {useEffect} from 'react';
import {useDispatch, useSelector} from 'react-redux';

import {AppointmentCard} from '@components';
import {FlatListHandler} from '@reuseableComponents';

import apis from '@apis';
import {request} from '@serviceAction';
import {APPOINTMENTS_PENDING} from '@actionTypes';

const Pending = () => {
  const dispatch = useDispatch();

  const appointmentsPending = useSelector(
    ({appointmentsPending}) => appointmentsPending,
  );

  useEffect(() => {
    fetchPendingAppointments();
  }, []);

  fetchPendingAppointments = (isConcat = false, page = 1) => {
    dispatch(
      request(
        apis.createAppointment,
        apis.serviceTypes.GET,
        {
          status: 'pending',
          page,
          limit: 10,
        },
        APPOINTMENTS_PENDING,
        false,
        isConcat,
      ),
    );
  };

  const renderAppointments = ({item}) => <AppointmentCard item={item} />;

  return (
    <FlatListHandler
      fetchRequest={fetchPendingAppointments}
      data={appointmentsPending.data}
      isFetching={appointmentsPending.isFetching}
      meta={appointmentsPending.meta}
      renderItem={renderAppointments}
    />
  );
};

export default Pending;
