import React, {useContext, useEffect, useRef, useState} from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import OneSignal from 'react-native-onesignal';

import {LoginContext} from '@contexts';
import {GradientContainer, BigBtn} from '../../components';
import {
  ButtonView,
  FormHandler,
  ImageHandler,
  MaterialTextField,
} from '../../reuseableComponents';
import {INPUT_TYPES} from '../../reuseableComponents/FormHandler/Constants';
import CheckBox from '@react-native-community/checkbox';
import {navigate} from '../../services/NavigationService';
import {Colors, Metrics, Fonts, Images} from '../../theme';
import HttpServiceManager from '@services/HttpServiceManager';

import {useDispatch} from 'react-redux';
import apis from '@apis';
import {request} from '@serviceAction';
import {USER} from '@actionTypes';
import utility from '@utils';
import constant from '@constants';

const Login = () => {
  const {setLogin} = useContext(LoginContext);
  const dispatch = useDispatch();
  const formHandler = useRef();

  const [state, setState] = useState({
    isShowPass: false,
    device_token: null,
  });

  const intervalRef = useRef(null);
  useEffect(() => {
    intervalRef.current = setInterval(() => fetchDeviceState(), 5000);
  }, []);

  useEffect(() => {
    state.device_token &&
      intervalRef.current &&
      clearInterval(intervalRef.current);
  }, [state.device_token]);

  const fetchDeviceState = async () => {
    const {userId} = await OneSignal.getDeviceState();
    userId && setState(s => ({...s, device_token: userId}));
  };

  const onForgotPass = () => navigate('ForgotPass');
  const onAgencyDisclosure = () => navigate('AgencyDisclosure');
  const onShowPass = () => setState(s => ({...s, isShowPass: !s.isShowPass}));

  const onLogin = async () => {
    const data = formHandler.current.onSubmitForm();
    if (data) {
      const {userId} = await OneSignal.getDeviceState();

      dispatch(
        request(
          apis.login,
          apis.serviceTypes.POST,
          {
            ...data,
            device_type: utility.isPlatformIOS() ? 'ios' : 'android',
            user_type: constant.USER_TYPE_CUSTOMER,
            device_token: userId,
          },
          USER,
          true,
          false,
          user => {
            HttpServiceManager.getInstance().userToken = user.api_token;
            setLogin(true);
          },
        ),
      );
    }
  };

  return (
    <ScrollView keyboardShouldPersistTaps="handled">
      <GradientContainer style={styles.container}>
        <View style={styles.header}>
          <ImageHandler source={Images.icLoginLogo} />
        </View>
        <View style={styles.content}>
          <Text style={styles.description}>
            Please login to your account using credentials sent to your Mobile
            number Or Email
          </Text>
          <Text style={styles.mainTxt}>Login Here</Text>
          <FormHandler ref={formHandler}>
            <MaterialTextField
              leftIcon={Images.icEmail}
              placeholder="Email"
              identifier="email"
              type={INPUT_TYPES.EMAIL}
              error="Email is required"
              blurOnSubmit={false}
              returnKeyType="next"
            />
            <MaterialTextField
              leftIcon={Images.icPassword}
              placeholder="Password"
              identifier="password"
              type={state.isShowPass ? INPUT_TYPES.TEXT : INPUT_TYPES.PASSWORD}
              rightIcon={state.isShowPass ? Images.icEyeOff : Images.icEye}
              onRightPress={onShowPass}
              secureTextEntry={false}
              error="Password is required"
              returnKeyType="done"
            />
          </FormHandler>
          <ButtonView style={styles.forgotPasswordBtn} onPress={onForgotPass}>
            <Text style={styles.forgotPasswordTxt}>Forgot Password?</Text>
          </ButtonView>

          <BigBtn onPress={setLogin} title="SIGN IN" onPress={onLogin} />
        </View>
      </GradientContainer>
    </ScrollView>
  );
};

export default Login;

const styles = StyleSheet.create({
  container: {
    width: Metrics.screenWidth,
    height: Metrics.screenHeight,
    justifyContent: 'space-between',
  },
  header: {
    flex: Metrics.screenHeight < 800 ? 0.3 : 0.35,
    justifyContent: 'center',
  },
  content: {
    flex: Metrics.screenHeight < 800 ? 0.7 : 0.65,
    paddingHorizontal: 25,
  },
  footer: {
    flex: 0.15,
    alignItems: 'center',
    backgroundColor: Colors.primary.white,
  },
  signInBtn: {
    flexDirection: 'row',
    padding: Metrics.baseMargin,
    marginTop: Metrics.heightRatio(8),
  },
  footerText: {
    ...Fonts.font({
      size: 15,
      color: Colors.primary.blueyGrey,
    }),
  },
  signInTxt: {
    ...Fonts.font({
      size: 15,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.brightlightblue,
    }),
    marginLeft: 5,
  },
  description: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkslateblue,
    }),
    lineHeight: 17,
  },
  mainTxt: {
    ...Fonts.font({
      type: Fonts.Type.SemiBold,
      size: 33,
      color: Colors.primary.dark,
    }),
    lineHeight: 42,
    marginTop: Metrics.heightRatio(8),
  },
  forgotPasswordTxt: {
    ...Fonts.font({
      size: 13,
    }),
  },
  forgotPasswordBtn: {
    paddingRight: 0,
    alignSelf: 'flex-end',
    padding: Metrics.baseMargin,
  },
});
