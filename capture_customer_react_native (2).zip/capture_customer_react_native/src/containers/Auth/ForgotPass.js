import React, {useRef} from 'react';
import {ScrollView, Text, View, Image, SafeAreaView} from 'react-native';

import {
  MaterialTextField,
  FormHandler,
  ButtonView,
} from '../../reuseableComponents';
import {BigBtn} from '../../components';
import {INPUT_TYPES} from '../../reuseableComponents/FormHandler/Constants';
import {AppStyles, Metrics, Images, Colors} from '../../theme';
import {pop} from '../../services/NavigationService';
import {useDispatch} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';
import utility from '@utils';
import constant from '@constants';

export default ForgotPass = () => {
  const dispatch = useDispatch();
  const formHandler = useRef();

  const onSubmitForm = () => {
    const data = formHandler.current.onSubmitForm();
    if (data) onForgotPass(data);
  };

  const onForgotPass = data => {
    dispatch(
      request(
        apis.forgotPass,
        apis.serviceTypes.POST,
        {email: data.email, type: constant.USER_TYPE_CUSTOMER},
        null,
        true,
        false,
        () => {
          utility.showFlashMessage(
            'Check your email for reset password link',
            'success',
          );
          pop();
        },
      ),
    );
  };

  const Header = () => (
    <View>
      <ButtonView onPress={pop}>
        <Image
          source={Images.icBackArrow}
          style={{
            marginLeft: Metrics.doubleBaseMargin,
            marginTop: Metrics.baseMargin,
          }}
        />
      </ButtonView>
      <Image
        source={Images.icLoginLogo}
        style={{marginTop: Metrics.baseMargin}}
      />
    </View>
  );

  return (
    <ScrollView
      contentContainerStyle={{
        width: Metrics.screenWidth,
        height: Metrics.screenHeight,
        backgroundColor: Colors.primary.white,
      }}>
      <SafeAreaView style={{flex: 1}}>
        <Header />
        <View
          style={{
            flex: 1,
            justifyContent: 'center',
            padding: Metrics.doubleBaseMargin,
            marginBottom: Metrics.widthRatio(90),
          }}>
          <Text style={AppStyles.gbSb(24, Colors.primary.darkslateblue)}>
            Forgot Password
          </Text>
          <Text
            style={{
              ...AppStyles.gbRe(14, Colors.primary.lightgreyblue),
              marginBottom: Metrics.baseMargin * 1.5,
              marginTop: Metrics.baseMargin,
            }}>
            Please enter your email address associated with your account
          </Text>

          <FormHandler ref={formHandler}>
            <MaterialTextField
              leftIcon={Images.icEmail}
              placeholder="Email"
              identifier="email"
              type={INPUT_TYPES.EMAIL}
              error="Email address is required"
            />
          </FormHandler>
          <BigBtn
            onPress={onSubmitForm}
            title="SEND"
            style={{
              width: Metrics.screenWidth - Metrics.doubleBaseMargin * 2,
              marginTop: Metrics.baseMargin,
            }}
          />
        </View>
      </SafeAreaView>
    </ScrollView>
  );
};
