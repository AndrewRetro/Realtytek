import React from 'react';
import {ScrollView, Text, View, Image, SafeAreaView} from 'react-native';

import {
  MaterialTextField,
  FormHandler,
  ButtonView,
} from '../../reuseableComponents';
import {BigBtn} from '../../components';
import {INPUT_TYPES} from '../../reuseableComponents/FormHandler/Constants';
import {AppStyles, Metrics, Images, Colors} from '../../theme';
import {pop} from '../../services/NavigationService';

export default AgencyDisclosure = () => {
  const Header = () => (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
      }}>
      <Text
        style={{
          ...AppStyles.gbRe(18, Colors.primary.darkslateblue),
          position: 'absolute',
          left: 0,
          right: 0,
          textAlign: 'center',
        }}>
        Agency Disclosure
      </Text>
      <ButtonView onPress={pop} style={{padding: Metrics.baseMargin}}>
        <Image
          source={Images.icBackArrow}
          style={{
            marginRight: Metrics.baseMargin,
          }}
        />
      </ButtonView>
    </View>
  );

  return (
    <SafeAreaView style={{flex: 1}}>
      <Header />
      <View
        style={{
          flex: 1,
          padding: Metrics.baseMargin,
        }}>
        <Text style={{...AppStyles.gbRe(16, Colors.primary.black)}}>
          Contrary to popular belief, Lorem Ipsum is not simply random text. It
          has roots in a piece of classical Latin literature from 45 BC, making
          it over 2000 years old. Richard McClintock, a Latin professor at
          Hampden-Sydney College in Virginia, looked up one of the more obscure
          Latin words, consectetur, from a Lorem Ipsum passage, and going
          through the cites of the word in classical literature, discovered the
          undoubtable source. Lorem Ipsum comes from sections 1.10.32 and
          1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and
          Evil) by Cicero, written in 45 BC. This book is a treatise on the
          theory of ethics, very popular during the Renaissance. The first line
          of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in
          section 1.10.32 Contrary to popular belief, Lorem Ipsum is not simply
          random text.\n It has roots in a piece of classical Latin literature
          from 45 BC, making it over 2000 years old. Richard McClintock, a Latin
          professor at Hampden-Sydney College in Virginia, looked up one of the
          more obscure Latin words, consectetur, from a Lorem Ipsum passage, and
          going through the cites of the word in classical literature,
          discovered the undoubtable source. Lorem Ipsum comes from sections
          1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes
          of Good and Evil) by Cicero, written in 45 BC. This book is a treatise
          on the theory of ethics, very popular during the Renaissance. The
          first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from
          a line in section 1.10.32 Contrary to popular belief, Lorem Ipsum is
          not simply random text. It has roots in a piece of classical Latin
          literature from 45 BC, making it over 2000 years old. Richard
          McClintock, a Latin professor at Hampden-Sydney College in Virginia,
          looked up one of the more obscure Latin words, consectetur, from a
          Lorem Ipsum passage, and going through the cites of the word in
          classical literature, discovered the undoubtable source. Lorem Ipsum
          comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et
          Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC.
          This book is a treatise on the theory of ethics, very popular during
          the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit
          amet..", comes from a line in section 1.10.32
        </Text>
      </View>
    </SafeAreaView>
  );
};
