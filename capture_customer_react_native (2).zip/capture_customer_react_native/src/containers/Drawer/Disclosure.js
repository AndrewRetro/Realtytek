import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import {PropTypes} from 'prop-types';
import {useIsFocused} from '@react-navigation/native';

import {BackHeader} from '../../components';
import {ButtonView, Loader} from '../../reuseableComponents';
import {pop} from '../../services/NavigationService';
import {AppStyles, Colors, Fonts, Images, Metrics} from '../../theme';

import {useDispatch, useSelector} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';
import utility from '@utils';
import {generalSaveAction} from '@serviceAction';
import {DOWNLOAD_FILE} from '@actionTypes';
import ListEmpty from '@reuseableComponents/FlatListHandler/ListEmpty';

const Disclosure = ({route}) => {
  const dispatch = useDispatch();
  const {isFromDrawer = true} = route.params;
  const user = useSelector(({user}) => user.data);
  const {api_token, agent} = user;

  const [state, setState] = useState({
    links: [],
    docs: [],
    isFetching: false,
    downloading: {},
  });
  const isFocused = useIsFocused();
  useEffect(() => {
    fetchAgentDisclosures();
  }, [isFocused]);

  const fetchAgentDisclosures = () => {
    setState(s => ({...s, isFetching: true}));
    dispatch(
      request(
        apis.getAgentDisclosures,
        apis.serviceTypes.GET,
        {},
        null,
        false,
        false,
        ({document, link}) =>
          setState(s => ({
            ...s,
            links: link,
            docs: document,
            isFetching: false,
          })),
      ),
    );
  };

  const dispatchDownload =
    ({id, file_url, filename}) =>
    () => {
      setState(s => ({
        ...s,
        downloading: {...s.downloading, [id]: {isDownloading: true}},
      }));
      dispatch(
        generalSaveAction(DOWNLOAD_FILE, {
          url: file_url,
          userToken: api_token,
          fileName: filename,
          cbSuccess: () =>
            setState(s => ({
              ...s,
              downloading: {...s.downloading, [id]: {isDownloading: false}},
            })),
          cbFailure: () =>
            setState(s => ({
              ...s,
              downloading: {...s.downloading, [id]: {isDownloading: false}},
            })),
        }),
      );
    };

  const Docs = () => {
    return (
      <View style={styles.containerRow}>
        {state.docs.map((doc, index) => {
          return (
            <ButtonView
              style={styles.doc}
              key={`doc_${index}`}
              onPress={() => utility.openLink(doc.file_url)}>
              <Image style={styles.icDoc} source={Images.icDoc} />
              <Text
                style={styles.txtDocTitle}
                numberOfLines={1}
                ellipsizeMode="tail">
                {doc.filename ? doc.filename : 'Doc'}
              </Text>
              {state.downloading?.[doc.id]?.isDownloading ? (
                <ActivityIndicator
                  size="small"
                  color={Colors.primary.purplishbrown}
                />
              ) : (
                <ButtonView
                  onPress={dispatchDownload(doc)}
                  style={styles.containerIcDeleteDoc}>
                  <Image
                    source={Images.icDownload}
                    style={styles.icDeleteDoc}
                  />
                </ButtonView>
              )}
            </ButtonView>
          );
        })}
      </View>
    );
  };

  const onLink = link => () => utility.openLink(link);

  const Links = () => {
    return state.links.map((link, index) => (
      <LinkItem data={link} index={index} key={link.id} />
    ));
  };

  const LinkItem = ({data}) => {
    const {title, link} = data;

    return (
      <ButtonView style={styles.content} onPress={onLink(link)}>
        <View style={styles.card}>
          <View style={styles.cardWrapper}>
            <Text style={styles.cardTxt}>{title ? title : 'Title'}</Text>
          </View>
          <Text numberOfLines={2} style={styles.cardLink}>
            {link}
          </Text>
        </View>
      </ButtonView>
    );
  };

  if (!state.isFetching && !state.links.length && !state.docs.length) {
    return (
      <View style={styles.container}>
        <BackHeader
          useDrawer={isFromDrawer ? true : false}
          title="Lenders & State Agency Disclosure"
          onBack={isFromDrawer ? null : pop}
          titleStyle={isFromDrawer ? {} : styles.titleStyle}
          containerStyle={isFromDrawer ? {} : styles.backHeader}
        />
        <ListEmpty />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <BackHeader
        useDrawer={isFromDrawer ? true : false}
        title="Lenders & State Agency Disclosure"
        onBack={isFromDrawer ? null : pop}
        titleStyle={isFromDrawer ? {} : styles.titleStyle}
        containerStyle={isFromDrawer ? {} : styles.backHeader}
      />
      {state.isFetching ? (
        <Loader />
      ) : (
        <ScrollView contentContainerStyle={{paddingBottom: Metrics.baseMargin}}>
          <Agreement
            agent={agent}
            dispatchDownload={dispatchDownload}
            isDownloading={state.downloading?.['-1']?.isDownloading}
          />
          <Text style={styles.txtTitleDoc}>Documents</Text>
          <Docs />
          <Text style={styles.txtTitleLinks}>Links</Text>
          <Links />
        </ScrollView>
      )}
    </View>
  );
};

const Agreement = ({agent, dispatchDownload, isDownloading}) => {
  const {agent_agrement, name} = agent;

  if (agent_agrement && agent_agrement.length) {
    return (
      <View style={{marginRight: Metrics.baseMargin}}>
        <Text style={styles.txtTitleDoc}>Agreement</Text>
        <ButtonView
          style={styles.doc}
          onPress={() => utility.openLink(agent_agrement)}>
          <Image style={styles.icDoc} source={Images.icDoc} />
          <Text
            style={styles.txtDocTitle}
            numberOfLines={1}
            ellipsizeMode="tail">
            Agreement Document
          </Text>
          {isDownloading ? (
            <ActivityIndicator
              size="small"
              color={Colors.primary.purplishbrown}
            />
          ) : (
            <ButtonView
              onPress={dispatchDownload({
                id: '-1',
                file_url: agent_agrement,
                filename: `${name}_agreement_document`,
              })}
              style={styles.containerIcDeleteDoc}>
              <Image source={Images.icDownload} style={styles.icDeleteDoc} />
            </ButtonView>
          )}
        </ButtonView>
      </View>
    );
  }
  return null;
};

Disclosure.propTypes = {
  isFromDrawer: PropTypes.bool,
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.primary.white,
  },
  content: {
    flex: 1,
    marginHorizontal: Metrics.baseMargin,
    marginVertical: Metrics.xDoubleBaseMargin,
  },
  card: {
    borderRadius: 6,
    padding: Metrics.baseMargin,
  },
  backHeader: {
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 1.5,
    elevation: 5,
  },
  titleStyle: {
    ...AppStyles.gbRe(17, Colors.primary.dark),
    maxWidth: null,
    flex: 1,
    textAlign: 'center',
    marginRight: Metrics.widthRatio(55),
  },
  txtTitleDoc: {
    ...AppStyles.gbSb(16, Colors.primary.black),
    marginLeft: Metrics.baseMargin,
    marginTop: Metrics.baseMargin,
  },
  txtTitleLinks: {
    marginTop: Metrics.doubleBaseMargin,
    ...AppStyles.gbSb(16, Colors.primary.black),
    marginLeft: Metrics.baseMargin,
  },
  content: {
    flex: 1,
    justifyContent: 'space-between',
    marginHorizontal: Metrics.baseMargin,
    marginTop: Metrics.widthRatio(18),
  },
  card: {
    borderRadius: 6,
    padding: Metrics.baseMargin,
    backgroundColor: Colors.primary.palegrey,
  },
  cardTxt: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.darkslateblue,
    }),
  },
  cardWrapper: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  cardLink: {
    ...Fonts.font({
      size: 12,
      color: Colors.primary.clearblue,
    }),
    lineHeight: Metrics.heightRatio(20),
  },
  containerRow: {
    marginRight: Metrics.baseMargin,
    flex: 1,
  },
  doc: {
    flexDirection: 'row',
    marginTop: Metrics.baseMargin,
    backgroundColor: Colors.primary.palegrey,
    alignItems: 'center',
    borderRadius: Metrics.widthRatio(6),
    marginLeft: Metrics.baseMargin,
    padding: Metrics.baseMargin,
    paddingLeft: Metrics.smallMargin,
  },
  icDoc: {
    width: Metrics.widthRatio(30),
    height: Metrics.widthRatio(30),
    resizeMode: 'contain',
    tintColor: Colors.primary.clearblue,
  },
  deleteBtnLink: {
    paddingLeft: Metrics.baseMargin,
    paddingBottom: Metrics.smallMargin,
  },
  containerIcDeleteDoc: {
    padding: Metrics.smallMargin,
  },
  icDeleteDoc: {
    width: Metrics.widthRatio(20),
    height: Metrics.widthRatio(20),
  },
  txtDocTitle: {
    marginRight: Metrics.baseMargin,
    marginLeft: Metrics.smallMargin,
    ...AppStyles.gbRe(15, Colors.primary.darkslateblue),
    flex: 1,
  },
});

export default Disclosure;
