import React, {Component, useContext, useRef, useState} from 'react';
import {View, Text, StyleSheet} from 'react-native';

import {ShadowHeader, SmallBtn} from '../../components';
import {pop} from '../../services/NavigationService';
import {FormHandler, MaterialTextField} from '../../reuseableComponents';
import {INPUT_TYPES} from '../../reuseableComponents/FormHandler/Constants';
import {Colors, Images, Metrics} from '../../theme';
import {request} from '@serviceAction';
import {useDispatch} from 'react-redux';
import apis from '@apis';
import {generalSaveAction} from '@serviceAction';
import {LOGOUT} from '@actionTypes';
import {LoginContext} from '@contexts';
import utility from '@utils';

export default function () {
  const formHandler = useRef();
  const dispatch = useDispatch();

  const {setLogin} = useContext(LoginContext);
  const [state, setState] = useState({
    isCurrentPassVisible: false,
    isNewPassVisible: false,
    isConfirmPassVisible: false,
  });

  const onSubmitForm = () => {
    const data = formHandler.current.onSubmitForm();

    if (data) {
      dispatch(
        request(
          apis.changePass,
          apis.serviceTypes.POST,
          data,
          null,
          true,
          false,
          () => {
            utility.showFlashMessage(
              'Password successfully updated. Login again',
              'success',
            );
            setLogin(false);
            dispatch(generalSaveAction(LOGOUT));
          },
        ),
      );
    }
  };

  onRight = key => e => setState(s => ({...s, [key]: !s[key]}));

  return (
    <View style={styles.container}>
      <ShadowHeader onBack={pop} title="Change Password" useShadows />
      <View style={styles.content}>
        <View>
          <FormHandler ref={formHandler}>
            <MaterialTextField
              label="Current Password"
              placeholder="Enter current password"
              type={
                state.isCurrentPassVisible
                  ? INPUT_TYPES.TEXT
                  : INPUT_TYPES.PASSWORD
              }
              error="Current password is required"
              identifier="current_password"
              rightIcon={
                state.isCurrentPassVisible ? Images.icEyeOff : Images.icEye
              }
              onRightPress={onRight('isCurrentPassVisible')}
            />
            <MaterialTextField
              label="New Password"
              placeholder="Enter new password"
              type={
                state.isNewPassVisible ? INPUT_TYPES.TEXT : INPUT_TYPES.PASSWORD
              }
              error="New password is required"
              identifier="new_password"
              rightIcon={
                state.isNewPassVisible ? Images.icEyeOff : Images.icEye
              }
              onRightPress={onRight('isNewPassVisible')}
            />
            <MaterialTextField
              label="Confirm New Password"
              placeholder="Enter confirm password"
              type={
                state.isConfirmPassVisible
                  ? INPUT_TYPES.TEXT
                  : INPUT_TYPES.PASSWORD
              }
              error="Confirm password is required"
              identifier="confirm_password"
              rightIcon={
                state.isConfirmPassVisible ? Images.icEyeOff : Images.icEye
              }
              onRightPress={onRight('isConfirmPassVisible')}
            />
          </FormHandler>
        </View>
        <SmallBtn
          useBold
          title="Save"
          bgColor={Colors.primary.clearblue}
          alignCenter
          onPress={onSubmitForm}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'space-between',
    marginHorizontal: Metrics.baseMargin,
    marginBottom: Metrics.xDoubleBaseMargin,
  },
});
