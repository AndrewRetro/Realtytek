import constant from '@constants';
import utility from '@utils';
import moment from 'moment';
import React from 'react';
import {View, Text, StyleSheet, ScrollView, Image} from 'react-native';

import {AbsoluteHeader} from '../../components';
import {ImageHandlerUpdated} from '../../reuseableComponents';

import {Colors, Fonts, Images, Metrics} from '../../theme';

export default function ({route}) {
  const {property, appointment_date, appointment_time} = route.params.property;

  const {
    image_url,
    title,
    address,
    asking_price,
    property_type,
    mls_detail,
    city,
    state,
    zipcode,
  } = property;

  const onMls = () => utility.openLink(mls_detail);

  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <ImageHandlerUpdated style={styles.cover} source={{uri: image_url}} />
      <AbsoluteHeader title="Property Detail" showRight={false} />
      <View style={styles.content}>
        <Tag
          {...{
            t1: 'Community/Building',
            d1: title,
            t2: 'Price',
            d2: utility.formateCurrency(asking_price),
          }}
        />

        <Tag
          {...{
            t1: 'Address',
            d1: address,
            t2: 'City',
            d2: city,
          }}
        />
        <Tag
          {...{
            t1: 'State',
            d1: state,
            t2: 'Zipcode',
            d2: zipcode,
          }}
        />

        <Tag
          {...{
            t1: 'Date',
            d1: appointment_date,
            t2: 'Time',
            d2: moment(appointment_time, constant.TIME_FORMAT_DB).format(
              constant.NOON_FORMAT,
            ),
          }}
        />

        <Text style={styles.tileTxt2}>Type</Text>
        <Text style={styles.tileDesc2}>{property_type}</Text>

        <Text style={styles.tileTxt2}>MLS Details</Text>
        <View
          style={{flexDirection: 'row', alignItems: 'center', marginTop: 8}}>
          <Image source={Images.icLink} />
          <Text style={styles.linkTxt} onPress={onMls}>
            {mls_detail}
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const Tag = ({t1, d1, t2, d2, rating}) => (
  <View style={{flexDirection: 'row'}}>
    <View style={{flex: 0.5}}>
      <Text style={styles.tileTxt2}>{t1}</Text>
      <Text style={styles.tileDesc2}>{d1}</Text>
    </View>

    <View style={{flex: 0.5}}>
      <Text style={styles.tileTxt2}>{t2}</Text>
      {!!d2 && <Text style={styles.tileDesc2}>{d2}</Text>}
      {rating !== 'null' && rating !== undefined && (
        <Rating useBig style={styles.tileDesc2} rating={rating} />
      )}
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  cover: {
    width: Metrics.screenWidth,
    height: Metrics.heightRatio(308),
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
    // marginTop: Metrics.baseMargin,
    marginBottom: Metrics.xDoubleBaseMargin,
  },
  tileTxt2: {
    ...Fonts.font({
      size: 12,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: Metrics.doubleBaseMargin,
  },
  tileDesc2: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginTop: 8,
  },
  linkTxt: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.Italic,
      color: Colors.primary.clearblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
  btn: {
    width:
      (Metrics.screenWidth - 2 * Metrics.baseMargin - Metrics.smallMargin) / 2,
  },
  btnContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Metrics.xDoubleBaseMargin,
  },
});
