import React, {useRef, useState} from 'react';
import {View, StyleSheet, ScrollView} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';

import {ShadowHeader, SmallBtn, MaskedInput} from '../../components';
import {
  ButtonView,
  FormHandlerUpdated,
  ImageHandlerUpdated,
  MaterialTextField,
  BottomActionSheet,
} from '../../reuseableComponents';

import {selectSingleImage, selectCameraImage} from '@services/MultipickerUtils';
import {pop} from '@services/NavigationService';
import {Colors, Fonts, Metrics, AppStyles} from '../../theme';
import {request} from '@serviceAction';
import {USER} from '@actionTypes';
import apis from '@apis';

export default function () {
  const user = useSelector(({user}) => user.data);
  const formHandler = useRef();
  const imageBottomSheetRef = React.useRef();
  const dispatch = useDispatch();

  const [state, setState] = useState({
    img: {path: user.image_url},
    isImgPicked: false,
  });

  const onUpdate = () => {
    const data = formHandler.current.onSubmitForm();

    if (data) {
      const formData = new FormData();

      state.isImgPicked &&
        formData.append('image_url', {
          uri: state.img.path,
          name: 'img',
          type: state.img.mime,
        });
      Object.keys(data).map(key => formData.append(key, data[key]));
      formData.append('_method', 'put');
      dispatch(
        request(
          `${apis.updateUser}/${user.slug}`,
          apis.serviceTypes.POST,
          formData,
          USER,
          true,
          false,
          () => pop(),
        ),
      );
    }
  };

  const onSelectImg = index =>
    index == 1
      ? setTimeout(
          () =>
            selectCameraImage().then(res => {
              setState(s => ({...s, img: res, isImgPicked: true}));
            }),
          400,
        )
      : setTimeout(
          () =>
            selectSingleImage().then(res =>
              setState(s => ({...s, img: res, isImgPicked: true})),
            ),
          400,
        );

  const cbOnImageSelection = () =>
    imageBottomSheetRef.current.showActionSheet();

  cbImageOptionSelected = index => {
    index && onSelectImg(index);
  };

  return (
    <View style={styles.container}>
      <ShadowHeader useShadows title="Edit Profile" onBack={pop} />
      <ScrollView
        bounces={0}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}>
        <View>
          <ButtonView onPress={cbOnImageSelection} style={styles.wrapperImg}>
            <ImageHandlerUpdated
              style={styles.imgWrapper}
              source={{uri: state.img.path}}
            />
          </ButtonView>
          <FormHandlerUpdated ref={formHandler}>
            {(refCollector, onSubmitEditing) => {
              const {text, number} = FormHandlerUpdated.INPUTS(
                refCollector,
                onSubmitEditing,
              );
              return (
                <>
                  <MaterialTextField
                    {...text({identifier: 'name'})}
                    label="Full Name"
                    placeholder="Enter name"
                    value={user.name}
                    error="Name is required"
                  />
                  <MaskedInput
                    {...number({identifier: 'mobile_no'})}
                    label="Phone Number"
                    placeholder="Enter phone number"
                    error="Phone number is required"
                    value={user?.mobile_no}
                  />
                </>
              );
            }}
          </FormHandlerUpdated>

          {/* <MaterialTextField
            label="Email"
            placeholder="Enter email"
            type={INPUT_TYPES.TEXT}
          />
          <MaterialTextField
            label="Phone Number"
            type={INPUT_TYPES.NUMBER}
            placeholder="123 456 789 658"
          /> */}
        </View>

        <SmallBtn
          style={styles.btn}
          title="SAVE"
          alignCenter
          useBold
          onPress={onUpdate}
        />
      </ScrollView>
      <BottomActionSheet
        ref={imageBottomSheetRef}
        options={['Cancel', 'Camera', 'Photo Album']}
        cbOnPressActionSheet={cbImageOptionSelected}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginTop: Metrics.baseMargin,
    marginHorizontal: Metrics.baseMargin,
    paddingBottom: Metrics.xDoubleBaseMargin,
    flexGrow: 1,
    justifyContent: 'space-between',
  },
  imgTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginLeft: Metrics.baseMargin,
  },
  imgWrapper: {
    width: Metrics.widthRatio(100),
    height: Metrics.widthRatio(100),
    borderRadius: Metrics.smallMargin,
  },
  imgContainer: {
    marginVertical: Metrics.baseMargin,
  },
  btn: {
    marginVertical: Metrics.xDoubleBaseMargin,
  },
  wrapperImg: {
    ...AppStyles.darkShadow,
    alignSelf: 'center',
    marginVertical: Metrics.heightRatio(60),
    width: Metrics.widthRatio(100),
    height: Metrics.widthRatio(100),
    borderRadius: Metrics.smallMargin,
  },
});
