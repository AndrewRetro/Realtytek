import React, {useContext, useMemo} from 'react';
import {StyleSheet, FlatList, View, Text} from 'react-native';
import {EventBusSingleton} from 'light-event-bus';

import {LoginContext} from '../../contexts';
import {Colors, Images, Metrics, Fonts} from '../../theme';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {navigate, toggleDrawer} from '@services/NavigationService';
import {
  ImageHandler,
  ButtonView,
  ImageHandlerUpdated,
} from '../../reuseableComponents';
import {useSelector} from 'react-redux';
import moment from 'moment';

import apis from '@apis';

const drawerRoutes = [
  {
    title: 'Home',
    route: 'TabStack',
    icon: Images.icHome,
  },
  {
    title: 'My Account',
    route: 'MyAccount',
    icon: Images.icMyAccount,
  },
  {
    route: 'Calendar',
    title: 'My Calendar',
    icon: Images.icBusiness,
  },
  {
    title: 'Approved Lenders',
    route: 'Disclosure',
    icon: Images.icApproval,
  },
  {
    title: 'Terms & Conditions',
    route: 'Webview',
    icon: Images.icApproval,
  },
  {
    title: 'Privacy Policy',
    route: 'Webview',
    icon: Images.icApproval,
  },
  {
    title: 'Logout',
    route: '',
    icon: Images.icLogout,
  },
];

function handleNavigateProfile() {
  navigate('Profile');
}

const index = props => {
  const {} = props;
  const {setLogin} = useContext(LoginContext);
  const {top} = useSafeAreaInsets();

  const user = useSelector(({user}) => user.data);

  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
          backgroundColor: Colors.primary.darkslateblue,
        },
        header: {
          height: 127 + top,
          alignItems: 'center',
          flexDirection: 'row',
          paddingTop: Metrics.baseMargin,
          backgroundColor: Colors.primary.clearblue,
        },
        closeBtn: {
          padding: Metrics.baseMargin,
        },
        profileCard: {
          flexDirection: 'row',
          alignItems: 'center',
          marginLeft: Metrics.baseMargin,
        },
        profileImageWrapper: {
          width: 51,
          height: 51,
          borderRadius: 22,
        },
        profileTxt: {
          ...Fonts.font({
            size: 18,
            type: Fonts.Type.SemiBold,
            color: Colors.primary.white,
          }),
        },
        profileSubtitle: {
          ...Fonts.font({
            size: 14,
            color: Colors.primary.white,
          }),
          marginTop: 8,
          opacity: 0.6,
        },
        profileTxtWrapper: {
          marginLeft: Metrics.smallMargin,
        },
        routeTxt: {
          ...Fonts.font({
            size: 16,
            color: Colors.primary.white,
          }),
          // marginLeft: Metrics.baseMargin,
          lineHeight: 24,
        },
        routeWrapper: {
          flexDirection: 'row',
          alignItems: 'center',
          paddingTop: Metrics.baseMargin,
          paddingBottom: Metrics.heightRatio(15),
        },
        routeIcon: {
          width: 40,
        },
      }),
    [top],
  );

  const onPress = item => ev => {
    toggleDrawer();
    if (item.title === 'Logout') {
      EventBusSingleton.publish('logout');
    } else if (item.title === 'Terms & Conditions') {
      navigate(item.route, {title: item.title, link: apis.terms});
    } else if (item.title === 'Privacy Policy') {
      navigate(item.route, {title: item.title, link: apis.privacy});
    } else {
      navigate(item.route);
    }
  };

  const onProfile = () => navigate('MyAccount');

  const duration = `Member since ${moment(user.created_at).format('MMM yyyy')}`;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <ButtonView style={styles.profileCard} onPress={onProfile}>
          <ImageHandlerUpdated
            style={styles.profileImageWrapper}
            source={{uri: user.image_url}}
          />
          <View style={styles.profileTxtWrapper}>
            <Text style={styles.profileTxt}>{user.name}</Text>
            <Text style={styles.profileSubtitle}>{duration}</Text>
          </View>
        </ButtonView>
      </View>
      <FlatList
        data={drawerRoutes}
        renderItem={({item}) => (
          <ButtonView
            onPress={onPress(item, setLogin)}
            style={styles.routeWrapper}>
            <View style={styles.routeIcon}>
              <ImageHandler source={item.icon} />
            </View>
            <Text style={styles.routeTxt}>{item.title}</Text>
          </ButtonView>
        )}
        contentContainerStyle={{
          paddingVertical: 15,
          paddingHorizontal: Metrics.baseMargin,
        }}
        keyExtractor={item => item.route}
      />
    </View>
  );
};

export default index;
