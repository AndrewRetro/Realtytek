import React, {useEffect, useState} from 'react';
import {View, Text, ScrollView, StyleSheet, Image} from 'react-native';
import {Calendar} from 'react-native-calendars';
import moment from 'moment';
import DateTimePickerModal from 'react-native-modal-datetime-picker';

import {BackHeader, CardAppointmentCalender} from '../../components';
import ListEmpty from '../../reuseableComponents/FlatListHandler/ListEmpty';
import {Loader, ButtonView} from '../../reuseableComponents';

import {Colors, Fonts, Images, Metrics, AppStyles} from '../../theme';
import {pop} from '../../services/NavigationService';
import constant from '@constants';
import {useSelector, useDispatch} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';

export default function ({route}) {
  const dispatch = useDispatch();
  const {isFromDrawer = true} = route.params;
  const agent = useSelector(({user}) => user.data.agent);

  const [state, setState] = useState({
    currentDate: moment(new Date()).format(constant.DB_DATE_FORMAT),
    markedDate: [],
    pickedDate: new Date(),
    appointments: [],
    isFetching: false,
    isShowDatePicker: false,
  });
  const {currentDate, markedDate, pickedDate} = state;
  const momentPickedDate = moment(pickedDate);

  useEffect(() => {
    fetchAppointments(state.pickedDate);
  }, []);

  const fetchAppointments = date => {
    setState(s => ({...s, isFetching: true}));
    dispatch(
      request(
        apis.createAppointment,
        apis.serviceTypes.GET,
        {
          year: moment(date).format('YYYY'),
          month: moment(date).format('M'),
        },
        null,
        false,
        false,
        appointments =>
          setState(s => ({
            ...s,
            appointments,
            isFetching: false,
            markedDate: appointments.map(
              ({appointment_date}) => appointment_date,
            ),
          })),
      ),
    );
  };

  const RenderAppointments = () =>
    state.appointments.map(appointment => (
      <CardAppointmentCalender
        key={appointment.id}
        appointment={appointment}
        agentName={agent.name}
      />
    ));

  const RenderLoader = () =>
    state.isFetching ? (
      <Loader
        size={'small'}
        spinerColor={Colors.secondary.xGray}
        style={{
          justifyContent: 'flex-start',
          flexDirection: 'column-reverse',
          height: Metrics.widthRatio(130),
          width: Metrics.screenWidth,
        }}
      />
    ) : null;

  const RenderEmpty = () =>
    !state.appointments.length && !state.isFetching && <ListEmpty />;

  const onPickDate = () =>
    setState(s => ({
      ...s,
      isShowDatePicker: true,
    }));

  const onDateTimePicked = date => {
    setState(s => ({
      ...s,
      isShowDatePicker: false,
      pickedDate: date,
      isFetching: true,
      markedDate: [],
      appointments: [],
    }));
    fetchAppointments(date);
  };

  const onCancelDatePicker = () =>
    setState(s => ({...s, isShowDatePicker: false}));

  return (
    <View
      style={[
        styles.container,
        {backgroundColor: isFromDrawer ? undefined : 'white'},
      ]}>
      <BackHeader
        useDrawer={isFromDrawer ? true : false}
        onBack={isFromDrawer ? null : pop}
        title="Calendar"
        titleStyle={isFromDrawer ? {} : styles.headerTitle}
        containerStyle={isFromDrawer ? {} : styles.headerContainer}
      />

      <ScrollView
        bounces={false}
        contentContainerStyle={[
          styles.content,
          {
            backgroundColor: isFromDrawer ? undefined : Colors.primary.palegrey,
            // flex: isFromDrawer ? undefined : 1,
          },
        ]}>
        <View style={styles.header}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
            }}>
            <Text style={styles.heading}>
              {momentPickedDate.format('MMMM')}
            </Text>
            <ButtonView
              style={styles.containerCalenderPopBtn}
              onPress={onPickDate}>
              <Image
                style={styles.icCalenderPop}
                source={Images.icIconAwesomeCaretDown}
              />
            </ButtonView>
          </View>
          <Text style={styles.yearTxt}>{momentPickedDate.format('YYYY')}</Text>
        </View>

        <Calendar
          key={state.pickedDate}
          renderHeader={() => null}
          theme={{
            textDayHeaderFontWeight: '500',
            calendarBackground: 'transparent',
            textSectionTitleColor: Colors.primary.darkslateblue,
            textDayHeaderFontFamily: `Gibson-${Fonts.Type.Regular}`,
          }}
          hideArrows={true}
          current={momentPickedDate.format(constant.DB_DATE_FORMAT)}
          dayComponent={({date, state}) => {
            const isMarked = markedDate.includes(date.dateString);
            const isSelected = date.dateString == currentDate;
            return (
              <View
                style={[
                  styles.dateContainer,
                  isSelected && {
                    backgroundColor: `${Colors.primary.clearblue}21`,
                  },
                ]}>
                <View
                  style={[
                    styles.dot,
                    !isMarked && {backgroundColor: 'transparent'},
                  ]}
                />
                <Text
                  style={
                    state === 'disabled' ? styles.disableTxt : styles.activeTxt
                  }>
                  {date.day}
                </Text>
              </View>
            );
          }}
        />

        <View>
          <Text style={styles.listHeader}>
            {momentPickedDate.format('DD MMMM, YYYY')}
          </Text>
          <RenderAppointments />
          <RenderLoader />
          <RenderEmpty />
        </View>

        <DateTimePickerModal
          date={state.pickedDate}
          isVisible={state.isShowDatePicker}
          mode={'date'}
          onConfirm={onDateTimePicked}
          onCancel={onCancelDatePicker}
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingBottom: Metrics.xDoubleBaseMargin,
  },
  header: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Metrics.baseMargin,
    marginHorizontal: Metrics.baseMargin,
  },
  headerContainer: {
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: {
      width: 2,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 1.5,
    elevation: 5,
  },
  headerTitle: {
    ...AppStyles.gbRe(17, Colors.primary.dark),
    maxWidth: null,
    marginLeft: Metrics.baseMargin,
    flex: 1,
    textAlign: 'center',
    marginRight: Metrics.widthRatio(55),
  },
  heading: {
    ...Fonts.font({
      size: 30,
      color: Colors.primary.clearblue,
    }),
    letterSpacing: -0.6,
  },
  yearTxt: {
    ...Fonts.font({
      size: 14,
    }),
    letterSpacing: -0.28,
    opacity: 0.7,
  },
  activeTxt: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.purplishbrown,
    }),
    letterSpacing: -0.28,
    textAlign: 'center',
  },
  disableTxt: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.purplishbrown,
    }),
    opacity: 0.4,
    letterSpacing: -0.28,
    textAlign: 'center',
  },
  dateContainer: {
    width: 50,
    height: 50,
    borderRadius: 50,
    justifyContent: 'center',
  },
  listHeader: {
    ...Fonts.font({
      size: 24,
      color: Colors.primary.darkslateblue,
    }),
    marginLeft: Metrics.baseMargin,
    marginTop: Metrics.doubleBaseMargin,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 8,
    marginBottom: 4,
    alignSelf: 'center',
    backgroundColor: Colors.primary.clearblue,
  },
  containerCalenderPopBtn: {
    paddingHorizontal: Metrics.baseMargin,
    paddingVertical: Metrics.smallMargin,
  },
  icCalenderPop: {
    width: Metrics.widthRatio(19),
    height: Metrics.widthRatio(19),
    resizeMode: 'contain',
  },
});
