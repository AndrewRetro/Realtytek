import React from 'react';
import {View, Text, StyleSheet, ScrollView, Platform} from 'react-native';
import {BackHeader} from '../../components';
import {
  ButtonView,
  ImageHandler,
  ImageHandlerUpdated,
} from '../../reuseableComponents';
import {AppStyles, Colors, Fonts, Images, Metrics} from '../../theme';
import LinearGradient from 'react-native-linear-gradient';
import {navigate} from '../../services/NavigationService';
import {useSelector} from 'react-redux';

export default function () {
  const user = useSelector(({user}) => user.data);

  return (
    <View style={styles.container}>
      <BackHeader
        useDrawer
        title="My Account"
        rightBtn={() => navigate('EditProfile')}
        secondary
      />
      <ScrollView
        bounces={0}
        contentContainerStyle={{
          alignItems: 'center',
          paddingTop: Metrics.heightRatio(70),
          marginHorizontal: Metrics.baseMargin,
        }}
        showsVerticalScrollIndicator={false}>
        <View style={styles.wrapperProfileImg}>
          <ImageHandlerUpdated
            source={{uri: user.image_url}}
            style={AppStyles.roundImg(140)}
            isProfileImage
            isZoomViewerEnabled
          />
        </View>
        <Text style={styles.txtHeading}>{user.name}</Text>
        <LinearGradient
          style={{
            width: '100%',
            minHeight: Metrics.heightRatio(55),
            alignItems: 'center',
            flexDirection: 'row',
            marginTop: Metrics.heightRatio(50),
            padding: Metrics.smallMargin,
            borderRadius: Metrics.widthRatio(4),
          }}
          colors={['#f0f2fc', '#dce0f0']}>
          <ImageHandler source={Images.icName1} />
          <View style={{marginLeft: Metrics.widthRatio(25)}}>
            <Text
              style={{
                ...Fonts.font({
                  size: 12,
                  color: Colors.primary.clearblue,
                }),
              }}>
              Full Name
            </Text>
            <Text
              style={{
                ...Fonts.font({
                  size: 12,
                  color: Colors.primary.darkslateblue,
                }),
                marginTop: 5,
              }}>
              {user.name}
            </Text>
          </View>
        </LinearGradient>
        <LinearGradient
          style={{
            width: '100%',
            minHeight: Metrics.heightRatio(55),
            alignItems: 'center',
            flexDirection: 'row',
            marginTop: Metrics.baseMargin,
            padding: Metrics.smallMargin,
            borderRadius: Metrics.widthRatio(4),
          }}
          colors={['#f0f2fc', '#dce0f0']}>
          <ImageHandler source={Images.icEmail2} />
          <View style={{marginLeft: Metrics.widthRatio(25)}}>
            <Text
              style={{
                ...Fonts.font({
                  size: 12,
                  color: Colors.primary.clearblue,
                }),
              }}>
              Email
            </Text>
            <Text
              style={{
                ...Fonts.font({
                  size: 12,
                  color: Colors.primary.darkslateblue,
                }),
                marginTop: 5,
              }}>
              {user.email}
            </Text>
          </View>
        </LinearGradient>
        <LinearGradient
          style={{
            width: '100%',
            minHeight: Metrics.heightRatio(55),
            alignItems: 'center',
            flexDirection: 'row',
            marginTop: Metrics.baseMargin,
            padding: Metrics.smallMargin,
            borderRadius: Metrics.widthRatio(4),
            justifyContent: 'space-between',
          }}
          colors={['#f0f2fc', '#dce0f0']}>
          <View style={{flexDirection: 'row'}}>
            <ImageHandler source={Images.icPassword1} />
            <View style={{marginLeft: Metrics.widthRatio(25)}}>
              <Text
                style={{
                  ...Fonts.font({
                    size: 12,
                    color: Colors.primary.clearblue,
                  }),
                }}>
                Change Password
              </Text>
              <Text
                style={{
                  ...Fonts.font({
                    size: 50,
                    color: Colors.primary.darkslateblue,
                  }),
                  marginTop: Platform.OS === 'ios' ? -25 : -35,
                  marginLeft: Platform.OS === 'ios' ? -3 : 0,
                  letterSpacing: -5,
                }}>
                ........
              </Text>
            </View>
          </View>
          <ButtonView
            onPress={() => navigate('ChangePassword')}
            style={{padding: Metrics.smallMargin}}>
            <Text
              style={{
                ...Fonts.font({
                  size: 12,
                  color: Colors.primary.darkslateblue,
                }),
                marginTop: 5,
              }}>
              Change
            </Text>
          </ButtonView>
        </LinearGradient>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  txtHeading: {
    ...Fonts.font({
      size: 24,
      type: Fonts.Type.SemiBold,
      color: '#2d2d2d',
    }),
    marginTop: Metrics.heightRatio(40),
  },
  wrapperProfileImg: {
    ...AppStyles.roundImg(140),
    ...AppStyles.heavyShadow,
  },
});
