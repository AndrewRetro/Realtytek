import React, {useEffect} from 'react';
import {View, Text} from 'react-native';

import {FlatListHandler} from '@reuseableComponents';
import {ListingCards} from '@components';
import {Images} from '@theme';
import {useDispatch, useSelector} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';
import constant from '@constants';
import {SELLING_UNDER_CONTRACT} from '@actionTypes';

const dummyData = [
  {
    id: '1',
    address: '235 Elm Street, Los Angeles, CA',
    amount: '350000',
    image_url: Images.icPlace,
  },
];

export default SellingUnderContractList = () => {
  const dispatch = useDispatch();
  const sellingUnderContract = useSelector(
    ({sellingUnderContract}) => sellingUnderContract,
  );

  useEffect(() => {
    fetchUnderContractHomes();
  }, []);

  const fetchUnderContractHomes = (isConcat = false, page = 1) => {
    dispatch(
      request(
        apis.createProperty,
        apis.serviceTypes.GET,
        {
          page,
          limit: 10,
          property_type: constant.UNDER_CONTRACT,
        },
        SELLING_UNDER_CONTRACT,
        false,
        isConcat,
      ),
    );
  };

  renderProperties = ({item}) => (
    <ListingCards item={item} isNavigateToContractDetails />
  );

  return (
    <View style={styles.container}>
      <FlatListHandler
        fetchRequest={fetchUnderContractHomes}
        data={sellingUnderContract.data}
        isFetching={sellingUnderContract.isFetching}
        meta={sellingUnderContract.meta}
        showsHorizontalScrollIndicator={false}
        keyExtractor={item => item.id}
        renderItem={renderProperties}
      />
    </View>
  );
};

const styles = {
  container: {
    flex: 1,
  },
};
