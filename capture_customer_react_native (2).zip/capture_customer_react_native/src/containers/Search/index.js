import React from 'react';
import {View, StyleSheet, TextInput, Image} from 'react-native';

import {ListingCards, ShadowHeader} from '../../components';
import {FlatListHandler} from '../../reuseableComponents';
import {navigate, pop} from '../../services/NavigationService';
import {AppStyles, Images, Colors, Metrics} from '../../theme';

const dummyData = [
  {
    id: '1',
    name: 'Luxury Villa Available @ Maddison Valley',
    address: '235 Elm Street, Los Angeles, CA',
    amount: '350000',
    image_url: Images.icPlace,
  },
  {
    id: '2',
    name: 'Luxury Villa Available @ Maddison Valley',
    address: '235 Elm Street, Los Angeles, CA',
    amount: '350000',
    image_url: Images.icPlace2,
  },
];

export default function () {
  React.useEffect(() => {}, []);

  const Search = () => (
    <View style={styles.containerSearch}>
      <Image source={Images.icSearch} />
      <TextInput placeholder="Search here..." style={styles.txtSearch} />
    </View>
  );

  return (
    <View style={styles.container}>
      <ShadowHeader onBack={pop} useShadows title="Search" />
      <Search />
      <FlatListHandler
        data={dummyData}
        renderItem={({item}) => (
          <ListingCards
            onPress={() => navigate('PropertyDetails')}
            item={item}
            style={{marginTop: 0}}
          />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.primary.palegrey,
  },
  containerSearch: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.primary.white,
    padding: Metrics.smallMargin * 1.5,
    margin: Metrics.baseMargin,
    marginTop: Metrics.smallMargin,
    ...AppStyles.heavyShadow,
    borderRadius: Metrics.widthRatio(4),
  },
  txtSearch: {
    flex: 1,
    ...AppStyles.gbRe(14, Colors.primary.darkslateblue),
    marginLeft: Metrics.baseMargin,
  },
});
