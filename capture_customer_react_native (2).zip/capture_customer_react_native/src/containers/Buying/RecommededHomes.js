import React, {useEffect} from 'react';
import {View, StyleSheet} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import PropTypes from 'prop-types';

import {ListingCards, ShadowHeader} from '../../components';
import {FlatListHandler} from '../../reuseableComponents';

import {pop} from '@nav';
import {Metrics} from '../../theme';

import apis from '@apis';
import {RECOMMENDED_HOMES} from '@actionTypes';
import {request} from '@serviceAction';

const RecommendedHomes = ({isHorizontal, buyingQueryId, route}) => {
  const dispatch = useDispatch();
  const recommendedHomes = useSelector(
    ({recommendedHomes}) => recommendedHomes,
  );

  useEffect(() => {
    fetchRecommendedHomes();
  }, []);

  const fetchRecommendedHomes = (isConcat = false, page = 1) => {
    dispatch(
      request(
        apis.buyingQueryRecommendedHomes,
        apis.serviceTypes.GET,
        {
          page,
          limit: 10,
          buyer_id: isHorizontal ? buyingQueryId : route.params.buyingQueryId,
        },
        RECOMMENDED_HOMES,
        false,
        isConcat,
      ),
    );
  };

  const containerStyle = {
    ...(isHorizontal && {height: Metrics.widthRatio(210)}),
    ...(!isHorizontal && {flex: 1}),
  };

  const cardStyle = {
    margin: isHorizontal ? 0 : Metrics.baseMargin,
  };

  const imgStyle = isHorizontal
    ? {
        width: Metrics.screenWidth - Metrics.widthRatio(80),
        height: Metrics.widthRatio(145),
      }
    : {};

  renderProperties = ({item}) => {
    return (
      <ListingCards
        style={cardStyle}
        imgStyle={imgStyle}
        item={{...item, ...item.property, review: item.review}}
        buyingQueryId={
          isHorizontal ? buyingQueryId : route.params.buyingQueryId
        }
      />
    );
  };

  const renderItemSeparator = () => (
    <View style={{width: Metrics.baseMargin}} />
  );

  const contentContainerStyle = isHorizontal
    ? {paddingRight: Metrics.baseMargin}
    : {};

  return (
    <View style={containerStyle}>
      {!isHorizontal && (
        <ShadowHeader onBack={pop} useShadows title="Recommended Homes" />
      )}
      <FlatListHandler
        fetchRequest={isHorizontal ? null : fetchRecommendedHomes}
        data={recommendedHomes.data}
        meta={recommendedHomes.meta}
        isFetching={recommendedHomes.isFetching}
        renderItem={renderProperties}
        horizontal={isHorizontal}
        bounces={isHorizontal ? false : true}
        ItemSeparatorComponent={renderItemSeparator}
        contentContainerStyle={contentContainerStyle}
      />
    </View>
  );
};

export default RecommendedHomes;

RecommendedHomes.propTypes = {
  isHorizontal: PropTypes.bool,
  buyingQueryId: PropTypes.number,
};

RecommendedHomes.defaultProps = {
  isHorizontal: false,
  buyingQueryId: -1,
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
