import React, {forwardRef, useImperativeHandle, useRef, useState} from 'react';
import {View, Text, StyleSheet, ScrollView, TextInput} from 'react-native';
import PropTypes from 'prop-types';
import {Rating} from 'react-native-ratings';
import _ from 'lodash';

import {AbsoluteHeader, BigBtn, SmallBtn, PopupModal} from '@components';
import {
  ImageHandler,
  ImageHandlerUpdated,
  ButtonView,
} from '@reuseableComponents';
import {navigate, pop} from '@nav';
import {AppStyles, Colors, Fonts, Images, Metrics} from '@theme';
import apis from '@apis';
import utility from '@utils';
import {useDispatch, useSelector} from 'react-redux';
import {request} from '@serviceAction';
import {generalSaveAction} from '@serviceAction';
import {TOURED_HOMES} from '@actionTypes';

const PropertyDetails = ({route}) => {
  const {enableInvite, property, buyingQueryId, touredHomeId} = route.params;
  const review = useRef();

  const touredHomeObj = useSelector(({touredHomes}) =>
    touredHomes.data.find(home => home.property_id == property.property_id),
  );

  const dispatch = useDispatch();

  const [state, setState] = useState({
    isVisible: false,
    isRating: property?.rating > 0 ? true : false,
  });
  const {isVisible} = state;

  const onLink = website => () => utility.openLink(website);

  const onRate = () =>
    state.isRating ? onCreateReview() : setState(s => ({...s, isRating: true}));

  const onCreateReview = () => {
    const isReviewSubmitted = review.current.getRating();
    const isFeedbackSubmitted = review.current.getFeedback().length;

    if (!isReviewSubmitted || !isFeedbackSubmitted) {
      if (!isReviewSubmitted) review.current.setRatingErr();
      if (!isFeedbackSubmitted) review.current.setFeedbackErr();
    } else {
      dispatch(
        request(
          apis.rating,
          apis.serviceTypes.POST,
          {
            review: review.current.getFeedback(),
            rating: review.current.getRating(),
            buyer_id: buyingQueryId,
            property_id: touredHomeId, // sending id of toured home in property_id
          }, // instead of property_id as told by backend developer
          null,
          true,
          false,
          () => {
            dispatch(
              generalSaveAction(TOURED_HOMES.UPDATE, {
                ..._.cloneDeep(touredHomeObj),
                rating: review.current.getRating(),
                review: review.current.getFeedback(),
              }),
            );
            pop();
            utility.showFlashMessage('Successfully reviewd', 'success');
          },
        ),
      );
    }
  };

  const {
    state: property_state,
    address,
    city,
    zipcode,
    title,
    mls_detail,
    asking_price,
    property_type,
    rating,
    review: property_review,
  } = property;

  return (
    <ScrollView
      bounces={0}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}>
      <View>
        <ImageHandlerUpdated
          style={styles.cover}
          source={{uri: property.image_url}}
        />
        <PopupModal
          onClose={() =>
            setState(prevState => ({...prevState, isVisible: false}))
          }
          isVisible={isVisible}
        />
        <AbsoluteHeader
          title="Property Detail"
          showRight={true}
          rightIcon={-1}
        />
        <View
          style={{
            marginHorizontal: Metrics.baseMargin,
          }}>
          <Tag
            {...{
              t1: 'Community/Building',
              d1: title,
              t2: 'Price',
              d2: utility.formateCurrency(asking_price),
            }}
          />

          <Tag
            {...{
              t1: 'Address',
              d1: address,
              t2: 'City',
              d2: city,
            }}
          />

          <Tag
            {...{
              t1: 'State',
              d1: property_state,
              t2: 'Zipcode',
              d2: zipcode,
            }}
          />

          <Text style={styles.tileTxt2}>
            {enableInvite ? 'Offer Status' : 'Type'}
          </Text>
          <Text style={styles.tileDesc2}>
            {enableInvite ? 'Accepted' : property.property_type}
          </Text>

          <Text style={styles.tileTxt2}>MLS Details</Text>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              marginTop: 8,
            }}>
            <ImageHandler source={Images.icLink} />
            <ButtonView onPress={onLink(property.mls_detail)}>
              <Text style={styles.linkTxt}>{property.mls_detail}</Text>
            </ButtonView>
          </View>

          {state.isRating && (
            <Review
              ref={review}
              review={property.review}
              rating={property.rating}
            />
          )}
        </View>
      </View>
      {enableInvite ? (
        property?.rating > 0 ? null : (
          <SmallBtn
            style={{width: '45%', marginTop: Metrics.doubleBaseMargin}}
            useBold
            alignCenter
            title={state.isRating ? 'Save' : 'Rate'}
            onPress={onRate}
            bgColor={Colors.primary.clearblue}
          />
        )
      ) : (
        <BigBtn
          style={{width: '70%', alignSelf: 'center'}}
          useMargin
          useSmall
          title="Schedule Appointment"
          onPress={() => {
            navigate('CreateAppointment', {
              buyingQueryId,
              propertyId: property.id,
            });
          }}
          bgColor={Colors.primary.clearblue}
        />
      )}
    </ScrollView>
  );
};

const Tag = ({t1, d1, t2, d2, rating}) => (
  <View style={{flexDirection: 'row'}}>
    <View style={{flex: 0.5}}>
      <Text style={styles.tileTxt2}>{t1}</Text>
      <Text style={styles.tileDesc2}>{d1}</Text>
    </View>

    <View style={{flex: 0.5}}>
      <Text style={styles.tileTxt2}>{t2}</Text>
      {!!d2 && <Text style={styles.tileDesc2}>{d2}</Text>}
      {rating !== 'null' && rating !== undefined && (
        <Rating useBig style={styles.tileDesc2} rating={rating} />
      )}
    </View>
  </View>
);

export default PropertyDetails;

const Review = forwardRef(({review, rating}, ref) => {
  const [state, setState] = useState({
    rating,
    feedback: review ?? '',
    isRatingErr: false,
    isFeedbackErr: false,
  });

  useImperativeHandle(ref, () => ({
    setFeedbackErr: () => setState(s => ({...s, isFeedbackErr: true})),
    setRatingErr: () => setState(s => ({...s, isRatingErr: true})),
    getRating: () => state.rating,
    getFeedback: () => state.feedback,
  }));

  const onRatingFinihed = rating =>
    setState(s => ({...s, rating, isRatingErr: false}));

  return (
    <View>
      <Text style={styles.tileTxt2}>Rating</Text>
      <Rating
        type="custom"
        ratingCount={5}
        startingValue={state.rating}
        imageSize={25}
        showRating={false}
        style={{
          alignItems: 'flex-start',
          backgroundColor: Colors.secondary.searchTextField,
          marginTop: Metrics.smallMargin,
        }}
        tintColor={Colors.primary.palegrey}
        ratingColor={Colors.primary.theme}
        ratingBackgroundColor={Colors.primary.verylightpink}
        onFinishRating={onRatingFinihed}
        readonly={rating > 0 ? true : false}
      />

      {state.isRatingErr && (
        <Text
          style={{
            ...AppStyles.gbRe(12, Colors.primary.vermillion),
            marginTop: Metrics.smallMargin,
          }}>
          Rating is required
        </Text>
      )}

      <Text style={styles.tileTxt2}>Feedback</Text>
      <TextInput
        placeholder="Write your feedback"
        style={styles.inputFeedback}
        multiline={true}
        value={state.feedback}
        onChangeText={feedback =>
          setState(s => ({...s, feedback, isFeedbackErr: false}))
        }
        editable={rating > 0 ? false : true}
      />
      {state.isFeedbackErr && (
        <Text
          style={{
            ...AppStyles.gbRe(12, Colors.primary.vermillion),
            marginTop: Metrics.smallMargin,
          }}>
          Feedback is required
        </Text>
      )}
    </View>
  );
});

PropertyDetails.propTypes = {
  property: PropTypes.object,
  enableInvite: PropTypes.bool,
};

PropertyDetails.defaultProps = {
  property: {},
  enableInvite: false,
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  cover: {
    width: Metrics.screenWidth,
    height: Metrics.heightRatio(308),
  },
  content: {
    paddingBottom: Metrics.xDoubleBaseMargin,
    flexGrow: 1,
    justifyContent: 'space-between',
    backgroundColor: Colors.primary.palegrey,
  },
  btn: {
    width:
      (Metrics.screenWidth - 2 * Metrics.baseMargin - 2 * Metrics.smallMargin) /
      3,
  },
  btnContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Metrics.doubleBaseMargin,
  },
  actionBtn: {
    marginVertical: Metrics.xDoubleBaseMargin,
    width: (Metrics.screenWidth - Metrics.xDoubleBaseMargin) / 2,
  },
  tileTxt2: {
    ...Fonts.font({
      size: 12,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: Metrics.doubleBaseMargin,
  },
  tileDesc2: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginTop: 8,
  },
  linkTxt: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.Italic,
      color: Colors.primary.clearblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
  ratingWrapper: {
    width: '50%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    marginTop: Metrics.doubleBaseMargin,
  },
  inputFeedback: {
    backgroundColor: 'white',
    borderRadius: Metrics.widthRatio(2),
    marginTop: Metrics.smallMargin,
    paddingHorizontal: Metrics.smallMargin,
    paddingTop: Metrics.widthRatio(6),
    paddingBottom: Metrics.smallMargin,
    minHeight: Metrics.widthRatio(100),
    maxHeight: Metrics.widthRatio(250),
  },
});
