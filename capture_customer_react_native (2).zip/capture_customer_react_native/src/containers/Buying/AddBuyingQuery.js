import React, {useRef} from 'react';
import {View, StyleSheet, ScrollView} from 'react-native';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import moment from 'moment';

import {ShadowHeader, SmallBtn} from '@components';
import {
  MaterialTextField,
  BottomActionSheet,
  FormHandlerUpdated,
} from '@reuseableComponents';
import {pop} from '@nav';
import {Colors, Images, Metrics} from '@theme';

import {useDispatch, useSelector} from 'react-redux';
import constant from '@constants';
import {request} from '@serviceAction';
import apis from '@apis';
import {BUYING_QUERIES} from '@actionTypes';
import {generalSaveAction} from '@serviceAction';

export default function () {
  const formHandlerRef = useRef();
  const bottomSheetRef = useRef();
  const inputPreApprovedRef = useRef();
  const inputPropertyTypeRef = useRef();
  const inputFirstTimeBuyRef = useRef();
  const inputMovingDateRef = useRef();

  const dispatch = useDispatch();

  const user = useSelector(({user}) => user.data);

  const [state, setState] = React.useState({
    movingDate: new Date(),
    isShowDatePicker: false,
    isDatePicked: false,
    isPropertyTypeSelection: false,
    isFirstTimeBuySelection: false,
    isPreApprovedSelection: false,
    isImageSelection: false,
    selectedPropertyTypeIndex: null,
    selectedPreApprovedIndex: null,
    selectedFirstTimeBuyIndex: null,
  });

  const onSubmitForm = () => {
    let isError = false;

    const data = formHandlerRef.current.onSubmitForm();

    if (!state.selectedFirstTimeBuyIndex) {
      isError = true;
      inputFirstTimeBuyRef.current.setError(true, 'First time buy is required');
    }

    if (!state.selectedPreApprovedIndex) {
      isError = true;
      inputPreApprovedRef.current.setError(
        true,
        'Pre approved status is required',
      );
    }

    if (state.selectedPropertyTypeIndex == null) {
      isError = true;
      inputPropertyTypeRef.current.setError(true, 'Property type is required');
    }

    if (!state.isDatePicked) {
      isError = true;
      inputMovingDateRef.current.setError(true, 'Moving date is required');
    }

    if (data && !isError) createProperty(data);
  };

  const createProperty = data => {
    const payload = new FormData();
    Object.keys(data).map(key => payload.append(key, data[key]));
    payload.append(
      'house_type',
      constant.PROPERTY_TYPES_OPTIONS[state.selectedPropertyTypeIndex],
    );
    payload.append(
      'first_time_buyer',
      constant.FIRST_TIME_BUYER_OPTIONS[state.selectedFirstTimeBuyIndex],
    );
    payload.append(
      'pre_approved',
      constant.PRE_APPROVED_OPTIONS[state.selectedPreApprovedIndex],
    );

    payload.append(
      'move_date',
      moment(state.movingDate).format(constant.DB_DATE_FORMAT),
    );

    dispatch(
      request(
        apis.createBuyer,
        apis.serviceTypes.POST,
        payload,
        null,
        true,
        false,
        buyingQuery => {
          dispatch(
            generalSaveAction(BUYING_QUERIES.ADD, {
              ...buyingQuery,
              isAddAtZero: true,
            }),
          );
          pop();
        },
      ),
    );
  };

  const cbOnPressActionSheet = index => {
    setState(s => {
      if (index && s.isFirstTimeBuySelection) {
        inputFirstTimeBuyRef.current.setError(false);
        return {...s, selectedFirstTimeBuyIndex: index};
      }
      if (index && s.isPreApprovedSelection) {
        inputPreApprovedRef.current.setError(false);
        return {...s, selectedPreApprovedIndex: index};
      }
      if (s.isPropertyTypeSelection) {
        if (index !== constant.PROPERTY_TYPES_OPTIONS.length - 1) {
          inputPropertyTypeRef.current.setError(false);
          return {...s, selectedPropertyTypeIndex: index};
        }
      }

      return s;
    });
  };

  const getBottomSheetOptions = () => {
    if (state.isFirstTimeBuySelection) return constant.FIRST_TIME_BUYER_OPTIONS;
    if (state.isPropertyTypeSelection) return constant.PROPERTY_TYPES_OPTIONS;
    if (state.isPreApprovedSelection) return constant.PRE_APPROVED_OPTIONS;
    return ['Cancel'];
  };

  const showActionSheet = sheetToOpen => () => {
    setState(prevState => {
      const state = {
        ...prevState,
        isFirstTimeBuySelection: false,
        isPreApprovedSelection: false,
        isPropertyTypeSelection: false,
        isImageSelection: false,
      };
      state[sheetToOpen] = true;
      return state;
    });
    setTimeout(bottomSheetRef.current.showActionSheet, 200);
  };

  return (
    <View style={styles.container}>
      <ShadowHeader onBack={pop} title="Add Buying Criteria" useShadows />
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}>
        <FormHandlerUpdated ref={formHandlerRef}>
          {(refCollector, onSubmitEditing) => {
            const {text, number} = FormHandlerUpdated.INPUTS(
              refCollector,
              onSubmitEditing,
            );
            return (
              <>
                <MaterialTextField
                  style={{width: '100%'}}
                  label="Agent"
                  placeholder="Select Agent"
                  rightIcon={Images.icContactList}
                  value={user.agent.name}
                  editable={false}
                />
                <MaterialTextField
                  {...text({identifier: 'requirements'})}
                  style={{width: '100%'}}
                  label="Requirements"
                  placeholder="Enter details here..."
                  multiline
                  useBigSpace
                  error="Requirements are required"
                  onSubmitEditing={null}
                />
                <MaterialTextField
                  {...number({identifier: 'price'})}
                  style={{width: '100%'}}
                  label="Price"
                  placeholder="Enter price"
                  error="Price is required"
                  isPriceInput
                />
                <MaterialTextField
                  ref={inputPropertyTypeRef}
                  style={{width: '100%'}}
                  label="House Type"
                  placeholder="Select house type"
                  editable={false}
                  rightIcon={Images.icDropdown}
                  onRightPress={showActionSheet('isPropertyTypeSelection')}
                  value={
                    state.selectedPropertyTypeIndex !== null
                      ? constant.PROPERTY_TYPES_OPTIONS[
                          state.selectedPropertyTypeIndex
                        ]
                      : undefined
                  }
                />
                <MaterialTextField
                  ref={inputMovingDateRef}
                  style={{width: '100%'}}
                  label="Moving Date"
                  placeholder={moment(new Date()).format(
                    constant.DB_DATE_FORMAT,
                  )}
                  editable={false}
                  rightIcon={Images.icCalendarField}
                  onRightPress={() =>
                    setState(s => ({...s, isShowDatePicker: true}))
                  }
                  value={
                    state.isDatePicked
                      ? moment(state.movingDate).format(constant.DB_DATE_FORMAT)
                      : undefined
                  }
                />
                <MaterialTextField
                  ref={inputFirstTimeBuyRef}
                  style={{width: '100%'}}
                  label="First time Buyer"
                  placeholder="Yes"
                  editable={false}
                  rightIcon={Images.icDropdown}
                  onRightPress={showActionSheet('isFirstTimeBuySelection')}
                  value={
                    state.selectedFirstTimeBuyIndex
                      ? constant.FIRST_TIME_BUYER_OPTIONS[
                          state.selectedFirstTimeBuyIndex
                        ]
                      : undefined
                  }
                />

                <MaterialTextField
                  ref={inputPreApprovedRef}
                  style={{width: '100%'}}
                  label="Pre Approved"
                  placeholder="Yes"
                  editable={false}
                  rightIcon={Images.icDropdown}
                  onRightPress={showActionSheet('isPreApprovedSelection')}
                  value={
                    state.selectedPreApprovedIndex
                      ? constant.PRE_APPROVED_OPTIONS[
                          state.selectedPreApprovedIndex
                        ]
                      : undefined
                  }
                />
                {state.selectedPreApprovedIndex == 1 && (
                  <MaterialTextField
                    {...text({identifier: 'company_name'})}
                    style={{width: '48%'}}
                    label="Company Name"
                    placeholder="Enter company name"
                    error="Company name is required"
                  />
                )}
                {state.selectedPreApprovedIndex == 1 && (
                  <MaterialTextField
                    {...text({identifier: 'amount'})}
                    style={{width: '48%'}}
                    label="Amount"
                    placeholder="Enter amount"
                    error="Amount is required"
                    keyboardType="numeric"
                    isPriceInput
                  />
                )}
              </>
            );
          }}
        </FormHandlerUpdated>
        <SmallBtn
          style={{width: '48%', marginTop: Metrics.xDoubleBaseMargin}}
          bgColor={Colors.primary.darkslateblue}
          useBold
          title="Cancel"
          onPress={pop}
        />
        <SmallBtn
          style={{width: '48%', marginTop: Metrics.xDoubleBaseMargin}}
          bgColor={Colors.primary.clearblue}
          useBold
          title="Add"
          onPress={onSubmitForm}
        />
      </ScrollView>
      <DateTimePickerModal
        date={state.movingDate}
        isVisible={state.isShowDatePicker}
        mode="date"
        onConfirm={movingDate => {
          inputMovingDateRef.current.setError(false);
          setState(s => ({
            ...s,
            isDatePicked: true,
            isShowDatePicker: false,
            movingDate,
          }));
        }}
        onCancel={() => setState(s => ({...s, isShowDatePicker: false}))}
        minimumDate={new Date()}
      />
      <BottomActionSheet
        ref={bottomSheetRef}
        options={getBottomSheetOptions()}
        cbOnPressActionSheet={cbOnPressActionSheet}
        cancelButtonIndex={
          state.isPropertyTypeSelection
            ? constant.PROPERTY_TYPES_OPTIONS.length - 1
            : 0
        }
        destructiveButtonIndex={
          state.isPropertyTypeSelection
            ? constant.PROPERTY_TYPES_OPTIONS.length - 1
            : 0
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
    paddingBottom: Metrics.xDoubleBaseMargin,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
});
