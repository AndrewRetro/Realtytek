import React from 'react';
import {View} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import PropTypes from 'prop-types';

import {ListingCards, ShadowHeader} from '@components';
import {FlatListHandler} from '@reuseableComponents';

import apis from '@apis';
import {pop} from '@nav';
import {request} from '@serviceAction';
import {Metrics} from '@theme';
import {TOURED_HOMES} from '@actionTypes';

const TouredHomes = ({isHorizontal, idBuyingQuery, route}) => {
  const dispatch = useDispatch();
  const touredHomes = useSelector(({touredHomes}) => touredHomes);

  React.useEffect(() => {
    !touredHomes.data.length && fetchTouredHomes();
  }, []);

  const fetchTouredHomes = (isConcat = false, page = 1) => {
    dispatch(
      request(
        apis.touredHomes,
        apis.serviceTypes.GET,
        {
          page,
          limit: 10,
          buyer_id: isHorizontal ? idBuyingQuery : route.params.idBuyingQuery,
        },
        TOURED_HOMES,
        false,
        isConcat,
        null,
        null,
        TOURED_HOMES,
      ),
    );
  };

  const cardStyle = {
    margin: isHorizontal ? 0 : Metrics.baseMargin,
  };

  const imgStyle = isHorizontal
    ? {
        width: Metrics.screenWidth - Metrics.widthRatio(80),
        height: Metrics.widthRatio(145),
      }
    : {};

  const renderProperties = ({item}) => {
    return (
      <ListingCards
        item={{
          ...item,
          ...item.property,
          review: item.review,
          rating: item.rating,
        }}
        style={cardStyle}
        imgStyle={imgStyle}
        enableInvite
        buyingQueryId={
          isHorizontal ? idBuyingQuery : route.params.idBuyingQuery
        }
        isShowRating
        touredHomeId={item.id}
      />
    );
  };

  const renderItemSeparator = () => (
    <View style={{width: Metrics.baseMargin}} />
  );

  const containerStyle = {
    ...(isHorizontal && {height: Metrics.widthRatio(210)}),
    ...(!isHorizontal && {flex: 1}),
  };

  const contentContainerStyle = {
    ...(isHorizontal && {paddingRight: Metrics.baseMargin}),
  };

  return (
    <View style={containerStyle}>
      {!isHorizontal && (
        <ShadowHeader onBack={pop} useShadows title="Toured Homes" />
      )}
      <FlatListHandler
        fetchRequest={isHorizontal ? null : fetchTouredHomes}
        data={touredHomes.data}
        meta={touredHomes.meta}
        isFetching={touredHomes.isFetching}
        renderItem={renderProperties}
        horizontal={isHorizontal}
        bounces={isHorizontal ? false : true}
        ItemSeparatorComponent={renderItemSeparator}
        contentContainerStyle={contentContainerStyle}
      />
    </View>
  );
};

TouredHomes.propTypes = {
  isHorizontal: PropTypes.bool,
  idBuyingQuery: PropTypes.number,
};

TouredHomes.defaultProps = {
  isHorizontal: false,
  idBuyingQuery: -1,
};

export default TouredHomes;

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//   },
// });
