import React, {useRef, useState} from 'react';
import {View, Text, ScrollView, ActivityIndicator} from 'react-native';
import DateTimePickerModal from 'react-native-modal-datetime-picker';

import {BigBtn, ShadowHeader} from '../../components';
import {
  ImageHandler,
  MaterialTextField,
  ButtonView,
} from '../../reuseableComponents';
import {Colors, Fonts, Images, Metrics} from '../../theme';
import {Calendar} from 'react-native-calendars';
import moment from 'moment';
import {pop} from '../../services/NavigationService';
import constant from '@constants';
import {useDispatch} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';
import {generalSaveAction} from '@serviceAction';
import {APPOINTMENTS_PENDING} from '@actionTypes';
import utility from '@utils';

export default function ({route}) {
  const dispatch = useDispatch();

  const inputDate = useRef();
  const inputTime = useRef();

  const [state, setState] = useState({
    currentDate: moment(new Date()).format(constant.DB_DATE_FORMAT),
    markedDate: [],
    pickedDate: new Date(),
    isShowDatePicker: false,
    isDatePicked: false,
    pickedTime: undefined,
    isDatePickerMode: true,
    isFetchingAppointments: false,
  });

  const {currentDate, markedDate} = state;

  const fetchAppointmentsForMonth = date => {
    const pickedDate = moment(date);
    dispatch(
      request(
        apis.createAppointment,
        apis.serviceTypes.GET,
        {
          year: pickedDate.format('YYYY'),
          month: pickedDate.format('M'),
        },
        null,
        false,
        false,
        fetchedAppointments,
      ),
    );
  };

  const fetchedAppointments = appointments => {
    if (appointments.length) {
      setState(s => ({
        ...s,
        isFetchingAppointments: false,
        markedDate: appointments.map(({appointment_date}) => appointment_date),
      }));
    } else {
      setState(s => ({...s, isFetchingAppointments: false}));
    }
  };

  const createAppointment = () => {
    dispatch(
      request(
        apis.createAppointment,
        apis.serviceTypes.POST,
        {
          property_id: route.params.propertyId,
          buyer_id: route.params.buyingQueryId,
          appointment_date: moment(state.pickedDate).format(
            constant.DB_DATE_FORMAT,
          ),
          appointment_time: moment(state.pickedTime).format('HH:mm:ss'),
        },
        null,
        true,
        false,
        appointment => {
          utility.showFlashMessage(
            'Appointment created successfully',
            'success',
          );
          dispatch(
            generalSaveAction(APPOINTMENTS_PENDING.ADD, {
              ...appointment,
              isAddAtZero: true,
            }),
          );
          pop(2);
        },
      ),
    );
  };

  const onPickDate = () =>
    setState(s => ({
      ...s,
      isShowDatePicker: true,
      isDatePickerMode: true,
    }));

  const onPickTime = () =>
    setState(s => ({
      ...s,
      isShowDatePicker: true,
      isDatePickerMode: false,
    }));

  const onDateTimePicked = date => {
    if (state.isDatePickerMode) {
      setState(s => ({
        ...s,
        isDatePicked: true,
        isShowDatePicker: false,
        pickedDate: date,
        isFetchingAppointments: true,
        markedDate: [],
      }));
      inputDate.current.setError(false);
      fetchAppointmentsForMonth(date);
    } else {
      setState(s => ({
        ...s,
        pickedTime: date,
        isShowDatePicker: false,
      }));
      inputTime.current.setError(false);
    }
  };

  const onAppointment = () => {
    if (!state.isDatePicked)
      inputDate.current.setError(true, 'Appointment date is required');

    if (!state.pickedTime)
      inputTime.current.setError(true, 'Appointment time is required');

    if (state.isDatePicked && state.pickedTime) createAppointment();
  };

  const onCancelDatePicker = () =>
    setState(s => ({...s, isShowDatePicker: false}));

  return (
    <View style={styles.container}>
      <ShadowHeader useShadows onBack={pop} title="Calendar" />
      <ScrollView contentContainerStyle={styles.content}>
        <View>
          <View style={styles.header}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <Text style={styles.heading}>
                {moment(state.pickedDate).format('MMMM')}
              </Text>
              <ButtonView onPress={onPickDate} style={styles.wrapperDateArrow}>
                <ImageHandler
                  style={{marginLeft: Metrics.baseMargin}}
                  source={Images.icIconAwesomeCaretDown}
                />
              </ButtonView>
              <View style={{flex: 1}} />

              {state.isFetchingAppointments && (
                <ActivityIndicator color="grey" />
              )}
            </View>
            <Text style={styles.yearTxt}>
              {moment(state.pickedDate).format('YYYY')}
            </Text>
          </View>

          <Calendar
            key={state.pickedDate}
            renderHeader={() => null}
            theme={styles.themeCalender}
            hideArrows={true}
            current={moment(state.pickedDate).format('yyyy-MM-DD')}
            dayComponent={({date, state}) => {
              const isMarked = markedDate.includes(date.dateString);
              const isSelected = date.dateString == currentDate;
              return (
                <View
                  style={[
                    styles.dateContainer,
                    isSelected && {
                      backgroundColor: `${Colors.primary.clearblue}21`,
                    },
                  ]}>
                  <View
                    style={[
                      styles.dot,
                      !isMarked && {backgroundColor: 'transparent'},
                    ]}
                  />
                  <Text
                    style={
                      state === 'disabled'
                        ? styles.disableTxt
                        : styles.activeTxt
                    }>
                    {date.day}
                  </Text>
                </View>
              );
            }}
          />
          <View
            style={{
              marginHorizontal: Metrics.baseMargin,
              marginTop: Metrics.baseMargin,
            }}>
            <View
              style={{
                borderTopWidth: 1,
                borderColor: Colors.primary.lightgreyblue,
                paddingTop: Metrics.baseMargin,
              }}>
              <View
                style={{flexDirection: 'row', justifyContent: 'space-between'}}>
                <MaterialTextField
                  ref={inputDate}
                  error="Appointment date is required"
                  editable={false}
                  style={styles.txtTime}
                  label="Select Date"
                  placeholder="17/03/2021"
                  rightIcon={Images.icCalendarField}
                  onRightPress={onPickDate}
                  value={
                    state.isDatePicked
                      ? moment(state.pickedDate)
                          .format(constant.DISPLAY_DATE_FORMAT)
                          .toString()
                      : undefined
                  }
                />
                <MaterialTextField
                  ref={inputTime}
                  error="Appointment time is required"
                  editable={false}
                  style={styles.txtTime}
                  label="Select Time"
                  placeholder={moment(new Date()).format(
                    constant.DISPLAY_TIME_FORMAT,
                  )}
                  rightIcon={Images.icTime}
                  onRightPress={onPickTime}
                  value={
                    state.pickedTime
                      ? moment(state.pickedTime)
                          .format(constant.DISPLAY_TIME_FORMAT)
                          .toString()
                      : undefined
                  }
                />
              </View>
            </View>
          </View>
        </View>

        <BigBtn
          style={{width: '70%', alignSelf: 'center'}}
          useMargin
          useSmall
          title="Confirm Appointment"
          onPress={onAppointment}
          bgColor={Colors.primary.clearblue}
        />
      </ScrollView>
      <DateTimePickerModal
        date={state.pickedDate}
        isVisible={state.isShowDatePicker}
        mode={state.isDatePickerMode ? 'date' : 'time'}
        onConfirm={onDateTimePicked}
        onCancel={onCancelDatePicker}
        minimumDate={new Date()}
      />
    </View>
  );
}

const styles = {
  container: {
    flex: 1,
  },
  content: {
    flexGrow: 1,
    justifyContent: 'space-between',
    paddingBottom: Metrics.xDoubleBaseMargin,
  },
  header: {
    justifyContent: 'space-between',
    marginTop: Metrics.baseMargin,
    marginHorizontal: Metrics.baseMargin,
  },
  heading: {
    ...Fonts.font({
      size: 30,
      color: Colors.primary.clearblue,
    }),
    letterSpacing: -0.6,
  },
  yearTxt: {
    ...Fonts.font({
      size: 14,
    }),
    letterSpacing: -0.28,
    opacity: 0.7,
    marginTop: Metrics.smallMargin,
  },
  activeTxt: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.purplishbrown,
    }),
    letterSpacing: -0.28,
    textAlign: 'center',
  },
  disableTxt: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.purplishbrown,
    }),
    opacity: 0.4,
    letterSpacing: -0.28,
    textAlign: 'center',
  },
  dateContainer: {
    width: 50,
    height: 50,
    borderRadius: 50,
    justifyContent: 'center',
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 8,
    marginBottom: 4,
    alignSelf: 'center',
    backgroundColor: Colors.primary.clearblue,
  },
  listHeader: {
    ...Fonts.font({
      size: 24,
      color: Colors.primary.darkslateblue,
    }),
    marginLeft: Metrics.baseMargin,
    marginTop: Metrics.doubleBaseMargin,
  },
  cardContainer: {
    borderRadius: 4,
    flexDirection: 'row',
    padding: Metrics.baseMargin,
    shadowColor: 'rgba(0, 0, 0, 0.04)',
    marginVertical: Metrics.smallMargin,
    marginHorizontal: Metrics.baseMargin,
    backgroundColor: Colors.primary.white,
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowRadius: 10,
    shadowOpacity: 1,
    elevation: 3,
  },
  cardHeading: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.darkslateblue,
    }),
  },
  cardDesc: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: 8,
  },
  txtTime: {
    width:
      (Metrics.screenWidth - 2 * Metrics.baseMargin - Metrics.smallMargin) / 2,
  },
  wrapperDateArrow: {
    paddingRight: Metrics.baseMargin,
    paddingVertical: Metrics.smallMargin,
  },
  themeCalender: {
    textDayHeaderFontWeight: '500',
    calendarBackground: 'transparent',
    textSectionTitleColor: Colors.primary.darkslateblue,
    textDayHeaderFontFamily: `Gibson-${Fonts.Type.Regular}`,
  },
};
