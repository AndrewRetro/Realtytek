//
//  serviceSaga.js:
//  BoilerPlate
//
//  Created by Retrocube on 10/4/2019, 9:29:45 AM.
//  Copyright © 2019 Retrocube. All rights reserved.
//
import {call, takeEvery} from 'redux-saga/effects';
import {DOWNLOAD_FILE} from '../actions/ActionTypes';
import {
  downloadFile,
  DocumentDirectoryPath,
  DownloadDirectoryPath,
} from 'react-native-fs';
import utility from '@utils';

const downloadPDF = async ({
  url,
  fileName,
  userToken,
  cbSuccess,
  cbFailure,
}) => {
  //Define path to store file along with the extension
  const path = `${
    utility.isPlatformAndroid() ? DownloadDirectoryPath : DocumentDirectoryPath
  }/${fileName}.pdf`;
  const headers = {
    Accept: 'application/pdf',
    'Content-Type': 'application/pdf',
    Authorization: userToken,
  };
  //Define options
  const options = {
    fromUrl: url,
    toFile: path,
    headers: headers,
  };
  //Call downloadFile
  const response = await downloadFile(options);
  return response.promise.then(async res => {
    //Transform response
    if (res && res.statusCode === 200 && res.bytesWritten > 0) {
      utility.showFlashMessage(
        utility.isPlatformAndroid()
          ? `${fileName} successfully downloaded into your downloads`
          : `${fileName} successfully downloaded`,
        'success',
      );
      cbSuccess(res);
    } else {
      utility.showFlashMessage(`${fileName} download failed`);
      cbFailure(res);
    }
  });
};

function* watchDownloadFileRequest(action) {
  try {
    yield call(downloadPDF, action.data);
  } catch (err) {
    console.log('downloading crashed');
  }
}

export default function* root() {
  yield takeEvery(DOWNLOAD_FILE, watchDownloadFileRequest);
}
