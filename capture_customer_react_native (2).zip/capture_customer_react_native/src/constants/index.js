//
//  index.js:
//  BoilerPlate
//
//  Created by Retrocube on 10/4/2019, 9:13:09 AM.
//  Copyright © 2019 Retrocube. All rights reserved.
//
const constant = {
  //App Constants
  socketIP: '192.34.60.217',
  socketPort: '1233',
  baseURL: 'http://retrocubedev.com/dev/case_book/public/api/',
  baseImageURL: 'http://retrocubedev.com/dev/case_book/public/api/',
  applicationToken: 'api.Pd*!(5675',
  //Services Constants
  posts: 'user/login',
  //Socket Constants
  //     failure: { action: "failure", packet_code: 9900 },
  //Location Constants
  LOCATION_TIME_OUT: 10000,
  LOCATION_MAX_AGE: 1000,
  LOCATION_HIGH_ACCURACY: false,

  USER_TYPE_CUSTOMER: '2',

  DB_DATE_FORMAT: 'YYYY-MM-DD',
  DISPLAY_DATE_FORMAT: 'DD-MM-YYYY',
  TIME_FORMAT_DB: 'HH:mm:ss',
  DISPLAY_TIME_FORMAT: 'LT',
  NOON_FORMAT: 'h:mm A',

  BUYERS: 'buyers',
  UNDER_CONTRACT: 'under_contract',
  PROPERTY_TYPE_RECOMMENDED: 'recommended',

  PROPERTY_TYPES: {
    0: 'Single Family (SF)',
    1: 'Town House (TH)',
    2: 'Condo (C)',
    3: 'Farm (F)',
    4: 'Land (L)',
  },

  PROPERTY_TYPES_OPTIONS: [
    'Single Family (SF)',
    'Town House (TH)',
    'Condo (C)',
    'Farm (F)',
    'Land (L)',
    'Cancel',
  ],
  FIRST_TIME_BUYER_OPTIONS: ['Cancel', 'Yes', 'No'],
  PRE_APPROVED_OPTIONS: ['Cancel', 'Yes', 'No'],
  IMAGE_PICKING_OPTIONS: ['Cancel', 'Camera', 'Photo Album'],

  // event bus events
  LOGOUT: 'logout',
};

export const AppointmentStatus = {
  PENDING: 'pending',
  CONFIRMED: 'confirmed',
  REJECTED: 'reject',
  ACCEPT: 'accept',
};

export const NOTIFICATION_IDENTIFIERS = {
  CREATE_BUYING_QUERY: 'create_buying_query',
  UPDATE_BUYING_QUERY: 'update_buying_query',
  ACCEPT_APPOINTMENT: 'accept_appointment',
  CREATE_PROPERTY: 'property_create',
  INITIATE_CONTRACT: 'initiate_contract',
  HOME_RECOMMENDED: 'home_recommended',
};

export default constant;
