//
//  index.js:
//  BoilerPlate
//
//  Created by Retrocube on 10/4/2019, 9:13:09 AM.
//  Copyright © 2019 Retrocube. All rights reserved.
//

// const baseUrlDev = 'https://realtytek.dev.retrocubedev.com/';
// const baseUrlQa = 'https://realtytek.qa.retrocubedev.com/';

const live = 'https://realtytek.net/';

const apis = {
  //App Constants
  socketIP: '192.34.60.217',
  socketPort: '1233',
  baseURL: live,
  applicationToken: 'api.Pd*!(5675',

  //Services Constants
  login: 'api/user/login',
  forgotPass: 'api/user/forgot-password',
  changePass: 'api/user/change-password',
  logout: 'api/user/logout',
  notification: 'api/user-notification',
  fetchBadgeCount: 'api/count-notification',

  createProperty: 'api/property',
  updateUser: 'api/user',
  agentGet: 'api/get/customer/agent',
  createBuyer: 'api/buyer',
  buyingQueryRecommendedHomes: 'api/buyer/recommended/homes',
  createAppointment: 'api/appointments',
  touredHomes: 'api/buyer/tour/homes',
  rating: 'api/rating',
  getContractStatus: 'api/get/property/contract/status',
  getLoanInfo: 'api/get/property/loaninfo/contract',
  getAgentDisclosures: 'api/get/disclosure',
  getContractedbuyingQuery: 'api/property/initiate/contract/list',
  acceptAgreement: 'api/accept-agent-agrement',

  privacy: 'https://realtytek.net/app-content/privacy_policy',
  terms: 'https://realtytek.net/app-content/term_and_condition',

  LOCATION_TIME_OUT: 10000,
  LOCATION_MAX_AGE: 1000,
  LOCATION_HIGH_ACCURACY: false,

  serviceTypes: {
    GET: 'get',
    POST: 'post',
    PUT: 'put',
    DELETE: 'delete',
  },
};

export default apis;
