import _ from 'lodash';
import {checkNotifications} from 'react-native-permissions';
import {setBadgeCount} from 'react-native-notification-badge';

import singleton from '../singleton';
import {store} from '../store';
import {BADGE_COUNT} from '@actionTypes';
import {generalSaveAction, request} from '../actions/ServiceAction';
import {NOTIFICATION_IDENTIFIERS} from '@constants';
import apis from '@apis';
import utility from '@utils';
import {push} from '@nav';

const callback = response => global.log({response});

const callDispatch = request => {
  const dispatch = singleton.storeRef.dispatch;
  dispatch(request);
};

const handleBadgeCount = async ({badge_count}) => {
  if (utility.isPlatformIOS()) {
    const {status} = await checkNotifications();
    if (status == 'granted') await setBadgeCount(+badge_count);
  }
  singleton.storeRef.dispatch(
    generalSaveAction(BADGE_COUNT, {count: +badge_count}),
  );
};

const getUser = () => {
  return singleton.storeRef.getState().loginReducer.data;
};

const dispatchRequest = (
  url, //Service url
  method, //Web Service type 'post,get,put,delete....'
  data, //Paramter for request
  actionType = null, //Action Type
  showHud = true, //Show spinner
  successCB = callback,
  failureCB = callback,
) => {
  store.dispatch(
    request(url, method, data, actionType, showHud, successCB, failureCB),
  );
};

const fetchBuyingQuery = slug =>
  callDispatch(
    request(
      `${apis.createBuyer}/${slug}`,
      apis.serviceTypes.GET,
      {},
      null,
      this,
      false,
      buyingQuery => {
        push('BuyingQuery', {buyingQuery});
        // push('UnderContract', {
        //   isFromUnderContract: false,
        //   isFromBuyingUnderContract: true,
        //   buyingQuery,
        // });
      },
      err => utility.showFlashMessage('Failed to fetch buying query'),
    ),
  );

const fetchProperty = slug =>
  callDispatch(
    request(
      `${apis.createProperty}/${slug}`,
      apis.serviceTypes.GET,
      {},
      null,
      this,
      false,
      property => {
        push('PropertyContractDetails', {
          enableInvite: false,
          isFromUnderContract: false,
          data: property,
        });
      },
      err => utility.showFlashMessage('Failed to fetch property'),
    ),
  );

const fetchAppointment = slug =>
  callDispatch(
    request(
      `${apis.createAppointment}/${slug}`,
      apis.serviceTypes.GET,
      {},
      null,
      this,
      false,
      property => push('AppointmentDetails', {property}),
      err => utility.showFlashMessage('Failed to fetch appointment'),
    ),
  );

const fetchContractedBuyingQuery = id => {
  callDispatch(
    request(
      apis.getContractedbuyingQuery,
      apis.serviceTypes.GET,
      {buyer_id: id},
      null,
      false,
      false,
      buyingQuery => {
        push('UnderContract', {
          isFromUnderContract: false,
          isFromBuyingUnderContract: true,
          buyingQuery,
        });
      },
    ),
  );
};

const onNotificationOpened = noti => {
  console.log('nnoti : ', noti);
  const {
    custom_data: {identifier, data},
  } = noti.additionalData;

  const {slug, id} = data;

  switch (identifier) {
    case NOTIFICATION_IDENTIFIERS.CREATE_PROPERTY:
      fetchProperty(slug);
      break;
    case NOTIFICATION_IDENTIFIERS.ACCEPT_APPOINTMENT:
      fetchAppointment(slug);
      break;
    case NOTIFICATION_IDENTIFIERS.CREATE_BUYING_QUERY:
      fetchBuyingQuery(slug);
      break;
    case NOTIFICATION_IDENTIFIERS.UPDATE_BUYING_QUERY:
      fetchBuyingQuery(slug);
      break;
    case NOTIFICATION_IDENTIFIERS.INITIATE_CONTRACT:
      fetchContractedBuyingQuery(id);
      break;
    case NOTIFICATION_IDENTIFIERS.HOME_RECOMMENDED:
      fetchBuyingQuery(slug);
      break;
    default:
      return null;
  }
};

export {
  getUser,
  callDispatch,
  dispatchRequest,
  onNotificationOpened,
  handleBadgeCount,
};
