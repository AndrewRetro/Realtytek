import { createContext } from 'react';

export const LoginContext = createContext();

export const FlatListContext = createContext();

export const TabContext = createContext();
