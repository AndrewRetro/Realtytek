import React from 'react';
import {View, Text, SafeAreaView} from 'react-native';
import {EventBusSingleton} from 'light-event-bus';

import Modal from '../Modal';
import {SmallBtn} from '../../components';

import {Metrics, Colors, AppStyles} from '../../theme';
import {useDispatch} from 'react-redux';
import {generalSaveAction} from '@serviceAction';
import {LOGOUT} from '@actionTypes';
import {request} from '@serviceAction';
import apis from '@apis';
import {handleBadgeCount} from '../../reuseableFunctions';
import constant from '@constants';

export default ({setLogin}) => {
  const modal = React.useRef();
  const dispatch = useDispatch();

  React.useEffect(() => {
    EventBusSingleton.subscribe(constant.LOGOUT, is401 => {
      if (is401) {
        // when logged user is logged into another device old token becomes invalid
        // and so we get 401
        logout();
      } else modal.current.setModalVisibility(true);
    });
  }, []);

  const onCancel = () => modal.current.setModalVisibility(false);
  const onLogout = () => {
    modal.current.setModalVisibility(false);
    setTimeout(() => requestLogout(), 500);
  };

  const requestLogout = () =>
    dispatch(
      request(
        apis.logout,
        apis.serviceTypes.POST,
        {},
        null,
        true,
        false,
        logout,
      ),
    );

  const logout = () => {
    setLogin(false);
    dispatch(generalSaveAction(LOGOUT));
    handleBadgeCount({badge_count: 0});
  };

  return (
    <Modal ref={modal}>
      <SafeAreaView
        style={{
          flex: 1,
          backgroundColor: 'rgba(1,1,1,0.7)',
          justifyContent: 'center',
        }}>
        <View
          style={{
            marginHorizontal: Metrics.baseMargin,
            justifyContent: 'center',
            backgroundColor: 'white',
            borderRadius: Metrics.baseMargin,
            width: '90%',
            alignItems: 'center',
            padding: Metrics.baseMargin,
          }}>
          <Text
            style={{
              ...AppStyles.gbSb(18, Colors.primary.black),
              marginTop: Metrics.widthRatio(8),
            }}>
            Logout?
          </Text>
          <Text
            style={{
              ...AppStyles.gbRe(12, Colors.primary.blueyGrey),
              marginTop: Metrics.widthRatio(50),
            }}>
            Are you sure you want to Logout
          </Text>
          <View
            style={{
              flexDirection: 'row',
              marginTop: Metrics.doubleBaseMargin * 2,
            }}>
            <SmallBtn
              style={{
                flex: 1,
                marginRight: Metrics.smallMargin,
                height: Metrics.widthRatio(40),
              }}
              bgColor={Colors.primary.blueyGrey}
              txtColor={Colors.primary.white}
              onPress={onCancel}
              useBoldTxt
              title="Cancel"
            />
            <SmallBtn
              onPress={onLogout}
              style={{
                marginLeft: Metrics.smallMargin,
                flex: 1,
                height: Metrics.widthRatio(40),
              }}
              bgColor={Colors.primary.clearblue}
              txtColor={Colors.primary.white}
              useBoldTxt
              title="Yes, Logout"
            />
          </View>
        </View>
      </SafeAreaView>
    </Modal>
  );
};
