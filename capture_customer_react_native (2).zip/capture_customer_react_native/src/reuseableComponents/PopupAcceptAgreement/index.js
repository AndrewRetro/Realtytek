import React, {useState} from 'react';
import {View, Text, SafeAreaView, StyleSheet, Image} from 'react-native';
import {WebView} from 'react-native-webview';
import CheckBox from '@react-native-community/checkbox';
import _ from 'lodash';
import {useDispatch, useSelector} from 'react-redux';

import Modal from '../Modal';
import {Metrics, Colors, AppStyles, Images} from '../../theme';
import {generalSaveAction, request} from '@serviceAction';
import {USER} from '@actionTypes';
import apis from '@apis';
import {ButtonView, Loader} from '@reuseableComponents';
import utility from '@utils';

export default ({isReduxLoaded}) => {
  const modal = React.useRef();
  const dispatch = useDispatch();
  const user = useSelector(({user}) => user.data);
  const [state, setState] = useState({isAgreed: false, isFetching: false});
  const isUser = !!Object.keys(user).length;

  React.useEffect(() => {
    if (isUser && user.is_agrement_accept == 0)
      modal.current?.setModalVisibility(true);

    if (isUser && user.is_agrement_accept == 1)
      modal.current?.setModalVisibility(false);
  }, [isReduxLoaded, user]);

  const onAccpetAgreement = () => {
    setState(s => ({...s, isFetching: true}));
    dispatch(
      request(
        apis.acceptAgreement,
        apis.serviceTypes.POST,
        {is_agrement_accept: '1'},
        null,
        false,
        false,
        () => {
          dispatch(
            generalSaveAction(USER.SUCCESS, {
              ..._.cloneDeep(user),
              is_agrement_accept: 1,
            }),
          );
          setState(s => ({...s, isFetching: false}));
        },
        () => setState(s => ({...s, isFetching: false})),
      ),
    );
  };

  const renderLoading = () => <Loader />;

  return (
    <Modal ref={modal}>
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.container}>
          {isUser && (
            <View style={styles.containerHeader}>
              <View style={styles.containerTitle}>
                <Text style={styles.title}>Accept Agreement</Text>
              </View>
              {utility.isPlatformAndroid() ? (
                <WebView
                  source={{
                    uri: `http://docs.google.com/gview?embedded=true&url=${encodeURIComponent(
                      user.agent.agent_agrement,
                    )}`,
                  }}
                  allowFileAccess={true}
                  originWhitelist={['*']}
                  startInLoadingState={true}
                  renderLoading={renderLoading}
                  style={styles.webview}
                  onLoad={syntheticEvent => {}}
                  onError={syntheticEvent => {}}
                  onHttpError={syntheticEvent => {}}
                />
              ) : (
                <WebView
                  source={{uri: user.agent.agent_agrement}}
                  style={styles.webview}
                />
              )}

              <View style={styles.containerAcceptence}>
                <CheckBox
                  style={styles.checkboxWrapper}
                  boxType="square"
                  value={state.isAgreed}
                  onValueChange={() =>
                    setState(prevState => ({
                      ...prevState,
                      isAgreed: !prevState.isAgreed,
                    }))
                  }
                />
                <Text style={styles.txtAcceptance}>
                  I have read this document and I accept it
                </Text>
                <ButtonView
                  onPress={onAccpetAgreement}
                  style={styles.btnAccept}>
                  <Image source={Images.icCheck} style={styles.icCheck} />
                </ButtonView>
              </View>
            </View>
          )}
        </View>
        {state.isFetching && <Loader style={styles.loader} />}
      </SafeAreaView>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    marginHorizontal: Metrics.smallMargin,
    borderRadius: Metrics.baseMargin,
    flex: 1,
  },
  containerHeader: {
    flex: 1,
    backgroundColor: Colors.primary.white,
    borderRadius: Metrics.baseMargin,
  },
  safeArea: {
    flex: 1,
    backgroundColor: 'rgba(1,1,1,0.7)',
    justifyContent: 'center',
    borderBottomLeftRadius: Metrics.smallMargin,
    borderBottomRightRadius: Metrics.smallMargin,
  },
  containerTitle: {
    borderBottomColor: Colors.primary.blueyGrey,
    borderBottomWidth: Metrics.widthRatio(0.5),
  },
  checkboxWrapper: {
    height: Metrics.heightRatio(24),
    width: Metrics.widthRatio(24),
    marginRight: Metrics.baseMargin,
    marginLeft: Metrics.baseMargin,
  },
  containerAcceptence: {
    borderTopColor: Colors.primary.blueyGrey,
    borderTopWidth: Metrics.widthRatio(0.5),
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomRightRadius: Metrics.baseMargin,
    overflow: 'hidden',
  },
  title: {
    ...AppStyles.gbSb(14, Colors.primary.darkslateblue),
    textAlign: 'center',
    padding: Metrics.baseMargin,
    paddingTop: Metrics.widthRatio(18),
  },
  txtAcceptance: {...AppStyles.gbRe(14, Colors.primary.darkslateblue), flex: 1},
  webview: {flex: 1},
  btnAccept: {
    backgroundColor: Colors.primary.clearblue,
    padding: Metrics.baseMargin,
  },
  loader: {position: 'absolute', top: 0, left: 0, right: 0, bottom: 0},
  icCheck: {tintColor: 'white'},
});
