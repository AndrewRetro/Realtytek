import React from 'react';
import {View} from 'react-native';

import {Images} from '@theme';
import {ImageHandler} from '@reuseableComponents';

export default function ({rating, style, useBig}) {
  const element = [];
  for (let i = 0; i < 5; i++) {
    if (i < rating) {
      element.push(
        <ImageHandler
          style={useBig ? {height: 16, width: 16} : {height: 12, width: 12}}
          key={`star_${i}`}
          source={Images.icStar24Px}
        />,
      );
    } else {
      element.push(
        <ImageHandler
          style={useBig ? {height: 16, width: 16} : {height: 12, width: 12}}
          key={`star_${i}`}
          source={Images.icStarBorder24Px}
        />,
      );
    }
  }
  return <View style={{flexDirection: 'row', ...style}}>{element}</View>;
}
