import React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {createStackNavigator} from '@react-navigation/stack';
import Home from '../../containers/Tabs/Home';
import Buying from '../../containers/Tabs/Buying';
import Selling from '../../containers/Tabs/Selling';
import {Colors, Images} from '../../theme';
import Broker from '../../containers/Tabs/Broker';
import Appointment from '../../containers/Tabs/Appointment';
// import {toggleDrawer} from '../../services/NavigationService';
// import Example from '../../containers/Tabs/Example';
// import {backButton} from '../navigatorHelper';
// import Listings from '../../containers/Tabs/Listings';
// import Calander from '../../containers/Drawer/Calander';
// import Appointment from '../../containers/Drawer/Appointment';
// import {CustomerStack} from '../Stacks';
import {ImageHandler} from '../../reuseableComponents';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

const TabNav = ({props}) => {
  const {bottom} = useSafeAreaInsets();
  return (
    <Tab.Navigator
      tabBarOptions={{
        activeTintColor: Colors.primary.clearblue,
        inactiveTintColor: Colors.primary.darkslateblue,
        style: bottom
          ? {height: 90}
          : {
              height: 70,
              paddingBottom: 10,
            },
      }}>
      <Tab.Screen
        name="Dashboard"
        component={Home}
        options={{
          tabBarIcon: ({focused}) => (
            <ImageHandler
              style={{
                marginBottom: -10,
                tintColor: focused
                  ? Colors.primary.clearblue
                  : Colors.primary.darkslateblue,
              }}
              source={Images.icDashboard}
            />
          ),
          tabBarLabel: 'Dashboard',
        }}
      />
      <Tab.Screen
        name="Buying"
        component={Buying}
        options={{
          tabBarIcon: ({focused}) => (
            <ImageHandler
              style={{
                marginBottom: -10,
                tintColor: focused
                  ? Colors.primary.clearblue
                  : Colors.primary.darkslateblue,
              }}
              source={Images.icBuying}
            />
          ),
          tabBarLabel: 'Buying',
        }}
      />
      <Tab.Screen
        name="Selling"
        component={Selling}
        options={{
          tabBarIcon: ({focused}) => (
            <ImageHandler
              style={{
                marginBottom: -10,
                tintColor: focused
                  ? Colors.primary.clearblue
                  : Colors.primary.darkslateblue,
              }}
              source={Images.icSelling}
            />
          ),
          tabBarLabel: 'Selling',
        }}
      />
      <Tab.Screen
        name="Broker"
        component={Broker}
        options={{
          tabBarIcon: ({focused}) => (
            <ImageHandler
              style={{
                marginBottom: -10,
                tintColor: focused
                  ? Colors.primary.clearblue
                  : Colors.primary.darkslateblue,
              }}
              source={Images.icCustomer}
            />
          ),
          tabBarLabel: 'Broker',
        }}
      />
      <Tab.Screen
        name="Appointments"
        component={Appointment}
        options={{
          tabBarIcon: ({focused}) => (
            <ImageHandler
              style={{
                marginBottom: -10,
                tintColor: focused
                  ? Colors.primary.clearblue
                  : Colors.primary.darkslateblue,
              }}
              source={Images.icAppointments}
            />
          ),
          tabBarLabel: 'Appointments',
        }}
      />
    </Tab.Navigator>
  );
};

export default TabNav;
//   TabStack = ({ navigation }) => (
//   <Stack.Navigator
//     screenOptions={{
//       headerShown: false,
//     }}>
//     <Stack.Screen name="TabNav" component={TabNav} />
//     <Stack.Screen name="Example" component={Example} />
//   </Stack.Navigator>
// );
