import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {Login, ForgotPass, AgencyDisclosure} from '../../containers';
import DrawerNav from '../Drawer';

const Stack = createStackNavigator();

const AuthStack = () => (
  <Stack.Navigator headerMode="none">
    <Stack.Screen name="Login" component={Login} options={{title: 'Login'}} />
    <Stack.Screen name="ForgotPass" component={ForgotPass} />
    <Stack.Screen name="AgencyDisclosure" component={AgencyDisclosure} />
  </Stack.Navigator>
);

const MainStack = ({navigation}) => (
  <Stack.Navigator headerMode="none">
    <Stack.Screen name="DrawerNav" component={DrawerNav} />
  </Stack.Navigator>
);

export {AuthStack, MainStack};
