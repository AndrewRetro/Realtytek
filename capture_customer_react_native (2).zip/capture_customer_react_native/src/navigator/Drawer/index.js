import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {createDrawerNavigator} from '@react-navigation/drawer';
import Notifications from '../../containers/Drawer/Notifications';
import Settings from '../../containers/Drawer/Settings';
import ChangePassword from '../../containers/Drawer/ChangePassword';
import AppDrawer from '../../containers/Drawer';
import Calendar from '../../containers/Drawer/Calendar';
import Disclosure from '../../containers/Drawer/Disclosure';
import MyAccount from '../../containers/Drawer/MyAccount';
import Webview from '../../containers/Drawer/Webview';
import Tabs from '../Tabs';
import RecommededHomes from '../../containers/Buying/RecommededHomes';
import BuyingQuery from '../../containers/Buying/BuyingQuery';
import TouredHomes from '../../containers/Buying/TouredHomes';
import PropertyDetails from '../../containers/Buying/PropertyDetails';
import CreateAppointment from '../../containers/Buying/CreateAppointment';
import AddBuyingQuery from '../../containers/Buying/AddBuyingQuery';
import PropertyContractDetails from '../../containers/Selling/PropertyContractDetails';
import UnderContract from '../../containers/Selling/UnderContract';
import EditProfile from '../../containers/Drawer/EditProfile';
import AppointmentDetails from '../../containers/Drawer/AppointmentDetails';
import SellingQuery from '../../containers/Selling/SellingQuery';
import Search from '../../containers/Search';
import Notification from '../../containers/Notification';
import RandomRecommendedHomes from '../../containers/RandomRecommendedHomes';

const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

const SellingStack = () => (
  <Stack.Navigator headerMode="none">
    <Stack.Screen name="SellingQuery" component={SellingQuery} />
  </Stack.Navigator>
);

const BrokerStack = () => (
  <Stack.Navigator headerMode="none">
    <Stack.Screen name="BrokerDisclosure" component={Disclosure} />
    {/* <Stack.Screen name="BrokerCalendar" component={Calendar} /> */}
  </Stack.Navigator>
);

const DrawerStack = () => (
  <Stack.Navigator headerMode="none">
    <Stack.Screen
      name="TabStack"
      component={Tabs}
      options={{
        headerShown: false,
      }}
    />
    <Stack.Screen name="Settings" component={Settings} />
    <Stack.Screen name="EditProfile" component={EditProfile} />
    <Stack.Screen name="AppointmentDetails" component={AppointmentDetails} />
    <Stack.Screen name="MyAccount" component={MyAccount} />
    <Stack.Screen name="Calendar" component={Calendar} />
    <Stack.Screen name="Disclosure" component={Disclosure} />
    <Stack.Screen name="BrokerStack" component={BrokerStack} />
    <Stack.Screen name="UnderContract" component={UnderContract} />
    <Stack.Screen name="SellingStack" component={SellingStack} />
    <Stack.Screen name="Notifications" component={Notifications} />
    <Stack.Screen name="ChangePassword" component={ChangePassword} />
    <Stack.Screen name="PropertyDetailsHome" component={PropertyDetails} />
    <Stack.Screen name="PropertyDetails" component={PropertyDetails} />
    <Stack.Screen name="Search" component={Search} />
    <Stack.Screen name="Notification" component={Notification} />
    <Stack.Screen name="AddBuyingQuery" component={AddBuyingQuery} />
    <Stack.Screen name="BuyingQuery" component={BuyingQuery} />
    <Stack.Screen name="TouredHomes" component={TouredHomes} />
    <Stack.Screen name="Webview" component={Webview} />
    <Stack.Screen
      name="PropertyContractDetails"
      component={PropertyContractDetails}
    />
    <Stack.Screen name="RecommededHomes" component={RecommededHomes} />
    <Stack.Screen
      name="RandomRecommendedHomes"
      component={RandomRecommendedHomes}
    />
    <Stack.Screen name="CreateAppointment" component={CreateAppointment} />
  </Stack.Navigator>
);

export default DrawerNav = () => (
  <Drawer.Navigator
    // options={{
    //   swipeEnabled: true,
    //   gestureEnabled: true,
    // }}
    drawerContent={props => <AppDrawer {...props} />}>
    <Drawer.Screen name="DrawerStack" component={DrawerStack} />
  </Drawer.Navigator>
);
