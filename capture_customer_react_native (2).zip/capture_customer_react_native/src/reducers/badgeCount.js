//
//  userLocation.js:
//  BoilerPlate
//
//  Created by Retrocube on 10/4/2019, 9:22:31 AM.
//  Copyright © 2019 Retrocube. All rights reserved.
//
import * as types from '../actions/ActionTypes';

const initialState = {
  count: 0,
};

export default (state: Object = initialState, action: Object) => {
  switch (action.type) {
    case types.BADGE_COUNT:
      return {
        count: action.data.count,
      };

    default:
      return state;
  }
};
