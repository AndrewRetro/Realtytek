import _ from 'lodash';
import React, {Component} from 'react';
import {StatusBar, View} from 'react-native';
import {Provider} from 'react-redux';
import {PersistGate} from 'redux-persist/integration/react';
import KeyboardManager from 'react-native-keyboard-manager';
import SplashScreen from 'react-native-splash-screen';
import FlashMessage from 'react-native-flash-message';
import Spinner from 'react-native-globalspinner';
import OneSignal from 'react-native-onesignal';
import uuid from 'react-native-uuid';

import {store, persistor} from './store';
import RootNavigator from './navigator';
import {navigatorRef} from './services/NavigationService';
import singleton from './singleton';
import {Colors} from './theme';
import HttpServiceManager from './services/HttpServiceManager';
import {LoginContext} from './contexts';
import utility from './utility';

import {
  LogoutModal,
  ImageViewer,
  PopupAcceptAgreement,
} from './reuseableComponents';
import apis from '@apis';
import {onNotificationOpened} from './reuseableFunctions';

export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLogin: false,
      setLogin: this.setLogin,
      isReduxLoaded: false,
    };
  }

  componentDidMount() {
    if (utility.isPlatformIOS()) {
      KeyboardManager.setEnable(true);
    }
    HttpServiceManager.initialize(apis.baseURL, {
      token: uuid.v4(),
    });

    OneSignal.setLocationShared(false);
    //OneSignal Init Code
    OneSignal.setLogLevel(6, 0);
    OneSignal.setAppId('d334786d-acaf-4949-91db-bddb07ae93d3');
    //END OneSignal Init Code

    //Prompt for push on iOS
    OneSignal.promptForPushNotificationsWithUserResponse(response => {
      console.log('Prompt response:', response);
    });

    //Method for handling notifications received while app in foreground
    OneSignal.setNotificationWillShowInForegroundHandler(
      notificationReceivedEvent => {
        let notification = notificationReceivedEvent.getNotification();

        const data = notification.additionalData;

        // Complete with null means don't show a notification.
        notificationReceivedEvent.complete(notification);
      },
    );

    //Method for handling notifications opened
    OneSignal.setNotificationOpenedHandler(({notification}) =>
      onNotificationOpened(notification),
    );
  }

  setLogin = (isLogin = true) => {
    this.setState({isLogin});
  };

  onBeforeLift = () => {
    singleton.storeRef = store;
    const user = store.getState().user.data;
    const isLogin = !_.isEmpty(user);
    if (isLogin) HttpServiceManager.getInstance().userToken = user.api_token;
    this.setState({isReduxLoaded: true, isLogin}, () => {
      setTimeout(SplashScreen.hide, 3000);
    });
  };

  render() {
    const {isReduxLoaded} = this.state;

    return (
      <Provider store={store}>
        <StatusBar
          barStyle="dark-content"
          backgroundColor={Colors.secondary.azure}
        />
        <PersistGate onBeforeLift={this.onBeforeLift} persistor={persistor}>
          {isReduxLoaded ? (
            <LoginContext.Provider value={this.state}>
              <RootNavigator ref={navigatorRef} />
            </LoginContext.Provider>
          ) : (
            <View />
          )}
        </PersistGate>
        <ImageViewer ref={utility.setImageViewerRef} />
        <PopupAcceptAgreement isReduxLoaded={isReduxLoaded} />
        <LogoutModal setLogin={this.setLogin} />
        <FlashMessage position="top" />
        <Spinner color={Colors.primary.theme} />
      </Provider>
    );
  }
}
