import React from 'react';
import {View, Text, StyleSheet} from 'react-native';

import moment from 'moment';
import {BigCard, FloatingBtn} from '../components';
import {Images, Metrics} from '../theme';
import {FlatListHandler} from '../reuseableComponents';
import {navigate} from '../services/NavigationService';

const dummyData = [
  {
    id: '1',
    name: 'Debra Pierce',
    image_url: Images.icUser2,
    date: moment().format('DD/MM/YYYY'),
    address: '3 Bed, 3 Bath TH, U. Marlboto/Ft. Washington',
    amount: 25000,
    email: 'someone@yopmail.com',
    number: '090078601',
  },
];

export default function (props) {
  return (
    <View style={styles.container}>
      <FlatListHandler
        data={dummyData}
        renderItem={({item}) => (
          <BigCard
            onPress={() => navigate('CustomerStack', {screen: 'UnderContract'})}
            item={item}
            useFullWidth
          />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: Metrics.baseMargin,
  },
});
