import React from 'react';
import {View, Text, StyleSheet} from 'react-native';

import {FloatingBtn} from '../components';
import {Colors, Images, Metrics, Fonts} from '../theme';
import {
  ImageHandler,
  FlatListHandler,
  ButtonView,
} from '../reuseableComponents';
import {navigate} from '../services/NavigationService';

const leadsDummyData = [
  {
    id: '1',
    image_url: Images.icUser1,
    name: 'Carolyn Lynch',
    email: 'someone@yopmail.com',
    mobile_no: '023432432423',
  },
  {
    id: '2',
    image_url: Images.icUser1,
    name: 'Chris Meyer',
    email: 'someone@yopmail.com',
    mobile_no: '023432432423',
  },
  {
    id: '3',
    image_url: Images.icUser1,
    name: 'Julie Lynch',
    email: 'someone@yopmail.com',
    mobile_no: '023432432423',
  },
  {
    id: '4',
    image_url: Images.icUser1,
    name: 'Rose Lynch',
    email: 'someone@yopmail.com',
    mobile_no: '023432432423',
  },
];

export default function (props) {
  return (
    <>
      <FlatListHandler
        data={leadsDummyData}
        renderItem={({item}) => (
          <ButtonView
            onPress={() => navigate('CustomerStack', {screen: 'Lead'})}
            style={stylesCards.container}>
            <View style={stylesCards.wrapper}>
              <ImageHandler style={stylesCards.img} source={item.image_url} />
              <Text style={stylesCards.nameTxt}>{item.name}</Text>
            </View>

            <View style={stylesCards.wrapper}>
              <ImageHandler source={Images.icEmailTile} />
              <ImageHandler
                style={{marginLeft: Metrics.smallMargin}}
                source={Images.icPhoneTile}
              />
            </View>
          </ButtonView>
        )}
      />
      <FloatingBtn
        onPress={() => navigate('CustomerStack', {screen: 'AddLead'})}
      />
    </>
  );
}

const stylesCards = StyleSheet.create({
  container: {
    borderRadius: 5,
    alignItems: 'center',
    flexDirection: 'row',
    padding: Metrics.smallMargin,
    marginTop: Metrics.baseMargin,
    justifyContent: 'space-between',
    marginHorizontal: Metrics.baseMargin,
    backgroundColor: Colors.primary.white,

    shadowColor: 'rgba(0, 0, 0, 0.04)',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowRadius: 6,
    shadowOpacity: 1,

    elevation: 4,
  },
  emailWrapper: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.primary.darkslateblue,
  },
  wrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  img: {
    height: 44,
    width: 44,
  },
  nameTxt: {
    ...Fonts.font({size: 16, color: Colors.primary.slate}),
    marginLeft: Metrics.baseMargin,
  },
});
