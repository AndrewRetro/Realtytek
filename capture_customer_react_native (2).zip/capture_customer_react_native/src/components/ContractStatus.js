import apis from '@apis';
import {request} from '@serviceAction';
import React, {useEffect, useState} from 'react';
import {Text, View} from 'react-native';
import {useDispatch} from 'react-redux';
import _ from 'lodash';

import {FormHandler, MaterialTextField} from '../reuseableComponents';
import {Fonts, Metrics, Colors} from '../theme';

const ContractStatus = ({property}) => {
  const dispatch = useDispatch();

  const [state, setState] = useState({
    add_comment: null,
    appraisal: null,
    contract_accepted: null,
    contract_countered: null,
    contract_executed: null,
    contract_offer: null,
    contract_status: null,
    final_walk_thru: null,
    inspection: null,
    offer_decline: null,
    sattlement_date: null,
  });

  useEffect(() => {
    fetchContractStatus();
  }, []);

  const fetchContractStatus = () => {
    dispatch(
      request(
        apis.getContractStatus,
        apis.serviceTypes.GET,
        {property_id: property.id},
        null,
        true, // if got contract status from parent don't show loader
        false,
        plotContractDetailsIntoState,
      ),
    );
  };

  const plotContractDetailsIntoState = contractStatus => {
    if (!Array.isArray(contractStatus)) {
      setState(s => {
        let state = _.cloneDeep(s);
        Object.keys(state).map(key => {
          if (contractStatus[key]) {
            state[key] = contractStatus[key];
          }
        });
        return state;
      });
    }
  };

  return (
    <>
      <View style={{flexDirection: 'row'}}>
        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Contract Offered</Text>
          <Text style={styles.tileDesc2}>
            {state.contract_offer ? state.contract_offer : 'Pending'}
          </Text>
        </View>

        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Contract Countered</Text>
          <Text style={styles.tileDesc2}>
            {state.contract_countered ? state.contract_countered : 'Pending'}
          </Text>
        </View>
      </View>

      <View style={{flexDirection: 'row'}}>
        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Contract Accepted</Text>
          <Text style={styles.tileDesc2}>
            {state.contract_accepted ? state.contract_accepted : 'Pending'}
          </Text>
        </View>

        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Contract Executed</Text>
          <Text style={styles.tileDesc2}>
            {state.contract_executed ? state.contract_executed : 'Pending'}
          </Text>
        </View>
      </View>

      <View style={{flexDirection: 'row'}}>
        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Offer Decline</Text>
          <Text style={styles.tileDesc2}>
            {state.offer_decline ? state.offer_decline : 'Pending'}
          </Text>
        </View>

        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Inspection</Text>
          <Text style={styles.tileDesc2}>
            {state.inspection ? state.inspection : 'Pending'}
          </Text>
        </View>
      </View>

      <View style={{flexDirection: 'row'}}>
        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Appraisal</Text>
          <Text style={styles.tileDesc2}>
            {state.appraisal ? state.appraisal : 'Pending'}
          </Text>
        </View>

        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Final Walk-thru</Text>
          <Text style={styles.tileDesc2}>
            {state.final_walk_thru ? state.final_walk_thru : 'Pending'}
          </Text>
        </View>
      </View>

      <View style={{flexDirection: 'row'}}>
        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Settlement Date</Text>
          <Text style={styles.tileDesc2}>
            {state.sattlement_date ? state.sattlement_date : 'Pending'}
          </Text>
        </View>

        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Contract Status</Text>
          <Text style={styles.tileDesc2}>
            {state.contract_status?.toLocaleLowerCase() == 'yes'
              ? 'Active'
              : 'Deactive'}
          </Text>
        </View>
      </View>
      <FormHandler>
        <MaterialTextField
          value={state.add_comment}
          useBoldTxt
          label="Miscellaneous"
          placeholder={'No comment yet'}
          multiline
          useBigSpace
          editable={false}
        />
      </FormHandler>
    </>
  );
};

export default ContractStatus;

const styles = {
  tileTxt2: {
    ...Fonts.font({
      size: 12,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: Metrics.doubleBaseMargin,
  },
  linkTxt: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.Italic,
      color: Colors.primary.clearblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
  tileDesc2: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginTop: 8,
  },
};
