import utility from '@utils';
import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import {
  ButtonView,
  ImageHandler,
  ImageHandlerUpdated,
} from '../reuseableComponents';
import {navigate} from '../services/NavigationService';

import {AppStyles, Colors, Fonts, Images, Metrics} from '../theme';

export default function () {
  const user = useSelector(({user}) => user.data);
  const {name, image_url, mobile_no, email} = user.agent;

  const onCalender = () => navigate('Calendar', {isFromDrawer: false});

  const onAgentDisclosure = () =>
    navigate('BrokerStack', {
      screen: 'BrokerDisclosure',
      params: {isFromDrawer: false},
    });

  return (
    <View style={styles.container}>
      <ImageHandlerUpdated
        source={{uri: image_url}}
        style={{
          width: Metrics.widthRatio(80),
          height: Metrics.widthRatio(80),
          borderRadius: Metrics.smallMargin,
        }}
        isProfileImage
        isZoomViewerEnabled
      />
      <View style={styles.wrapper}>
        <Text style={styles.nameTxt}>{name}</Text>
        <View style={styles.tileWrapper}>
          <ButtonView style={styles.btn} onPress={utility.email(email)}>
            <ImageHandler source={Images.icEmailTile} />
          </ButtonView>
          <ButtonView style={styles.btnChat} onPress={utility.chat(mobile_no)}>
            <ImageHandler source={Images.icChat} style={styles.icChat} />
          </ButtonView>
          <ButtonView style={styles.btn} onPress={utility.call(mobile_no)}>
            <ImageHandler source={Images.icPhoneTile} />
          </ButtonView>
          <ButtonView onPress={onCalender} style={styles.btn}>
            <ImageHandler source={Images.icCalenderTile} />
          </ButtonView>
          <ButtonView style={styles.btn} onPress={onAgentDisclosure}>
            <ImageHandler source={Images.icSellingTile} />
          </ButtonView>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 4,
    flexDirection: 'row',
    padding: Metrics.smallMargin,
    marginRight: Metrics.baseMargin,
    marginBottom: Metrics.smallMargin,
    minWidth: Metrics.screenWidth * 0.9,
    backgroundColor: Colors.primary.white,

    shadowColor: 'rgba(0, 0, 0, 0.04)',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowRadius: 6,
    shadowOpacity: 1,
    elevation: 4,
  },
  wrapper: {
    flex: 1,
    marginLeft: Metrics.smallMargin,
    justifyContent: 'space-between',
  },
  nameTxt: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.slate,
    }),
  },
  tileWrapper: {
    flexDirection: 'row',
    alignSelf: 'flex-end',
    alignItems: 'center',
    paddingVertical: Metrics.widthRatio(4),
  },
  btn: {
    paddingHorizontal: Metrics.smallMargin / 2,
  },
  btnChat: {
    ...AppStyles.centerAligned,
    width: Metrics.widthRatio(28),
    height: Metrics.widthRatio(28),
    backgroundColor: Colors.primary.clearblue,
    borderRadius: Metrics.widthRatio(14),
    marginHorizontal: Metrics.smallMargin / 2,
  },
  icChat: {
    width: Metrics.widthRatio(16),
    height: Metrics.widthRatio(16),
  },
});
