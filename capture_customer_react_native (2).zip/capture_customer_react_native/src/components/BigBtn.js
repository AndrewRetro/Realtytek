import React, {useMemo} from 'react';
import {Text, StyleSheet} from 'react-native';

import {Colors, Fonts, Metrics} from '../theme';
import {ButtonView, ImageHandler} from '../reuseableComponents';

export default ({
  title,
  bgColor,
  txtColor,
  onPress,
  useMargin,
  margin,
  dashed,
  borderColor,
  useSmall,
  icon,
  style,
}) => {
  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          borderColor,
          width: '100%',
          borderRadius: 5,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          height: Metrics.heightRatio(useSmall ? 42 : 52),
          borderStyle: dashed ? 'dashed' : 'solid',
          borderWidth: dashed ? 1 : 0,
          backgroundColor: bgColor || Colors.primary.clearblue,
          marginTop: useMargin ? margin || Metrics.xDoubleBaseMargin : 0,
        },
        txt: {
          ...Fonts.font({
            size: 16,
            type: dashed ? Fonts.Type.Regular : Fonts.Type.SemiBold,
            color: txtColor || Colors.primary.white,
          }),
          letterSpacing: 0.8,
        },
        img: {
          marginRight: Metrics.baseMargin,
        },
      }),
    [],
  );

  return (
    <ButtonView onPress={onPress} style={[styles.container, style]}>
      {icon && <ImageHandler style={styles.img} source={icon} />}
      <Text style={styles.txt}>{title}</Text>
    </ButtonView>
  );
};
