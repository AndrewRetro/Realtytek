import React, {useMemo} from 'react';
import {View, Text, StyleSheet, Image} from 'react-native';

import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {ButtonView, ImageHandler} from '../reuseableComponents';
import {pop} from '../services/NavigationService';
import {Colors, Fonts, Images, Metrics} from '../theme';

export default function ({
  title,
  showRight = true,
  onRightClick,
  rightIcon,
  useRelative,
  cbOnCall = null,
  cbOnEmail = null,
}) {
  const {top} = useSafeAreaInsets();
  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          top,
          minHeight: 50,
          alignItems: 'center',
          position: 'absolute',
          flexDirection: 'row',
          width: Metrics.screenWidth,
          justifyContent: 'space-between',
          backgroundColor: Colors.translucent,
        },
        relativeContainer: {
          top: 0,
          marginTop: top,
          position: 'relative',
        },
        backImg: {
          tintColor: useRelative ? Colors.primary.black : Colors.primary.white,
        },
        backBtn: {
          paddingVertical: Metrics.smallMargin,
          paddingHorizontal: Metrics.baseMargin,
        },
        rigthWrapper: {
          flexDirection: 'row',
          marginRight: Metrics.baseMargin,
        },
        rigthWrapperTwo: {
          marginRight: 0,
          height: '100%',
          justifyContent: 'center',
          alignItems: 'center',
        },
        title: {
          ...Fonts.font({
            size: 16,
            color: useRelative ? Colors.primary.black : Colors.primary.white,
          }),
          width: 160,
          textAlign: 'center',
          position: 'absolute',
          left: Metrics.screenWidth / 2 - 80,
        },
        rigthBtn: {
          height: '100%',
          alignItems: 'center',
          justifyContent: 'center',
          paddingHorizontal: Metrics.baseMargin,
        },
      }),
    [],
  );

  return (
    <View style={[styles.container, useRelative && styles.relativeContainer]}>
      <ButtonView onPress={pop} style={styles.backBtn}>
        <ImageHandler style={styles.backImg} source={Images.icBackArrow} />
      </ButtonView>

      <Text style={styles.title}>{title}</Text>

      {showRight && (
        <View
          style={[styles.rigthWrapper, rightIcon && styles.rigthWrapperTwo]}>
          {rightIcon ? (
            <ButtonView style={styles.rigthBtn} onPress={onRightClick}>
              <Image source={rightIcon} />
            </ButtonView>
          ) : (
            <>
              <ButtonView onPress={cbOnEmail}>
                <Image source={Images.icEmailTile} />
              </ButtonView>
              <ButtonView onPress={cbOnCall}>
                <Image
                  style={{marginLeft: Metrics.baseMargin}}
                  source={Images.icPhoneTile}
                />
              </ButtonView>
            </>
          )}
        </View>
      )}
    </View>
  );
}
