import apis from '@apis';
import {request} from '@serviceAction';
import React, {useEffect, useState} from 'react';
import {Text, View} from 'react-native';
import {useDispatch} from 'react-redux';
import _ from 'lodash';

import {Fonts, Metrics, Colors} from '../theme';

const LendersInfo = ({property}) => {
  const dispatch = useDispatch();

  const [state, setState] = useState({
    company: null,
    contact: null,
    contact_number: null,
    down_payment: null,
    emd_submitted: null,
    loan_status: null,
    sale_price: null,
    financing: null,
  });

  useEffect(() => {
    fetchLoanInfo();
  }, []);

  const fetchLoanInfo = () => {
    dispatch(
      request(
        apis.getLoanInfo,
        apis.serviceTypes.GET,
        {
          property_id: property.id,
        },
        null,
        true,
        false,
        plotLoanInfoIntoState,
      ),
    );
  };

  const plotLoanInfoIntoState = loanInfo => {
    if (!Array.isArray(loanInfo)) {
      setState(s => {
        let state = _.cloneDeep(s);
        Object.keys(state).map(key => {
          if (loanInfo[key]) {
            state[key] = loanInfo[key];
          }
        });
        return state;
      });
    }
  };

  const Info = ({title, desc}) => (
    <View style={{flex: 0.5}}>
      <Text style={styles.tileTxt2}>{title}</Text>
      <Text style={styles.tileDesc2}>{desc}</Text>
    </View>
  );

  return (
    <>
      <View style={{flexDirection: 'row'}}>
        <Info
          title="Company"
          desc={state.company ? state.company : 'Pending'}
        />
        <Info
          title="Contact"
          desc={state.contact ? state.contact : 'Pending'}
        />
      </View>

      <View style={{flexDirection: 'row'}}>
        <Info
          title="Sales Price"
          desc={state.sale_price ? state.sale_price : 'Pending'}
        />
        <Info
          title="Financing"
          desc={state.financing ? state.financing : 'Pending'}
        />
      </View>

      <View style={{flexDirection: 'row'}}>
        <Info
          title="EMD Submitted"
          desc={state.emd_submitted ? state.emd_submitted : 'Pending'}
        />
        <Info
          title="Down Payment"
          desc={state.down_payment ? state.down_payment : 'Pending'}
        />
      </View>

      <Info
        title="Loan Status"
        desc={state.loan_status ? state.loan_status : 'Pending'}
      />
    </>
  );
};

export default LendersInfo;

const styles = {
  tileTxt2: {
    ...Fonts.font({
      size: 12,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: Metrics.doubleBaseMargin,
  },
  linkTxt: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.Italic,
      color: Colors.primary.clearblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
  tileDesc2: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginTop: 8,
  },
};
