import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import moment from 'moment';

import utility from '../utility';
import {Colors, Fonts, Metrics} from '../theme';
import {ImageHandlerUpdated, ButtonView} from '../reuseableComponents';
import SmallBtn from './SmallBtn';
import constant, {AppointmentStatus} from '../constants';
import {navigate} from '@nav';

export default function ({item}) {
  const {property, status, appointment_date, appointment_time} = item;

  const onPress = () => navigate('AppointmentDetails', {property: item});

  return (
    <ButtonView onPress={onPress} style={styles.container}>
      <ImageHandlerUpdated
        style={styles.img}
        source={{uri: property.image_url}}
      />
      <View style={styles.amountWrapper}>
        <Text style={styles.amountTxt}>
          {utility.formateCurrency(property.asking_price)}
        </Text>
      </View>
      <View style={styles.addressWrapper}>
        <Text style={styles.heading}>Client:</Text>
        <Text style={styles.addressTxt}>{property.title}</Text>
      </View>
      <View style={{flexDirection: 'row'}}>
        <View style={[styles.addressWrapper, {flex: 0.5, marginVertical: 0}]}>
          <Text style={styles.heading}>Date:</Text>
          <Text style={styles.addressTxt}>{appointment_date}</Text>
        </View>
        <View style={[styles.addressWrapper, {flex: 0.5, marginVertical: 0}]}>
          <Text style={styles.heading}>Time:</Text>
          <Text style={styles.addressTxt}>
            {moment(appointment_time, constant.TIME_FORMAT_DB).format(
              constant.NOON_FORMAT,
            )}
          </Text>
        </View>
      </View>
      {/*
      {status === AppointmentStatus.PENDING && (
        <View style={styles.btnContainer}>
          <SmallBtn
            style={{width: '48%'}}
            bgColor={Colors.primary.watermelon}
            title="Reject"
          />
          <SmallBtn
            style={{width: '48%'}}
            bgColor={Colors.primary.clearblue}
            title="Accept"
          />
        </View>
      )}
      */}
    </ButtonView>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 4,
    margin: Metrics.baseMargin,
    marginBottom: 0,
    padding: Metrics.widthRatio(6),
    paddingBottom: Metrics.baseMargin,
    backgroundColor: Colors.primary.white,
    shadowColor: 'rgba(0, 0, 0, 0.04)',
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowRadius: 10,
    shadowOpacity: 1,

    elevation: 4,
  },
  img: {
    width: '100%',
    height: Metrics.heightRatio(130),
    borderRadius: Metrics.widthRatio(4),
  },
  addressWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: Metrics.baseMargin,
    marginLeft: Metrics.smallMargin,
  },
  addressTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkslateblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
  nameTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkslateblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
  amountWrapper: {
    left: Metrics.widthRatio(12),
    borderRadius: 4,
    position: 'absolute',
    backgroundColor: Colors.primary.white,
    padding: Metrics.heightRatio(5),
    top: Metrics.heightRatio(108),
  },
  amountTxt: {
    ...Fonts.font({
      type: Fonts.Type.SemiBold,
      size: 12,
      color: Colors.primary.clearblue,
    }),
  },
  heading: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.lightgreyblue,
    }),
  },
  btnContainer: {
    flexDirection: 'row',
    marginTop: Metrics.baseMargin,
    justifyContent: 'space-between',
  },
});
