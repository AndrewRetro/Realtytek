import React, {useMemo} from 'react';
import {View, Text, StyleSheet} from 'react-native';

import Modal from 'react-native-modal';
import {Colors, Fonts, Metrics} from '../theme';
import {useSafeAreaInsets} from 'react-native-safe-area-context';

export default function ({isVisible, onClose}) {
  const {top} = useSafeAreaInsets();
  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          backgroundColor: Colors.primary.white,
          padding: Metrics.smallMargin,
          paddingTop: 0,
          borderRadius: 4,
          width: 120,
          position: 'absolute',
          top,
          right: Metrics.baseMargin,
        },
        optionTxt: {
          ...Fonts.font({
            size: 12,
            color: Colors.primary.darkslateblue,
          }),
          textAlign: 'right',
          marginTop: Metrics.smallMargin,
        },
      }),
    [top],
  );

  return (
    <Modal
      onBackdropPress={onClose}
      backdropColor={`${Colors.primary.darkslateblue}CC`}
      isVisible={isVisible}>
      <View style={styles.container}>
        <Text style={styles.optionTxt}>Edit Property</Text>
        <Text style={styles.optionTxt}>Disable Property</Text>
        <Text style={[styles.optionTxt, {color: Colors.primary.tomato}]}>
          Delete Property
        </Text>
      </View>
    </Modal>
  );
}
