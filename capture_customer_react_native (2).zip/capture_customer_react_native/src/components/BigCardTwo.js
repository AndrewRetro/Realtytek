import React from 'react';
import {Text, StyleSheet} from 'react-native';

import {ButtonView, ImageHandlerUpdated} from '../reuseableComponents';
import {Colors, Metrics, Fonts} from '../theme';
import utility from '../utility';

export default ({item, onPress}) => {
  return (
    <ButtonView onPress={onPress} style={styles.container}>
      <ImageHandlerUpdated
        style={{
          width: Metrics.widthRatio(144) - 2 * Metrics.smallMargin,
          height: Metrics.widthRatio(112),
          borderRadius: Metrics.widthRatio(4),
        }}
        source={{uri: item.image_url}}
      />
      <Text numberOfLines={1} ellipsizeMode="tail" style={styles.addressTxt}>
        {item.address}
      </Text>
      <Text style={styles.tag}>Asking Price</Text>
      <Text style={styles.amountTxt}>
        {utility.formateCurrency(item.asking_price)}
      </Text>
    </ButtonView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderRadius: 5,
    width: Metrics.widthRatio(144),
    padding: Metrics.smallMargin,
    marginRight: Metrics.smallMargin,
    // marginBottom: utility.isPlatformAndroid() ? 0 : Metrics.baseMargin,
    backgroundColor: Colors.primary.white,
  },
  addressTxt: {
    ...Fonts.font({
      size: 13,
      color: Colors.primary.clearblue,
    }),
    marginTop: 6,
  },
  tag: {
    ...Fonts.font({
      size: 13,
      color: Colors.primary.verylightpink,
    }),
    marginTop: 6,
  },
  amountTxt: {
    ...Fonts.font({
      size: 13,
      color: Colors.primary.clearblue,
    }),
    marginTop: 6,
  },
});
