import React from 'react';
import {View, Text, Image} from 'react-native';
import PropTypes from 'prop-types';

import {Colors, Fonts, Images, Metrics} from '../theme';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {ButtonView, ImageHandler} from '../reuseableComponents';
import {toggleDrawer} from '../services/NavigationService';
import SmallBtn from './SmallBtn';
import {useSelector} from 'react-redux';
import {push} from '@nav';

const BackHeader = ({
  user,
  title,
  onBack,
  onSearch,
  rightBtn,
  useDrawer,
  useNotification,
  secondary = false,
  titleStyle,
  containerStyle,
}) => {
  const {top} = useSafeAreaInsets();

  return (
    <View style={[styles.container, containerStyle, {marginTop: top}]}>
      <View style={styles.leftHeaderWrapper}>
        {onBack && (
          <ButtonView onPress={onBack} style={styles.headerLeft}>
            <ImageHandler source={Images.icBackArrow} />
          </ButtonView>
        )}
        {useDrawer && (
          <ButtonView onPress={toggleDrawer} style={styles.headerLeft}>
            <ImageHandler source={Images.icDrawer} />
          </ButtonView>
        )}
        {user ||
          (title && (
            <>
              {user && <ImageHandler source={user.image_url} />}
              <Text style={[styles.userNameTxt, titleStyle]}>
                {title || `Hi, ${user.name}`}
              </Text>
            </>
          ))}
      </View>

      <View style={styles.headerRightWrapper}>
        {rightBtn && (
          <SmallBtn
            style={
              secondary
                ? {
                    marginRight: Metrics.baseMargin,
                    borderWidth: 1,
                    width: 100,
                  }
                : {marginRight: Metrics.baseMargin}
            }
            bgColor={secondary ? 'transparent' : Colors.primary.clearblue}
            txtColor={secondary ? Colors.primary.darkTwo : Colors.primary.white}
            onPress={rightBtn}
            useBoldTxt={!secondary}
            title={secondary ? 'Edit Profile' : '+ Add New'}
          />
        )}
        {onSearch && (
          <ButtonView style={styles.headerLeft} onPress={onSearch}>
            <ImageHandler source={Images.icSearch} />
          </ButtonView>
        )}

        {useNotification && <Notification />}
      </View>
    </View>
  );
};

const Notification = () => {
  const count = useSelector(({badgeCount}) => badgeCount.count);

  const onNotification = () => push('Notification');

  const Dot = () => <View style={styles.dot} />;

  return (
    <ButtonView style={styles.containerIcNotification} onPress={onNotification}>
      <Image source={Images.icNotificaiton} />
      {+count > 0 && <Dot />}
    </ButtonView>
  );
};

const styles = {
  dot: {
    width: Metrics.widthRatio(12),
    height: Metrics.widthRatio(12),
    borderRadius: Metrics.widthRatio(6),
    backgroundColor: Colors.primary.greenapple,
    position: 'absolute',
    top: Metrics.widthRatio(8),
    left: Metrics.widthRatio(11),
    borderWidth: 1,
    borderColor: 'white',
  },
  container: {
    minHeight: 50,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headerLeft: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingLeft: Metrics.baseMargin,
    paddingRight: Metrics.smallMargin,
  },
  leftHeaderWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  userNameTxt: {
    ...Fonts.font({
      type: Fonts.Type.SemiBold,
      size: 22,
      color: Colors.primary.darkslateblue,
    }),
    marginLeft: Metrics.smallMargin,
    maxWidth: Metrics.screenWidth / 1.8,
  },
  headerRightWrapper: {
    flexDirection: 'row',
  },
  containerIcNotification: {
    alignItems: 'center',
    justifyContent: 'center',
    width: Metrics.widthRatio(40),
    height: Metrics.widthRatio(40),
    paddingRight: Metrics.baseMargin,
  },
};

BackHeader.propTypes = {
  titleStyle: PropTypes.object,
  containerStyle: PropTypes.object,
};

BackHeader.defaultProps = {
  titleStyle: {},
  containerStyle: {},
};

export default BackHeader;
