import React from 'react';
import {Text, View} from 'react-native';

import {ImageHandler} from '../reuseableComponents';
import {Fonts, Metrics, Colors, Images} from '../theme';

const ContractInfo = () => {
  return (
    <>
      <Text style={styles.tileTxt2}>MLS Details</Text>
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          marginTop: 8,
        }}>
        <ImageHandler source={Images.icLink} />
        <Text style={styles.linkTxt}>
          http://235 Elm Street, Los Angeles, CA
        </Text>
      </View>

      <View style={{flexDirection: 'row'}}>
        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Sale Price</Text>
          <Text style={styles.tileDesc2}>$450,000</Text>
        </View>

        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Asking Price</Text>
          <Text style={styles.tileDesc2}>$450,000</Text>
        </View>
      </View>

      <View style={{flexDirection: 'row'}}>
        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Contingent</Text>
          <Text style={styles.tileDesc2}>Yes</Text>
        </View>

        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Financing</Text>
          <Text style={styles.tileDesc2}>Cash</Text>
        </View>
      </View>

      <Text style={styles.tileTxt2}>EMD Submitted</Text>
      <Text style={styles.tileDesc2}>$50,000</Text>
    </>
  );
};

export default ContractInfo;

const styles = {
  tileTxt2: {
    ...Fonts.font({
      size: 12,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: Metrics.doubleBaseMargin,
  },
  linkTxt: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.Italic,
      color: Colors.primary.clearblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
  tileDesc2: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginTop: 8,
  },
};
