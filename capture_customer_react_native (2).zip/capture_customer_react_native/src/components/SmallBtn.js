import React, {useMemo} from 'react';
import {Text, StyleSheet, Image} from 'react-native';
import {ButtonView} from '../reuseableComponents';
import {Colors, Fonts, Metrics} from '../theme';

export default ({
  icon,
  title,
  style,
  useBold,
  txtSize,
  bgColor,
  onPress,
  txtColor,
  tintColor,
  useMargin,
  useBoldTxt,
  alignCenter,
  useRegularTxt,
  disabled = false,
}) => {
  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          width: useBold ? 120 : 80,
          height: useBold ? 44 : 30,
          borderRadius: 4,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          alignSelf: alignCenter ? 'center' : 'auto',
          backgroundColor: bgColor || Colors.primary.clearblue,
          marginLeft: useMargin ? Metrics.smallMargin : 0,
        },
        title: {
          ...Fonts.font({
            size: txtSize ? txtSize : useBold ? 16 : 13,
            type:
              useBoldTxt || (useBold && !useRegularTxt)
                ? Fonts.Type.SemiBold
                : Fonts.Type.Regular,
            color: disabled
              ? `${Colors.primary.slate}64`
              : txtColor
              ? txtColor
              : Colors.primary.white,
          }),
          marginLeft: icon ? 6 : 0,
        },
        img: {
          tintColor: tintColor || Colors.primary.white,
          width: Metrics.widthRatio(22),
          height: Metrics.widthRatio(22),
          resizeMode: 'contain',
        },
      }),
    [bgColor],
  );

  return (
    <ButtonView
      disabled={disabled}
      onPress={onPress}
      style={[styles.container, style]}>
      {icon && <Image style={styles.img} source={icon} />}
      <Text style={styles.title}>{title}</Text>
    </ButtonView>
  );
};
