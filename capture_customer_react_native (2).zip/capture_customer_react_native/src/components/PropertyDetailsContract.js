import React from 'react';
import {Text, View, Image} from 'react-native';
import {Fonts, Colors, Metrics} from '@theme';
import {Images} from '@theme';
import utility from '@utils';

export default PropertyDetailsContract = ({data}) => {
  const {
    cma_appointment,
    sell_date,
    title,
    address,
    mls_detail,
    asking_price,
    city,
    state,
    zipcode,
  } = data;

  const onMls = () => utility.openLink(data.mls_detail);

  return (
    <>
      <View style={{flexDirection: 'row'}}>
        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Community/Building</Text>
          <Text style={styles.tileDesc2}>{title}</Text>
        </View>
        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Price</Text>
          <Text style={styles.tileDesc2}>
            {utility.formateCurrency(asking_price)}
          </Text>
        </View>
      </View>

      <View style={{flexDirection: 'row'}}>
        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Address</Text>
          <Text style={styles.tileDesc2}>{address}</Text>
        </View>
        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>City</Text>
          <Text style={styles.tileDesc2}>{city}</Text>
        </View>
      </View>

      <View style={{flexDirection: 'row'}}>
        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>State</Text>
          <Text style={styles.tileDesc2}>{state}</Text>
        </View>
        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Zipcode</Text>
          <Text style={styles.tileDesc2}>{zipcode}</Text>
        </View>
      </View>

      <View style={{flexDirection: 'row'}}>
        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Sell by Date</Text>
          <Text style={styles.tileDesc2}>{sell_date}</Text>
        </View>
        <View style={{flex: 0.5}}>
          <Text style={styles.tileTxt2}>Listing/CMA appoointment</Text>
          <Text style={styles.tileDesc2}>{cma_appointment ?? 'yes'}</Text>
        </View>
      </View>

      <Text style={styles.tileTxt2}>MLS Details</Text>
      <View style={styles.rowWrapper}>
        <Image source={Images.icLink} />
        <Text style={styles.linkTxt} onPress={onMls}>
          {mls_detail}
        </Text>
      </View>
    </>
  );
};

const styles = {
  tileTxt2: {
    ...Fonts.font({
      size: 12,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: Metrics.doubleBaseMargin,
  },
  tileDesc2: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginTop: 8,
  },
  linkTxt: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.Italic,
      color: Colors.primary.clearblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
  rowWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
};
