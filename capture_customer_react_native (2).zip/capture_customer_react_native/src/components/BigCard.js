import React, {useMemo} from 'react';
import {View, Text, StyleSheet, Image} from 'react-native';

import utility from '../utility';
import {ImageHandlerUpdated, ButtonView} from '../reuseableComponents';
import {Images, Metrics, Colors, Fonts} from '../theme';
import moment from 'moment';
import constant from '@constants';

export default ({item, useFullWidth, onPress, isUnderContractCard, agent}) => {
  const stylesCard = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
          borderRadius: 5,
          padding: Metrics.smallMargin,
          width: useFullWidth
            ? Metrics.screenWidth - 2 * Metrics.baseMargin
            : Metrics.screenWidth * 0.8,
          marginHorizontal: useFullWidth ? Metrics.baseMargin : 0,
          marginRight: useFullWidth ? 0 : Metrics.smallMargin,
          marginBottom: Metrics.baseMargin,
          backgroundColor:
            item?.status === 'Sold'
              ? Colors.primary.lightgrey
              : Colors.primary.white,

          shadowColor: '#000',
          shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.25,
          shadowRadius: 3.84,

          elevation: 5,
        },
        wrapper: {
          flexDirection: 'row',
          justifyContent: 'space-between',
        },
        personalDetails: {
          flex: 1,
          flexDirection: 'row',
        },
        nameWrapper: {
          flex: 1,
          marginVertical: 5,
          marginLeft: Metrics.smallMargin,
          justifyContent: 'space-between',
        },
        nameTxt: {
          flex: 1,
          ...Fonts.font({
            size: 16,
            color: Colors.primary.slate,
          }),
        },
        addressTxt: {
          ...Fonts.font({
            size: 12,
            color: Colors.primary.slate,
          }),
          lineHeight: 14,
        },
        amountTxt: {
          ...Fonts.font({
            size: 14,
            type: Fonts.Type.SemiBold,
            color: Colors.primary.clearblue,
          }),
        },
        subWrapper: {
          alignItems: 'center',
          marginTop: Metrics.smallMargin,
        },
        subHeader: {
          ...Fonts.font({
            size: 13,
            color: Colors.secondary.xGray,
          }),
        },
        subtitle: {
          ...Fonts.font({
            size: 13,
            color: Colors.primary.slate,
          }),
          marginTop: 6,
        },
      }),
    [item?.id],
  );

  const {customer} = item;

  return (
    <ButtonView
      onPress={onPress}
      style={{
        ...stylesCard.container,
        ...(isUnderContractCard && styles.contianerUnderContract),
      }}>
      <View style={stylesCard.personalDetails}>
        <ImageHandlerUpdated
          source={customer ? {uri: agent.image_url} : item.image_url}
          style={styles.img}
        />

        <View style={styles.containerInfo}>
          <View style={styles.wrapperNameAmount}>
            <Text
              style={stylesCard.nameTxt}
              numberOfLines={1}
              ellipsizeMode="tail">
              {item.house_type}
            </Text>
            <Text style={stylesCard.amountTxt}>
              {utility.formateCurrency(item.price)}
            </Text>
          </View>

          <View style={styles.wrapperRequirements}>
            <Image style={styles.icLoc} source={Images.iclocation1} />
            <Text numberOfLines={2} style={stylesCard.addressTxt}>
              {customer ? item.requirements : item.address}
            </Text>
          </View>
        </View>
      </View>

      <View style={[stylesCard.wrapper, stylesCard.subWrapper]}>
        <Text style={stylesCard.nameTxt} numberOfLines={2} ellipsizeMode="tail">
          {customer ? agent.name : item.name}
        </Text>

        {/* <View>
          <Text style={stylesCard.subHeader}>
            {isUnderContractCard ? 'Status' : 'Moving Date'}
          </Text>
          <Text style={stylesCard.subtitle}>
            {isUnderContractCard
              ? 'Sold'
              : moment(item.move_date).format(constant.DISPLAY_DATE_FORMAT)}
          </Text>
        </View> */}

        <View style={stylesCard.wrapper}>
          <Icon
            title="Chat"
            source={Images.icChat}
            bgColor={Colors.primary.clearblue}
            onPress={utility.chat(agent.mobile_no)}
          />
          <Icon
            title="Call"
            source={Images.icCall}
            bgColor={Colors.primary.clearblue}
            onPress={utility.call(agent.mobile_no)}
          />
          <Icon
            title="Email"
            useMargin
            source={Images.icEmail}
            bgColor={Colors.primary.darkslateblue}
            onPress={utility.email(agent.email)}
          />
        </View>
      </View>
    </ButtonView>
  );
};

const Icon = ({source, onPress}) => (
  <ButtonView
    style={{
      alignItems: 'center',
      justifyContent: 'center',
      padding: Metrics.smallMargin,
      marginLeft: Metrics.smallMargin,
      width: Metrics.widthRatio(32),
      height: Metrics.widthRatio(32),
      borderRadius: Metrics.widthRatio(16),
      backgroundColor: Colors.primary.clearblue,
    }}
    onPress={onPress}>
    <Image
      source={source}
      style={{
        width: Metrics.widthRatio(16),
        height: Metrics.widthRatio(16),
        resizeMode: 'contain',
        tintColor: Colors.primary.white,
      }}
    />
  </ButtonView>
);

const styles = {
  img: {
    height: Metrics.widthRatio(64),
    width: Metrics.widthRatio(64),
    borderRadius: Metrics.widthRatio(4),
  },
  wrapperNameAmount: {flexDirection: 'row'},
  wrapperRequirements: {flexDirection: 'row', marginTop: Metrics.baseMargin},
  containerInfo: {flex: 1, marginLeft: Metrics.smallMargin},
  icLoc: {
    marginTop: 1,
    tintColor: Colors.primary.slate,
    marginRight: Metrics.smallMargin,
  },
  contianerUnderContract: {backgroundColor: Colors.primary.lightgrey},
};
