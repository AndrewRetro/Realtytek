//
//  Colors.js:
//  BoilerPlate
//
//  Created by Retrocube on 10/4/2019, 9:47:37 AM.
//  Copyright © 2019 Retrocube. All rights reserved.
//
const primary = {
  theme: '#eeb924',
  black: '#000',
  white: '#fff',
  blueyGrey: '#8a9ead',
  brightlightblue: '#35c3ef',
  palegrey: '#f7f7fa',
  darkslateblue: '#12324b',
  dark: '#1e263f',
  clearblue: '#2382fa',
  bluegrey: '#78849e',
  vermillion: '#e22620',
  slate: '#454f63',
  verylightpink: '#d5d5d5',
  darkTwo: '#2e3748',
  greyishpurple: '#766a98',
  blackTwo: '#1e1e1e',
  darkindigo: '#0b092f',
  lightgreyblue: '#9fa5bb',
  greenapple: '#67d624',
  coral: '#f05656',
  purplishbrown: '#5f5657',
  watermelon: '#e35359',
  tomato: '#f02b2b',
  navy: '#00152b',
  lightgrey: '#dcedd2',
  verylightpinktwo: '#efefef',
};

const secondary = {
  azure: '#313131',
  gray: '#5f5f5f',
  xGray: '#919090',
};
export default {
  primary,
  secondary,
  translucent: 'rgba(0,0,0,0.1)',
};
