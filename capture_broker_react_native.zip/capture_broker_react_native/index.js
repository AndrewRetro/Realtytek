/**
 * @format
 */

import {AppRegistry} from 'react-native';
import {withIAPContext} from 'react-native-iap';

import App from './src';
import {name as appName} from './app.json';

AppRegistry.registerComponent(appName, () => withIAPContext(App));
