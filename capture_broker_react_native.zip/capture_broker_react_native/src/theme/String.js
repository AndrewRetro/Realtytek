//
//  String.js:
//  BoilerPlate
//
//  Created by Retrocube on 10/4/2019, 9:49:09 AM.
//  Copyright © 2019 Retrocube. All rights reserved.
//
const PLACEHOLDER = {};
const TITLES = {};
const LABEL = {};
const VALIDATION = {};
const API_SUCCESS_MESSAGE = {};

export default {
    PLACEHOLDER,
    LABEL,
    TITLES,
    VALIDATION,
    API_SUCCESS_MESSAGE
};
