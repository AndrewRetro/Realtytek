import React, {Component} from 'react';
import {StatusBar, View, Platform, UIManager} from 'react-native';
import OneSignal from 'react-native-onesignal';
import uuid from 'react-native-uuid';
import _ from 'lodash';

import {Colors} from './theme';
import apis from './constants/apis';
import singleton from './singleton';
import {Provider} from 'react-redux';
import RootNavigator from './navigator';
import {LoginContext} from './contexts';
import {store, persistor} from './store';
import Spinner from 'react-native-globalspinner';
import SplashScreen from 'react-native-splash-screen';
import {navigatorRef} from './services/NavigationService';
import {PersistGate} from 'redux-persist/integration/react';
import KeyboardManager from 'react-native-keyboard-manager';
import HttpServiceManager from './services/HttpServiceManager';
import FlashMessage from 'react-native-flash-message';

import {LogoutModal, ImageViewer, AddDocPopup} from './reuseableComponents';
import utils from '@utils';
import {onNotificationOpened} from './reuseableFunctions';

export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLogin: false,
      setLogin: this.setLogin,
      isReduxLoaded: false,
    };
  }

  componentDidMount() {
    if (Platform.OS === 'ios') {
      KeyboardManager.setEnable(true);
      KeyboardManager.setEnableAutoToolbar(true);
      KeyboardManager.setToolbarPreviousNextButtonEnable(true);
    }

    HttpServiceManager.initialize(apis.baseURL, {
      token: uuid.v4(),
    });

    if (
      Platform.OS === 'android' &&
      UIManager.setLayoutAnimationEnabledExperimental
    ) {
      UIManager.setLayoutAnimationEnabledExperimental(true);
    }

    //OneSignal Init Code
    OneSignal.setLocationShared(false);
    OneSignal.setLogLevel(6, 0);
    OneSignal.setAppId('fd904b24-e51d-4b4e-b9b8-373be3663d05');
    //END OneSignal Init Code

    //Prompt for push on iOS
    utils.isPlatformIOS() &&
      OneSignal.promptForPushNotificationsWithUserResponse(response => {});

    //Method for handling notifications received while app in foreground
    OneSignal.setNotificationWillShowInForegroundHandler(
      notificationReceivedEvent => {
        let notification = notificationReceivedEvent.getNotification();
        const data = notification.additionalData;
        // Complete with null means don't show a notification.
        notificationReceivedEvent.complete(notification);
      },
    );

    //Method for handling notifications opened
    OneSignal.setNotificationOpenedHandler(({notification}) =>
      onNotificationOpened(notification),
    );

    this.getDeviceState();
  }

  getDeviceState = () => {
    OneSignal.getDeviceState()
      .then(({userId}) => {
        utils.setDeviceToken(userId);
      })
      .catch(e => console.log(e));
  };

  setLogin = (isLogin = true) => this.setState({isLogin});

  onBeforeLift = () => {
    singleton.storeRef = store;
    const user = store.getState().user.data;
    const isLogin = !_.isEmpty(user);

    this.setState({isReduxLoaded: true, isLogin}, () => {
      if (isLogin) HttpServiceManager.getInstance().userToken = user.api_token;
      setTimeout(() => SplashScreen.hide(), 3000);
    });
  };

  render() {
    const {isReduxLoaded} = this.state;
    return (
      <Provider store={store}>
        <StatusBar
          barStyle={Platform.OS === 'ios' ? 'dark-content' : 'light-content'}
          backgroundColor={Colors.secondary.azure}
        />
        <PersistGate onBeforeLift={this.onBeforeLift} persistor={persistor}>
          {isReduxLoaded ? (
            <LoginContext.Provider value={this.state}>
              <RootNavigator ref={navigatorRef} />
            </LoginContext.Provider>
          ) : (
            <View />
          )}
        </PersistGate>
        <ImageViewer ref={utils.setImageViewerRef} />
        <LogoutModal setLogin={this.setLogin} />
        <AddDocPopup />
        <FlashMessage position="top" />
        <Spinner color={Colors.primary.theme} />
      </Provider>
    );
  }
}
