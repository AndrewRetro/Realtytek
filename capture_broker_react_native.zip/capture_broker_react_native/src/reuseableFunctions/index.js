import _ from 'lodash';
import singleton from '../singleton';
import {checkNotifications} from 'react-native-permissions';
import {setBadgeCount} from 'react-native-notification-badge';

import {store} from '../store';
import {generalSaveAction, request} from '../actions/ServiceAction';
import {BADGE_COUNT} from '@actionTypes';
import apis from '@apis';
import utility from '@utils';
import {push} from '@nav';
import constants from '@constants';

const callback = response => global.log({response});

const callDispatch = request => {
  const dispatch = singleton.storeRef.dispatch;
  dispatch(request);
};

const getUser = () => {
  return singleton.storeRef.getState().loginReducer.data;
};

const handleBadgeCount = async ({badge_count}) => {
  if (utility.isPlatformIOS()) {
    const {status} = await checkNotifications();
    if (status == 'granted') await setBadgeCount(+badge_count);
  }
  singleton.storeRef.dispatch(
    generalSaveAction(BADGE_COUNT, {count: +badge_count}),
  );
};

const dispatchRequest = (
  url, //Service url
  method, //Web Service type 'post,get,put,delete....'
  data, //Paramter for request
  actionType = null, //Action Type
  showHud = true, //Show spinner
  successCB = callback,
  failureCB = callback,
) => {
  store.dispatch(
    request(url, method, data, actionType, showHud, successCB, failureCB),
  );
};

const fetchBuyingQuery = slug =>
  callDispatch(
    request(
      `${apis.createBuyer}/${slug}`,
      apis.serviceTypes.GET,
      {},
      null,
      this,
      false,
      buyingQuery => push('ClientProfile', {buyingQuery}),
      err => utility.showFlashMessage('Failed to fetch appointment'),
    ),
  );

const fetchProperty = slug =>
  callDispatch(
    request(
      `${apis.createProperty}/${slug}`,
      apis.serviceTypes.GET,
      {},
      null,
      this,
      false,
      property => push('ListingDetails', {property}),
      err => utility.showFlashMessage('Failed to fetch appointment'),
    ),
  );

const fetchAppointment = slug =>
  callDispatch(
    request(
      `${apis.appointments}/${slug}`,
      apis.serviceTypes.GET,
      {},
      null,
      this,
      false,
      property => push('AppointmentDetails', {property}),
      err => utility.showFlashMessage('Failed to fetch appointment'),
    ),
  );

const onNotificationOpened = noti => {
  const {
    custom_data: {identifier, data},
  } = noti.additionalData;

  const {slug} = data;

  switch (identifier) {
    case constants.NOTIFICATION_IDENTIFIER.PROPERTY_CREATE:
      fetchProperty(slug);
      break;
    case constants.NOTIFICATION_IDENTIFIER.CREATE_APPOINTMENT:
      fetchAppointment(slug);
      break;
    case constants.NOTIFICATION_IDENTIFIER.CREATE_BUYING_QUERY:
      fetchBuyingQuery(slug);
      break;
    default:
      return null;
  }
};

export {
  getUser,
  callDispatch,
  dispatchRequest,
  onNotificationOpened,
  handleBadgeCount,
};
