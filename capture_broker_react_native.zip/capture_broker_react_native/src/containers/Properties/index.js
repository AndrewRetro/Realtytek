import React, {useEffect} from 'react';
import {View} from 'react-native';
import PropTypes from 'prop-types';

import {BigCardTwo, ListingCards} from '@components';
import {FlatListHandler} from '@reuseableComponents';

import {useDispatch, useSelector} from 'react-redux';
import {PROPERTIES} from '@actionTypes';
import apis from '@apis';
import {request} from '@serviceAction';
import {Metrics, AppStyles} from '@theme';
import {navigate} from '@services/NavigationService';
import {MY_PROPERTIES} from '@actionTypes';

const Properties = props => {
  const dispatch = useDispatch();
  // isShowContractDetailsBtn is related to property detail
  const {isHorizontal, isShowContractDetailsBtn, payload} = props;

  // handling listing and my listing in this screen thats is why having this check
  const isDisplayingMyPoperties = !!payload;

  const properties = useSelector(({properties, myProperties}) =>
    isDisplayingMyPoperties ? myProperties : properties,
  );

  useEffect(() => {
    fetchProperties();
  }, []);

  const fetchProperties = (isConcat = false, page = 1) => {
    dispatch(
      request(
        apis.createProperty,
        apis.serviceTypes.GET,
        {page, limit: 10, ...(isDisplayingMyPoperties && payload)},
        isDisplayingMyPoperties ? MY_PROPERTIES : PROPERTIES,
        false,
        isConcat,
        null,
        null,
        isDisplayingMyPoperties ? MY_PROPERTIES : PROPERTIES,
      ),
    );
  };

  const Item = isHorizontal ? BigCardTwo : ListingCards;

  const onProperty = item => () =>
    navigate('ListingDetails', {property: item, isShowContractDetailsBtn});

  const renderProperty = ({item}) => (
    <Item item={item} onPress={onProperty(item)} />
  );

  const itemSeparatorComponent = () => <View style={styles.separator} />;

  const isFetchingStyle = {
    height:
      isHorizontal && properties.isFetching && !properties.data.length
        ? Metrics.widthRatio(164)
        : undefined,
  };

  return (
    <View
      style={
        isHorizontal
          ? {
              ...styles.horizontalContainer,
              ...isFetchingStyle,
            }
          : {flex: 1}
      }>
      <FlatListHandler
        bounces={isHorizontal ? false : true}
        horizontal={isHorizontal}
        fetchRequest={fetchProperties}
        data={properties.data}
        isFetching={properties.isFetching}
        ItemSeparatorComponent={itemSeparatorComponent}
        meta={properties.meta}
        renderItem={renderProperty}
      />
    </View>
  );
};

Properties.propTypes = {
  isHorizontal: PropTypes.bool,
};

Properties.defaultProps = {
  isHorizontal: false,
};

export default Properties;

const styles = {
  separator: {width: Metrics.smallMargin},
  horizontalContainer: {
    ...AppStyles.centerAlign,
  },
};
