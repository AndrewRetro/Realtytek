import React from 'react';
import {View, Text, StyleSheet, ScrollView, Image} from 'react-native';
import {EventBusSingleton} from 'light-event-bus';

import {AbsoluteHeader, SmallBtn} from '../../components';
import {AppointmentStatus} from '../../constants';
import {ImageHandlerUpdated} from '../../reuseableComponents';
import {Colors, Fonts, Images, Metrics} from '../../theme';
import utility from '@utils';
import {useDispatch} from 'react-redux';
import {request, generalSaveAction} from '@serviceAction';
import {pop} from '@nav';
import {
  APPOINTMENTS_PENDING,
  APPOINTMENTS_CONFIRMED,
  APPOINTMENTS_REJECTED,
} from '@actionTypes';
import apis from '@apis';

export default function ({route}) {
  const dispatch = useDispatch();

  const {property, appointment_date, appointment_time, status, slug, client} =
    route.params.property;
  const {
    asking_price,
    image_url,
    title,
    address,
    property_type,
    mls_detail,
    city,
    state,
    zipcode,
  } = property;

  const {name} = client;

  onReject = () =>
    EventBusSingleton.publish('popup', {
      val: 'reject',
      onAccept: () => onAccept(AppointmentStatus.REJECTED),
    });

  const onAccept = (appointmentStatus = AppointmentStatus.ACCEPT) =>
    dispatch(
      request(
        `${apis.appointments}/${slug}`,
        apis.serviceTypes.POST,
        {
          _method: 'put',
          status: appointmentStatus,
        },
        null,
        true,
        false,
        appointment => {
          dispatch(
            generalSaveAction(APPOINTMENTS_PENDING.DELETE, {
              ...appointment,
              isDeleteObj: true,
            }),
          );

          appointmentStatus == AppointmentStatus.ACCEPT
            ? setTimeout(() => {
                dispatch(
                  generalSaveAction(APPOINTMENTS_CONFIRMED.SUCCESS, {
                    ...appointment,
                    isAddToZero: true,
                  }),
                );
              }, 500)
            : setTimeout(() => {
                dispatch(
                  generalSaveAction(APPOINTMENTS_REJECTED.SUCCESS, {
                    ...appointment,
                    isAddToZero: true,
                  }),
                );
              }, 500);

          pop();
        },
      ),
    );

  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <ImageHandlerUpdated style={styles.cover} source={{uri: image_url}} />
      <AbsoluteHeader title="Property Detail" rightIcon={-1} />
      <View style={styles.content}>
        <Tag
          {...{
            t1: 'Community/Building',
            d1: title,
            t2: 'Price',
            d2: utility.formateCurrency(asking_price),
          }}
        />
        <Tag {...{t1: 'Address', d1: address, t2: 'City', d2: city}} />
        <Tag {...{t1: 'State', d1: state, t2: 'Zipcode', d2: zipcode}} />
        <Tag
          {...{
            t1: 'Property Type',
            d1: property_type,
            t2: 'Client',
            d2: name,
          }}
        />
        <Tag
          {...{
            t1: 'Date',
            d1: appointment_date,
            t2: 'Time',
            d2: utility.formattedDisplayTime(appointment_time),
          }}
        />

        <Text style={styles.tileTxt2}>MLS Details</Text>
        <View
          style={{flexDirection: 'row', alignItems: 'center', marginTop: 8}}>
          <Image source={Images.icLink} />
          <Text style={styles.linkTxt}>{mls_detail}</Text>
        </View>

        {status === AppointmentStatus.PENDING && (
          <View style={styles.btnContainer}>
            <SmallBtn
              useBold
              style={styles.btn}
              title="Reject"
              bgColor={Colors.primary.coral}
              onPress={onReject}
            />
            <SmallBtn
              useBold
              title="Accept"
              style={styles.btn}
              bgColor={Colors.primary.darkslateblue}
              onPress={onAccept}
            />
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const Tag = ({t1, d1, t2, d2, rating}) => (
  <View style={{flexDirection: 'row'}}>
    <View style={{flex: 0.5}}>
      <Text style={styles.tileTxt2}>{t1}</Text>
      <Text style={styles.tileDesc2}>{d1}</Text>
    </View>

    <View style={{flex: 0.5}}>
      <Text style={styles.tileTxt2}>{t2}</Text>
      {!!d2 && <Text style={styles.tileDesc2}>{d2}</Text>}
      {!!rating && <Rating useBig style={styles.tileDesc2} rating={rating} />}
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  cover: {
    width: Metrics.screenWidth,
    height: Metrics.heightRatio(308),
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
    marginBottom: Metrics.xDoubleBaseMargin,
  },
  tileTxt2: {
    ...Fonts.font({
      size: 12,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: Metrics.doubleBaseMargin,
  },
  tileDesc2: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginTop: 8,
  },
  linkTxt: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.Italic,
      color: Colors.primary.clearblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
  btn: {
    width:
      (Metrics.screenWidth - 2 * Metrics.baseMargin - Metrics.smallMargin) / 2,
  },
  btnContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Metrics.xDoubleBaseMargin,
  },
});
