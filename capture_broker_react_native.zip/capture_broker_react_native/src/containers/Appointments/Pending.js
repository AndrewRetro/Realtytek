import React, {useEffect} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {View} from 'react-native';

import {AppointmentCard} from '@components';
import {FlatListHandler} from '@reuseableComponents';

import apis from '@apis';
import {request} from '@serviceAction';
import {APPOINTMENTS_PENDING} from '@actionTypes';
import {Metrics} from '@theme';
import {AppointmentStatus} from '@constants';

const Pending = () => {
  const dispatch = useDispatch();

  const appointmentsPending = useSelector(
    ({appointmentsPending}) => appointmentsPending,
  );

  useEffect(() => {
    fetchPendingAppointments();
  }, []);

  fetchPendingAppointments = (isConcat = false, page = 1) => {
    dispatch(
      request(
        apis.appointments,
        apis.serviceTypes.GET,
        {
          status: AppointmentStatus.PENDING,
          page,
          limit: 10,
        },
        APPOINTMENTS_PENDING,
        false,
        isConcat,
      ),
    );
  };

  const renderAppointments = ({item}) => <AppointmentCard item={item} />;

  const renderItemSeparator = () => <View style={styles.separator} />;

  return (
    <FlatListHandler
      fetchRequest={fetchPendingAppointments}
      data={appointmentsPending.data}
      isFetching={appointmentsPending.isFetching}
      meta={appointmentsPending.meta}
      renderItem={renderAppointments}
      ItemSeparatorComponent={renderItemSeparator}
    />
  );
};

export default Pending;

const styles = {
  separator: {height: Metrics.baseMargin},
};
