import React, {useEffect} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {View} from 'react-native';

import {AppointmentCard} from '@components';
import {FlatListHandler} from '@reuseableComponents';

import apis from '@apis';
import {request} from '@serviceAction';
import {Metrics} from '@theme';
import {AppointmentStatus} from '@constants';
import {APPOINTMENTS_REJECTED} from '@actionTypes';

const Rejected = () => {
  const dispatch = useDispatch();

  const appointmentsRejected = useSelector(
    ({appointmentsRejected}) => appointmentsRejected,
  );

  useEffect(() => {
    fetchRejectedAppointments();
  }, []);

  fetchRejectedAppointments = (isConcat = false, page = 1) => {
    dispatch(
      request(
        apis.appointments,
        apis.serviceTypes.GET,
        {
          status: AppointmentStatus.REJECTED,
          page,
          limit: 10,
        },
        APPOINTMENTS_REJECTED,
        false,
        isConcat,
      ),
    );
  };

  const renderAppointments = ({item}) => <AppointmentCard item={item} />;

  const renderItemSeparator = () => <View style={styles.separator} />;

  return (
    <FlatListHandler
      fetchRequest={fetchRejectedAppointments}
      data={appointmentsRejected.data}
      isFetching={appointmentsRejected.isFetching}
      meta={appointmentsRejected.meta}
      renderItem={renderAppointments}
      ItemSeparatorComponent={renderItemSeparator}
    />
  );
};

export default Rejected;

const styles = {
  separator: {height: Metrics.baseMargin},
};
