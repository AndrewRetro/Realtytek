import React from 'react';
import {View, StyleSheet} from 'react-native';
import {EventBusSingleton} from 'light-event-bus';

import {BackHeader, FloatingBtn} from '@components';
import {Properties} from '@containers';
import {navigate, push} from '@services/NavigationService';
import {useSelector} from 'react-redux';
import {pop} from '@nav';

export default function ({route}) {
  const user = useSelector(({user}) => user);

  const onSearch = () => navigate('Search', {isPropertySearch: true});

  const onAddListing = () => {
    const {is_subscribe} = user.data;
    if (is_subscribe) {
      navigate('AddListing');
    } else {
      EventBusSingleton.publish('popup', {
        val: 'subscribe',
        onAccept: () => push('Subscription'),
      });
    }
  };

  const isPropagatedPayload = !!route.params?.payload;
  const title = route.params?.title || 'Listings';

  return (
    <View style={styles.container}>
      <BackHeader
        title={title}
        onSearch={isPropagatedPayload ? null : onSearch}
        useDrawer={isPropagatedPayload ? false : true}
        user={user.data}
        {...(isPropagatedPayload && {onBack: () => pop()})}
      />
      <Properties
        isShowContractDetailsBtn={true}
        payload={route?.params?.payload}
      />
      {!isPropagatedPayload && <FloatingBtn onPress={onAddListing} />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
