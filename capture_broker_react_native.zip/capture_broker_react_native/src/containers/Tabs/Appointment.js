import React from 'react';
import {View, StyleSheet} from 'react-native';
import ScrollableTabView from 'react-native-scrollable-tab-view';

import Pending from '@containers/Appointments/Pending';
import Confirmed from '@containers/Appointments/Confirmed';
import Rejected from '@containers/Appointments/Rejected';
import {BackHeader} from '@components';
import {CustomTabBar} from '@reuseableComponents';
import {useSelector} from 'react-redux';
import {Metrics} from '@theme';

export default function () {
  const user = useSelector(({user}) => user.data);

  return (
    <View style={styles.container}>
      <BackHeader useDrawer title="Appointments" user={user} />
      <ScrollableTabView
        style={styles.tabs}
        renderTabBar={props => (
          <View style={styles.tabWrapper}>
            <CustomTabBar {...props} />
          </View>
        )}>
        <Pending tabLabel="Pending" />
        <Confirmed tabLabel="Confirmed" />
        <Rejected tabLabel="Rejected" />
      </ScrollableTabView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  tabs: {
    marginTop: Metrics.baseMargin,
  },
  tabWrapper: {
    marginRight: Metrics.smallMargin,
  },
});
