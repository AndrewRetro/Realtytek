import React, {useEffect, useRef} from 'react';
import {View, StyleSheet} from 'react-native';
import {EventBusSingleton} from 'light-event-bus';
import ScrollableTabView from 'react-native-scrollable-tab-view';

import {BackHeader, LeadTab, BuyerTab, ContractTab} from '../../components';
import {CustomTabBar} from '../../reuseableComponents';

import {Metrics} from '../../theme';
import {navigate} from '../../services/NavigationService';
import {useSelector} from 'react-redux';

export default function ({route: {params}}) {
  const scrollableTabView = useRef();

  const user = useSelector(({user}) => user.data);

  useEffect(() => {
    EventBusSingleton.subscribe('set_customer_tab', currentTab => {
      scrollableTabView.current.goToPage(currentTab);
    });
  }, []);

  const onSearch = () => {
    navigate('Search', {isLeadSearch: true});
  };

  const renderTabs = props => (
    <View style={{marginRight: Metrics.smallMargin}}>
      <CustomTabBar {...props} tabsCount={3} />
    </View>
  );

  return (
    <View style={styles.container}>
      <BackHeader useDrawer user={user} title="Customers" onSearch={onSearch} />
      <ScrollableTabView
        style={styles.tabs}
        ref={scrollableTabView}
        renderTabBar={renderTabs}>
        <LeadTab tabLabel="Leads" />
        <BuyerTab tabLabel="Buyers" />
        <ContractTab tabLabel="Under Contract" />
      </ScrollableTabView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  tabs: {marginTop: Metrics.baseMargin},
});
