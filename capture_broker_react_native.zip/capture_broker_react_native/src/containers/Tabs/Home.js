import React, {useEffect} from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import {EventBusSingleton} from 'light-event-bus';

import {Properties} from '@containers';
import {ButtonView} from '../../reuseableComponents';
import {BackHeader, ContractTab, BuyerTab} from '../../components';

import {Colors, Metrics, AppStyles} from '../../theme';
import {navigate} from '../../services/NavigationService';
import {useDispatch, useSelector} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';
import {handleBadgeCount} from '../../reuseableFunctions';
import {useSubscriptionValidation} from '@hooks';

const Buyers = () => {
  return (
    <View style={styles.containerBuyers}>
      <View style={styles.row}>
        <Text style={styles.heading}>Buyers</Text>
        <ButtonView
          onPress={() => {
            navigate('Customer');
            setTimeout(
              () => EventBusSingleton.publish('set_customer_tab', 1),
              300,
            );
          }}>
          <Text style={styles.all}>View All</Text>
        </ButtonView>
      </View>
      <BuyerTab isHorizontal />
    </View>
  );
};

const MyListings = ({title, id}) => {
  const payload = {};

  if (id != null && id != undefined) {
    payload['user_id'] = id;
  }

  return (
    <View style={styles.containerCat}>
      <View style={styles.row}>
        <Text style={styles.heading}>{title}</Text>
        <ButtonView
          onPress={
            id == undefined
              ? () => navigate('Listings')
              : () =>
                  navigate('Properties', {
                    payload: {user_id: id},
                    title: 'My Listings',
                  })
          }>
          <Text style={styles.all}>View All</Text>
        </ButtonView>
      </View>
      <Properties
        isHorizontal
        isShowContractDetailsBtn
        {...(!!Object.keys(payload).length && {payload})}
      />
    </View>
  );
};

const UnderContract = () => {
  return (
    <View>
      <View style={styles.row}>
        <Text style={styles.heading}>Under Contract</Text>
        <ButtonView
          onPress={() => {
            navigate('Customer');
            setTimeout(
              () => EventBusSingleton.publish('set_customer_tab', 2),
              300,
            );
          }}>
          <Text style={styles.all}>View All</Text>
        </ButtonView>
      </View>
      <ContractTab isHorizontal />
    </View>
  );
};

const Home = () => {
  const dispatch = useDispatch();
  const user = useSelector(({user}) => user.data);

  useSubscriptionValidation();
  useEffect(() => {
    setTimeout(fetchBadgeCount, 5000);
  }, []);

  const fetchBadgeCount = () => {
    dispatch(
      request(
        apis.fetchBadgeCount,
        apis.serviceTypes.GET,
        {},
        null,
        false,
        false,
        ({notification_count}) =>
          handleBadgeCount({badge_count: notification_count}),
      ),
    );
  };

  return (
    <View style={styles.parent}>
      <BackHeader useDrawer user={user} useNotification />
      <ScrollView bounces={false}>
        <View style={styles.container}>
          <View style={styles.separator} />
          <Buyers />
          <MyListings title="Listings" />
          <MyListings title="My Listings" id={user.id} />
          <UnderContract />
        </View>
      </ScrollView>
    </View>
  );
};

export default Home;

const styles = StyleSheet.create({
  parent: {flex: 1},
  container: {
    flex: 1,
    paddingLeft: Metrics.baseMargin,
    paddingBottom: Metrics.baseMargin,
  },
  containerBuyers: {marginBottom: Metrics.baseMargin},
  containerCat: {marginBottom: Metrics.baseMargin},
  separator: {height: Metrics.baseMargin},
  heading: {...AppStyles.gbSb(20, Colors.primary.black), flex: 1},
  all: {
    ...AppStyles.gbRe(14, Colors.primary.vermillion),
    marginRight: Metrics.baseMargin,
  },
  row: {flexDirection: 'row', paddingBottom: Metrics.smallMargin},
});
