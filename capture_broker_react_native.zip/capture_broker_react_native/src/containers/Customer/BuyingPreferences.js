import React, {useEffect, useRef} from 'react';
import {View, StyleSheet, ScrollView} from 'react-native';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import moment from 'moment';

import {ShadowHeader, SmallBtn} from '@components';
import {
  MaterialTextField,
  BottomActionSheet,
  FormHandlerUpdated,
  ButtonView,
} from '@reuseableComponents';
import {pop, push} from '@nav';
import {Colors, Images, Metrics} from '@theme';

import {useDispatch} from 'react-redux';
import constant from '@constants';
import {request} from '@serviceAction';
import apis from '@apis';
import {BUYERS} from '@actionTypes';
import {generalSaveAction} from '@serviceAction';

export default function ({route}) {
  const formHandlerRef = useRef();
  const bottomSheetRef = useRef();
  const inputPreApprovedRef = useRef();
  const inputPropertyTypeRef = useRef();
  const inputFirstTimeBuyRef = useRef();
  const inputMovingDateRef = useRef();
  const inputSelectedCustomer = useRef();

  const dispatch = useDispatch();

  const buyingQuery = route.params?.buyingQuery;
  const cbOnBuyingQueryUpdated = route.params?.cbOnBuyingQueryUpdated;

  const [state, setState] = React.useState({
    movingDate: new Date(),
    isShowDatePicker: false,
    isDatePicked: false,
    isPropertyTypeSelection: false,
    isFirstTimeBuySelection: false,
    isPreApprovedSelection: false,
    isImageSelection: false,
    selectedPropertyTypeIndex: null,
    selectedPreApprovedIndex: null,
    selectedFirstTimeBuyIndex: null,
    selectedCustomer: null,
  });

  useEffect(() => {
    // setting all selected values in case of edit buying query
    if (buyingQuery) {
      setState({
        movingDate: new Date(buyingQuery.move_date),
        isDatePicked: true,
        selectedPropertyTypeIndex: Object.keys(constant.PROPERTY_TYPES).find(
          key => constant.PROPERTY_TYPES[key] == buyingQuery.house_type,
        ),
        selectedPreApprovedIndex: Object.keys(constant.PRE_APROVED).find(
          key => constant.PRE_APROVED[key] == buyingQuery.pre_approved,
        ),
        selectedFirstTimeBuyIndex: Object.keys(constant.FIRST_TIME_BUYER).find(
          key => constant.PRE_APROVED[key] == buyingQuery.pre_approved,
        ),
        selectedCustomer: buyingQuery.customer,
      });
    }
  }, []);

  const onSubmitForm = () => {
    let isError = false;

    const data = formHandlerRef.current.onSubmitForm();

    if (!state.selectedFirstTimeBuyIndex) {
      isError = true;
      inputFirstTimeBuyRef.current.setError(true, 'First time buy is required');
    }

    if (!state.selectedPreApprovedIndex) {
      isError = true;
      inputPreApprovedRef.current.setError(
        true,
        'Pre approved status is required',
      );
    }

    if (state.selectedPropertyTypeIndex === null) {
      isError = true;
      inputPropertyTypeRef.current.setError(true, 'Property type is required');
    }

    if (!state.isDatePicked) {
      isError = true;
      inputMovingDateRef.current.setError(true, 'Moving date is required');
    }

    if (!state.selectedCustomer) {
      isError = true;
      inputSelectedCustomer.current.setError(true, 'Customer is required');
    }

    // if every thing filled on form then  proceed to property selection
    if (data && !isError) onNext();
  };

  const createProperty = data => {
    const payload = new FormData();
    Object.keys(data).map(key => {
      // this check is for edit buying query case
      if (buyingQuery && key == 'property_id') {
        const propertyIdsOnBuyingQuery = getPropertiesIds(
          buyingQuery.buyer_properties,
        ).join(',');
        // detecting change in property ids for showing different push in different
        // scenarios
        if (propertyIdsOnBuyingQuery !== data[key] && data[key].length) {
          payload.append('is_recommand', 1);
        } else {
          payload.append('is_recommand', 0);
        }
      }
      payload.append(key, data[key]);
    });
    payload.append(
      'house_type',
      constant.PROPERTY_TYPES_OPTIONS[state.selectedPropertyTypeIndex],
    );
    payload.append(
      'first_time_buyer',
      constant.FIRST_TIME_BUYER_OPTIONS[state.selectedFirstTimeBuyIndex],
    );
    payload.append(
      'pre_approved',
      constant.PRE_APPROVED_OPTIONS[state.selectedPreApprovedIndex],
    );
    payload.append(
      'move_date',
      moment(state.movingDate).format(constant.DB_DATE_FORMAT),
    );

    buyingQuery && payload.append('_method', 'put');

    dispatch(
      request(
        buyingQuery
          ? `${apis.createBuyer}/${buyingQuery.slug}`
          : apis.createBuyer,
        apis.serviceTypes.POST,
        payload,
        null,
        true,
        false,
        res => {
          if (buyingQuery) {
            dispatch(generalSaveAction(BUYERS.UPDATE, res));
          } else {
            dispatch(
              generalSaveAction(BUYERS.ADD, {
                ...res,
                isAddAtZero: true,
              }),
            );
          }
          cbOnBuyingQueryUpdated && cbOnBuyingQueryUpdated(res);
          pop();
        },
      ),
    );
  };

  // handling every action sheet item selection here
  // state has the boolen value representing which every sheet was selected by user
  const cbOnPressActionSheet = index => {
    setState(s => {
      if (index && s.isFirstTimeBuySelection) {
        inputFirstTimeBuyRef.current.setError(false);
        return {...s, selectedFirstTimeBuyIndex: index};
      }
      if (index && s.isPreApprovedSelection) {
        inputPreApprovedRef.current.setError(false);
        return {...s, selectedPreApprovedIndex: index};
      }

      if (
        s.isPropertyTypeSelection &&
        index !== constant.PROPERTY_TYPES_OPTIONS.length - 1
      ) {
        inputPropertyTypeRef.current.setError(false);
        return {...s, selectedPropertyTypeIndex: index};
      }

      return s;
    });
  };

  // populating action sheet with appropriate options based on pressed
  // action sheet to show
  const getBottomSheetOptions = () => {
    if (state.isFirstTimeBuySelection) return constant.FIRST_TIME_BUYER_OPTIONS;
    if (state.isPropertyTypeSelection) return constant.PROPERTY_TYPES_OPTIONS;
    if (state.isPreApprovedSelection) return constant.PRE_APPROVED_OPTIONS;
    return ['Cancel'];
  };

  const showActionSheet = sheetToOpen => () => {
    // first setting every sheet selection to false then setting that one true
    // whose on press was triggered its name we have in currying function then
    // showing sheet after some delay to reflect the change.
    setState(prevState => {
      const state = {
        ...prevState,
        isFirstTimeBuySelection: false,
        isPreApprovedSelection: false,
        isPropertyTypeSelection: false,
        isImageSelection: false,
      };
      state[sheetToOpen] = true;
      return state;
    });
    setTimeout(bottomSheetRef.current.showActionSheet, 200);
  };

  const cbOnSelectCustomer = selectedCustomer => {
    setState(s => ({...s, selectedCustomer: selectedCustomer}));
    inputSelectedCustomer.current.setError(false);
  };

  const onSearchUser = () => {
    push('Search', {cbOnSelectCustomer, isLeadSearch: true});
  };

  // receives property ids on this callback of selected properties
  const cbSelectedProperties = selectedProperties => {
    createProperty({
      ...formHandlerRef.current.onSubmitForm(),
      customer_id: state.selectedCustomer.id,
      property_id: selectedProperties.join(','),
    });
  };

  const onNext = () =>
    push('Search', {
      isPropertySearch: true,
      isSearchRecommended: true,
      cbSelectedProperties,
      ...(buyingQuery && {
        selectedPropertyIds: getPropertiesIds(buyingQuery.buyer_properties),
      }),
    });

  const getPropertiesIds = properties =>
    properties.map(({property_id}) => property_id);

  return (
    <View style={styles.container}>
      <ShadowHeader onBack={pop} title="Add Buying Criteria" useShadows />
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}>
        <FormHandlerUpdated ref={formHandlerRef}>
          {(refCollector, onSubmitEditing) => {
            const {text, number} = FormHandlerUpdated.INPUTS(
              refCollector,
              onSubmitEditing,
            );
            return (
              <>
                <View style={{width: '100%'}}>
                  <MaterialTextField
                    label="Client"
                    placeholder="Select Client"
                    rightIcon={Images.icContactList}
                    value={state.selectedCustomer?.name}
                    ref={inputSelectedCustomer}
                  />
                  <ButtonView
                    style={{
                      left: 0,
                      right: 0,
                      bottom: 0,
                      top: 0,
                      position: 'absolute',
                    }}
                    onPress={onSearchUser}
                  />
                </View>
                <MaterialTextField
                  {...text({identifier: 'requirements'})}
                  style={{width: '100%'}}
                  label="Requirements"
                  placeholder="Enter details here..."
                  multiline
                  useBigSpace
                  error="Requirements are required"
                  value={buyingQuery?.requirements}
                  onSubmitEditing={null}
                />
                <MaterialTextField
                  {...number({identifier: 'price'})}
                  style={{width: '100%'}}
                  label="Price"
                  placeholder="Enter price"
                  error="Price is required"
                  value={buyingQuery?.price}
                  isPriceInput
                />
                <MaterialTextField
                  ref={inputPropertyTypeRef}
                  style={{width: '100%'}}
                  label="House Type"
                  placeholder="Select house type"
                  editable={false}
                  rightIcon={Images.icDropdown}
                  onRightPress={showActionSheet('isPropertyTypeSelection')}
                  value={
                    state.selectedPropertyTypeIndex !== null
                      ? constant.PROPERTY_TYPES_OPTIONS[
                          state.selectedPropertyTypeIndex
                        ]
                      : undefined
                  }
                />
                <MaterialTextField
                  ref={inputMovingDateRef}
                  style={{width: '100%'}}
                  label="Moving Date"
                  placeholder={moment(new Date()).format(
                    constant.DB_DATE_FORMAT,
                  )}
                  editable={false}
                  rightIcon={Images.icCalendarField}
                  onRightPress={() =>
                    setState(s => ({...s, isShowDatePicker: true}))
                  }
                  value={
                    state.isDatePicked
                      ? moment(state.movingDate).format(constant.DB_DATE_FORMAT)
                      : undefined
                  }
                />
                <MaterialTextField
                  ref={inputFirstTimeBuyRef}
                  style={{width: '100%'}}
                  label="First time Buyer"
                  placeholder="Yes"
                  editable={false}
                  rightIcon={Images.icDropdown}
                  onRightPress={showActionSheet('isFirstTimeBuySelection')}
                  value={
                    state.selectedFirstTimeBuyIndex
                      ? constant.FIRST_TIME_BUYER_OPTIONS[
                          state.selectedFirstTimeBuyIndex
                        ]
                      : undefined
                  }
                />
                <MaterialTextField
                  ref={inputPreApprovedRef}
                  style={{width: '100%'}}
                  label="Pre Approved"
                  placeholder="Yes"
                  editable={false}
                  rightIcon={Images.icDropdown}
                  onRightPress={showActionSheet('isPreApprovedSelection')}
                  value={
                    state.selectedPreApprovedIndex
                      ? constant.PRE_APPROVED_OPTIONS[
                          state.selectedPreApprovedIndex
                        ]
                      : undefined
                  }
                />
                {/*
                Only show this field when preapproved is yes
                */}
                {state.selectedPreApprovedIndex == 1 && (
                  <MaterialTextField
                    {...text({identifier: 'company_name'})}
                    style={{width: '48%'}}
                    label="Company Name"
                    placeholder="Enter company name"
                    error="Company name is required"
                    value={buyingQuery?.company_name}
                  />
                )}

                {/*
                Only show this field when preapproved is yes
                */}
                {state.selectedPreApprovedIndex == 1 && (
                  <MaterialTextField
                    {...text({identifier: 'amount'})}
                    style={{width: '48%'}}
                    label="Amount"
                    placeholder="Enter amount"
                    error="Amount is required"
                    keyboardType="numeric"
                    value={buyingQuery?.amount}
                    isPriceInput
                  />
                )}
              </>
            );
          }}
        </FormHandlerUpdated>
        <SmallBtn
          style={{width: '48%', marginTop: Metrics.xDoubleBaseMargin}}
          bgColor={Colors.primary.darkslateblue}
          useBold
          title="Cancel"
          onPress={pop}
        />
        <SmallBtn
          style={{width: '48%', marginTop: Metrics.xDoubleBaseMargin}}
          bgColor={Colors.primary.clearblue}
          useBold
          title="Next"
          onPress={onSubmitForm}
        />
      </ScrollView>
      <DateTimePickerModal
        date={state.movingDate}
        isVisible={state.isShowDatePicker}
        mode="date"
        onConfirm={movingDate => {
          inputMovingDateRef.current.setError(false);
          setState(s => ({
            ...s,
            isDatePicked: true,
            isShowDatePicker: false,
            movingDate,
          }));
        }}
        onCancel={() => setState(s => ({...s, isShowDatePicker: false}))}
        minimumDate={new Date()}
      />
      <BottomActionSheet
        ref={bottomSheetRef}
        options={getBottomSheetOptions()}
        cbOnPressActionSheet={cbOnPressActionSheet}
        cancelButtonIndex={
          state.isPropertyTypeSelection
            ? constant.PROPERTY_TYPES_OPTIONS.length - 1
            : 0
        }
        destructiveButtonIndex={
          state.isPropertyTypeSelection
            ? constant.PROPERTY_TYPES_OPTIONS.length - 1
            : 0
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
    paddingBottom: Metrics.xDoubleBaseMargin,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
});
