import React, {useState} from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import {EventBusSingleton} from 'light-event-bus';

import {BigBtn, ShadowHeader} from '../../components';
import {ImageHandlerUpdated} from '../../reuseableComponents';
import {navigate, pop} from '../../services/NavigationService';
import {Colors, Fonts, Images, Metrics} from '../../theme';

// redux imports
import {useDispatch} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';
import utility from '@utils';
import {generalSaveAction} from '@serviceAction';
import {LEADS} from '@actionTypes';
import {SEARCH} from '@actionTypes';

export default Lead = ({route}) => {
  // const {lead} = route.params;
  const dispatch = useDispatch();

  const [lead, setLead] = useState(route.params.lead);

  const onDelete = () =>
    EventBusSingleton.publish('popup', {
      val: 'lead',
      onAccept: deleteLead,
    });

  const deleteLead = () =>
    dispatch(
      request(
        `${apis.addLead}/${lead.slug}`,
        apis.serviceTypes.DELETE,
        {},
        null,
        true,
        null,
        () => {
          pop();
          dispatch(
            generalSaveAction(LEADS.DELETE, {isDeleteObj: true, ...lead}),
          );
          setTimeout(
            () =>
              dispatch(
                generalSaveAction(SEARCH.DELETE, {isDeleteObj: true, ...lead}),
              ),
            100,
          );
        },
      ),
    );

  const sendInvitation = () => {
    dispatch(
      request(
        apis.sendInvitationLead,
        apis.serviceTypes.GET,
        {
          lead_id: lead.id,
        },
        null,
        true,
        false,
        () => utility.showFlashMessage('Invitation has been sent', 'success'),
      ),
    );
  };

  const {
    name,
    email,
    mobile_no,
    address,
    invitation_acceptance,
    image_url,
    state,
    city,
    zipcode,
  } = lead;

  const cbOnLeadUpdated = lead => {
    setLead(_ => lead);
  };

  const onUpdate = () => navigate('AddLead', {lead, cbOnLeadUpdated});

  return (
    <View style={styles.container}>
      <ShadowHeader
        onRightPress={onUpdate}
        rightImg={Images.icEdit}
        useShadows
        rightTxt="Edit"
        onBack={pop}
        useBorderLess
      />
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}>
        <View style={styles.content}>
          <ImageHandlerUpdated
            isProfileImage
            style={styles.img}
            source={{uri: image_url}}
            isZoomViewerEnabled
          />
          <Text style={styles.heading}>{name}</Text>
          <Text style={styles.tileTxt2}>Phone</Text>
          <Text style={styles.tileDesc2}>{mobile_no}</Text>
          <Text style={styles.tileTxt2}>Email</Text>
          <Text style={styles.tileDesc2}>{email}</Text>
          <Text style={styles.tileTxt2}>Address</Text>
          <Text style={styles.tileDesc2}>{address}</Text>
          <Text style={styles.tileTxt2}>App Status</Text>
          <Text style={styles.tileDesc2}>{invitation_acceptance}</Text>
          <Text style={styles.tileTxt2}>State</Text>
          <Text style={styles.tileDesc2}>{state}</Text>
          <Text style={styles.tileTxt2}>City</Text>
          <Text style={styles.tileDesc2}>{city}</Text>
          <Text style={styles.tileTxt2}>Zip Code</Text>
          <Text style={styles.tileDesc2}>{zipcode}</Text>
        </View>
        <View style={styles.btnContainer}>
          <BigBtn
            useSmall
            useMargin
            title="DELETE LEAD"
            bgColor={Colors.primary.coral}
            onPress={onDelete}
          />
          <BigBtn
            onPress={sendInvitation}
            useSmall
            useMargin
            title="SEND INVITE"
            margin={Metrics.baseMargin}
          />
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {},
  scrollContent: {
    flexGrow: 1,
    marginHorizontal: Metrics.baseMargin,
    paddingBottom: Metrics.xDoubleBaseMargin,
  },
  img: {
    width: Metrics.widthRatio(130),
    height: Metrics.widthRatio(130),
    borderRadius: Metrics.smallMargin,
    alignSelf: 'center',
    marginTop: Metrics.baseMargin,
  },
  heading: {
    ...Fonts.font({
      size: 18,
      color: Colors.primary.darkslateblue,
    }),
    textAlign: 'center',
    marginTop: Metrics.baseMargin,
  },
  tileTxt2: {
    ...Fonts.font({
      size: 12,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: Metrics.doubleBaseMargin,
  },
  tileDesc2: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginTop: 8,
  },
  btnContainer: {},
});
