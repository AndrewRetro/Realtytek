import React, {useEffect, useState} from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import {EventBusSingleton} from 'light-event-bus';
import moment from 'moment';

import RecommendedHomes from '@containers/Customer/RecommendedHomes';
import TouredHomes from '@containers/Customer/TouredHomes';
import {AbsoluteHeader, BigBtn, SmallBtn} from '@components';
import {ButtonView, ImageHandlerUpdated} from '@reuseableComponents';

import {pop, push} from '@nav';
import {Colors, Fonts, Metrics} from '@theme';
import {navigate} from '@nav';
import constants from '@constants';
import {useDispatch} from 'react-redux';
import {generalSaveAction} from '@serviceAction';
import {RECOMENDED_HOMES, TOURED_HOMES} from '@actionTypes';
import {request} from '@serviceAction';
import apis from '@apis';
import {BUYERS} from '@actionTypes';
import utility from '@utils';

export default function ({route, navigation}) {
  const dispatch = useDispatch();

  const [buyingQuery, setBuyingQuery] = useState(route.params.buyingQuery);

  const {customer, slug} = buyingQuery;
  const {name, image_url, email, mobile_no} = customer;
  const {move_date, price, requirements, house_type, company_name, amount} =
    buyingQuery;

  let isPopToTop = false;
  if (route.params && route.params.isPopToTop) {
    isPopToTop = true;
  }

  useEffect(
    () => () => {
      dispatch(generalSaveAction(RECOMENDED_HOMES.SUCCESS, []));
      setTimeout(
        () => dispatch(generalSaveAction(TOURED_HOMES.SUCCESS, [])),
        200,
      );
    },
    [],
  );

  const onDelete = () => {
    dispatch(
      request(
        `${apis.createBuyer}/${slug}`,
        apis.serviceTypes.POST,
        {_method: 'delete'},
        null,
        true,
        false,
        () => {
          dispatch(
            generalSaveAction(BUYERS.DELETE, {
              isDeleteObj: true,
              ...buyingQuery,
            }),
          );
          utility.showFlashMessage('Successfully deleted', 'success');
          pop();
        },
      ),
    );
  };

  const onDeleteBuyer = () => {
    EventBusSingleton.publish('popup', {
      val: 'buyer',
      onAccept: onDelete,
    });
  };

  const onAllRecommendedHomes = () =>
    navigate('RecommendedHomes', {idBuyingQuery: buyingQuery.id});

  const onAllTouredHomes = () =>
    navigate('TouredHomes', {idBuyingQuery: buyingQuery.id});

  const onRecommendHomes = () =>
    push('Search', {
      isPropertySearch: true,
      isSearchRecommended: true,
      isShowSelection: true,
      cbSelectedProperties,
      ...(buyingQuery && {
        selectedPropertyIds: buyingQuery.buyer_properties.map(
          ({property_id}) => property_id,
        ),
      }),
    });

  const cbSelectedProperties = properties => updateBuyingQuery(properties);

  // this update happens from recommend button
  const updateBuyingQuery = properties => {
    let is_recommand = 0;
    const selectedPropertyIds = properties;

    if (
      selectedPropertyIds.join(',') !==
      getPropertiesIds(buyingQuery.buyer_properties).join(',')
    )
      is_recommand = 1;

    const payload = {
      requirements: buyingQuery.requirements,
      price: buyingQuery.price,
      customer_id: buyingQuery.customer_id,
      property_id: properties.join(','),
      house_type: buyingQuery.house_type,
      first_time_buyer: buyingQuery.first_time_buyer,
      pre_approved: buyingQuery.pre_approved,
      move_date: buyingQuery.move_date,
      is_recommand,
      _method: 'put',
    };

    dispatch(
      request(
        `${apis.createBuyer}/${buyingQuery.slug}`,
        apis.serviceTypes.POST,
        payload,
        null,
        true,
        false,
        res => {
          dispatch(generalSaveAction(BUYERS.UPDATE, res));
          pop();
        },
      ),
    );
  };

  const getPropertiesIds = properties =>
    properties.map(({property_id}) => property_id);

  const cbOnBuyingQueryUpdated = buyingQuery => {
    setBuyingQuery(s => buyingQuery);
  };

  const LendersInfo = () =>
    company_name ? (
      <View style={styles.containerLenders}>
        <Text style={styles.heading}>Lender Info</Text>
        <View style={styles.leaderWrapper}>
          <Text style={[styles.desc, {marginTop: 0, marginBottom: 0}]}>
            {company_name}
          </Text>
          <Text style={styles.amount}>{`$${amount}`}</Text>
        </View>
      </View>
    ) : null;

  return (
    <View style={styles.container}>
      <AbsoluteHeader
        useRelative
        title="Client Profile"
        showRight
        isPopToTop={isPopToTop}
        navigation={navigation}
        onPressCall={utility.call(mobile_no)}
        onPressEmail={utility.email(email)}
      />
      <ScrollView
        contentContainerStyle={styles.scrollStyle}
        showsVerticalScrollIndicator={false}>
        <View style={styles.personalDetails}>
          <ImageHandlerUpdated
            source={{uri: image_url}}
            style={styles.imgProfile}
          />
          <View style={styles.personalDetailsWrapper}>
            <Text style={styles.nameTxt}>{name}</Text>
            <View style={{flexDirection: 'row'}}>
              <View style={{flex: 0.5}}>
                <Text style={styles.tileHeader}>Moving Date</Text>
                <Text style={styles.tileDesc}>
                  {moment(move_date).format(constants.DISPLAY_DATE_FORMAT)}
                </Text>
              </View>
              <View style={{flex: 0.5}}>
                <Text style={styles.tileHeader}>Max Range</Text>
                <Text style={styles.tileDesc}>
                  {utility.formateCurrency(price)}
                </Text>
              </View>
            </View>
          </View>
        </View>
        <View style={styles.content}>
          <Text style={styles.heading}>Requirements</Text>
          <Text style={styles.desc}>{requirements}</Text>
          <Text style={styles.heading}>House Type</Text>
          <Text style={styles.desc}>{house_type}</Text>

          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text style={styles.heading}>Recommended Homes</Text>
            <ButtonView
              onPress={onAllRecommendedHomes}
              style={{padding: Metrics.baseMargin}}>
              <Text style={styles.btnTxt}>View All</Text>
            </ButtonView>
          </View>

          <RecommendedHomes
            isHorizontal
            idBuyingQuery={buyingQuery.id}
            buyingQuery={buyingQuery}
          />

          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text style={styles.heading}>Toured Homes</Text>
            <ButtonView
              onPress={onAllTouredHomes}
              style={{padding: Metrics.baseMargin}}>
              <Text style={styles.btnTxt}>View All</Text>
            </ButtonView>
          </View>
          <TouredHomes isHorizontal idBuyingQuery={buyingQuery.id} />

          <LendersInfo />

          <BigBtn
            title="Recommend Home"
            style={{
              width: '95.5%',
              height: Metrics.widthRatio(45),
              marginTop: Metrics.baseMargin,
            }}
            onPress={onRecommendHomes}
          />

          <View style={styles.btnContainer}>
            <SmallBtn
              useBold
              style={styles.btn}
              title="Delete"
              bgColor={Colors.primary.coral}
              onPress={onDeleteBuyer}
            />
            <SmallBtn
              useBold
              title="Edit"
              style={styles.btn}
              bgColor={Colors.primary.darkslateblue}
              onPress={() =>
                navigate('BuyingPreferences', {
                  buyingQuery,
                  cbOnBuyingQueryUpdated,
                })
              }
            />
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginLeft: Metrics.baseMargin,
    marginTop: Metrics.doubleBaseMargin,
  },
  personalDetails: {
    paddingVertical: Metrics.smallMargin,
    paddingHorizontal: Metrics.baseMargin,
    backgroundColor: Colors.primary.slate,
    flexDirection: 'row',
  },
  nameTxt: {
    ...Fonts.font({
      size: 20,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.white,
    }),
  },
  personalDetailsWrapper: {
    marginLeft: Metrics.baseMargin,
    justifyContent: 'space-between',
    flex: 1,
  },
  tileHeader: {
    ...Fonts.font({
      size: 12,
      color: Colors.primary.white,
    }),
    opacity: 0.5,
  },
  tileDesc: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.white,
    }),
    marginTop: Metrics.heightRatio(9),
  },
  heading: {
    ...Fonts.font({
      size: 16,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.slate,
    }),
  },
  desc: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.slate,
    }),
    marginTop: Metrics.smallMargin,
    marginBottom: Metrics.doubleBaseMargin,
  },
  btnTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.vermillion,
    }),
  },
  listCardStyle: {
    marginTop: 0,
    marginLeft: 0,
    width: Metrics.screenWidth * 0.8,
  },
  scrollStyle: {
    paddingBottom: Metrics.xDoubleBaseMargin,
  },
  amount: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.clearblue,
    }),
  },
  leaderWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginRight: Metrics.baseMargin,
    paddingHorizontal: Metrics.smallMargin,
    paddingVertical: Metrics.baseMargin,
    backgroundColor: Colors.primary.white,
    marginTop: Metrics.baseMargin,
    borderRadius: 4,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,

    elevation: 1,
  },
  btn: {
    width:
      (Metrics.screenWidth - 2 * Metrics.baseMargin - Metrics.smallMargin) / 2,
  },
  btnContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Metrics.baseMargin,
    marginRight: Metrics.baseMargin,
  },
  imgProfile: {
    width: Metrics.widthRatio(75),
    height: Metrics.widthRatio(81),
    borderRadius: Metrics.widthRatio(6),
  },
  containerLenders: {
    marginTop: Metrics.baseMargin,
  },
});
