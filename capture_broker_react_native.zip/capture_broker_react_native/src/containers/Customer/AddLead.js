import React from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';

import {
  FormHandler,
  MaterialTextField,
  ButtonView,
  ImageHandlerUpdated,
  BottomActionSheet,
} from '@reuseableComponents';
import {INPUT_TYPES} from '@reuseableComponents/FormHandler/Constants';
import {ShadowHeader, SmallBtn, MaskedInput} from '@components';

import {pop} from '@services/NavigationService';
import {AppStyles, Colors, Fonts, Images, Metrics} from '../../theme';
import {selectSingleImage, selectCameraImage} from '@services/MultipickerUtils';

// redux imports
import {useDispatch} from 'react-redux';
import constants from '@constants';
import apis from '@apis';
import {request, generalSaveAction} from '@serviceAction';
import {LEADS} from '@actionTypes';
import {SEARCH} from '@actionTypes';

export default function ({route}) {
  const lead = route?.params?.lead;

  const formHandler = React.useRef();
  const imageBottomSheetRef = React.useRef();

  const dispatch = useDispatch();
  const [state, setState] = React.useState({
    img: lead ? {path: lead.image_url} : null,
    isFormSubmitted: false,
    isImgPicked: false,
  });

  const onCreateLead = payload => {
    dispatch(
      request(
        lead ? `${apis.addLead}/${lead.slug}` : apis.addLead,
        apis.serviceTypes.POST,
        payload,
        null,
        true,
        false,
        res => {
          if (lead) {
            route.params.cbOnLeadUpdated(res);
            dispatch(generalSaveAction(LEADS.UPDATE, res));
            setTimeout(() => {
              dispatch(generalSaveAction(SEARCH.UPDATE, res));
            }, 100);
          } else {
            dispatch(generalSaveAction(LEADS.ADD, {...res, isAddAtZero: true}));
          }
          pop();
        },
        () => {},
      ),
    );
  };

  const onSubimtForm = () => {
    const payload = formHandler.current.onSubmitForm();

    if (payload) {
      const formData = new FormData();
      const {img, isImgPicked} = state;
      isImgPicked &&
        formData.append('image_url', {
          name: 'image',
          uri: img.path,
          type: img.mime,
        });
      lead && formData.append('_method', 'put');
      formData.append('user_group_id', constants.USER_GROUPS.USER_GROUP_ID_2);
      Object.keys(payload).map(key => formData.append(key, payload[key]));
      onCreateLead(formData);
    }

    setState(s => ({...s, isFormSubmitted: true}));
  };

  const onSelectImg = index =>
    index == 1
      ? setTimeout(
          () =>
            selectCameraImage().then(img => {
              setState(s => ({...s, img, isImgPicked: true}));
            }),
          400,
        )
      : setTimeout(
          () =>
            selectSingleImage().then(img =>
              setState(s => ({...s, img, isImgPicked: true})),
            ),
          400,
        );

  const cbOnImageSelection = () =>
    imageBottomSheetRef.current.showActionSheet();

  cbImageOptionSelected = index => {
    index && onSelectImg(index);
  };

  return (
    <View style={styles.container}>
      <ShadowHeader useShadows onBack={pop} title="Add Lead" />
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}>
        <View>
          <View style={styles.imgWrapper}>
            <ButtonView onPress={cbOnImageSelection}>
              <ImageHandlerUpdated
                source={state.img ? {uri: state.img.path} : Images.icAddImage}
                style={styles.img}
                isProfileImage
              />
            </ButtonView>
            <Text style={styles.imgTxt}>Add Image</Text>
          </View>

          <FormHandler ref={formHandler}>
            <MaterialTextField
              label="Full Name"
              placeholder="Enter name"
              type={INPUT_TYPES.TEXT}
              identifier="name"
              error="Full name is required"
              value={lead?.name}
              blurOnSubmit={false}
              returnKeyType="next"
            />
            <MaskedInput
              label="Phone Number"
              placeholder="Enter phone number"
              type={INPUT_TYPES.NUMBER}
              identifier="mobile_no"
              error="Phone number is required"
              value={lead?.mobile_no}
              blurOnSubmit={false}
              returnKeyType="next"
              rightIcon={Images.icContactList}
              onRightPress={null}
            />
            <MaterialTextField
              label="Email Address"
              placeholder="Enter email address"
              type={INPUT_TYPES.EMAIL}
              identifier="email"
              error="email is required"
              value={lead?.email}
              blurOnSubmit={false}
              returnKeyType="next"
            />
            <MaterialTextField
              label="Street Address"
              placeholder="Enter address"
              type={INPUT_TYPES.TEXT}
              identifier="address"
              error="address is required"
              value={lead?.address}
              returnKeyType="next"
              blurOnSubmit={false}
            />
            <MaterialTextField
              label="State"
              placeholder="Enter state"
              type={INPUT_TYPES.TEXT}
              identifier="state"
              error="state is required"
              value={lead?.state}
              returnKeyType="next"
              blurOnSubmit={false}
            />
            <MaterialTextField
              label="City"
              placeholder="Enter city"
              type={INPUT_TYPES.TEXT}
              identifier="city"
              error="city is required"
              value={lead?.city}
              returnKeyType="next"
              blurOnSubmit={false}
            />
            <MaterialTextField
              label="Zip Code"
              placeholder="Enter zipcode"
              type={INPUT_TYPES.TEXT}
              identifier="zipcode"
              error="zip code is required"
              value={lead?.zipcode}
              returnKeyType="done"
              blurOnSubmit
            />
          </FormHandler>
        </View>
        <View style={styles.btnContainer}>
          <SmallBtn
            useBold
            style={styles.btn}
            title="Cancel"
            bgColor={Colors.primary.darkslateblue}
            onPress={pop}
          />
          <SmallBtn
            useBold
            title={lead ? 'Update' : 'Add'}
            style={styles.btn}
            bgColor={Colors.primary.clearblue}
            onPress={onSubimtForm}
          />
        </View>
      </ScrollView>
      <BottomActionSheet
        ref={imageBottomSheetRef}
        options={['Cancel', 'Camera', 'Photo Album']}
        cbOnPressActionSheet={cbImageOptionSelected}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flexGrow: 1,
    justifyContent: 'space-between',
    marginHorizontal: Metrics.baseMargin,
    paddingTop: Metrics.baseMargin,
    paddingBottom: Metrics.xDoubleBaseMargin,
  },
  imgTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginLeft: Metrics.baseMargin,
  },
  imgWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  btn: {
    width:
      (Metrics.screenWidth - 2 * Metrics.baseMargin - Metrics.smallMargin) / 2,
  },
  btnContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Metrics.xDoubleBaseMargin,
  },
  img: {
    width: Metrics.widthRatio(70),
    height: Metrics.widthRatio(70),
    resizeMode: 'contain',
    borderRadius: Metrics.smallMargin,
  },
  imgErr: {
    ...AppStyles.gbRe(10, Colors.primary.vermillion),
    marginTop: Metrics.smallMargin,
  },
});
