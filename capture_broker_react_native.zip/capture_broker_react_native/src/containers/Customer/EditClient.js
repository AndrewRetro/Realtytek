import React from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import {ShadowHeader, SmallBtn} from '../../components';
import {FormHandler, MaterialTextField} from '../../reuseableComponents';
import {INPUT_TYPES} from '../../reuseableComponents/FormHandler/Constants';
import {navigate, pop} from '../../services/NavigationService';
import {Colors, Fonts, Images, Metrics} from '../../theme';

export default function () {
  return (
    <View style={styles.container}>
      <ShadowHeader useShadows title="Edit Buyer" onBack={pop} />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}>
        <FormHandler>
          <MaterialTextField
            label="Select Customer"
            placeholder="Natasha Cooper"
            rightIcon={Images.icContactList}
            type={INPUT_TYPES.TEXT}
          />
          <MaterialTextField
            label="Requirements"
            placeholder="Enter details here..."
            multiline
            useBigSpace
            type={INPUT_TYPES.TEXT}
          />
          <MaterialTextField
            label="Price"
            placeholder="$325,000"
            type={INPUT_TYPES.NUMBER}
          />
          <MaterialTextField
            label="House Type"
            placeholder="SF"
            rightIcon={Images.icDropdown}
            editable={false}
            type={INPUT_TYPES.TEXT}
          />
          <MaterialTextField
            label="When would you like to move"
            placeholder="dd-mm-yy"
            editable={false}
            rightIcon={Images.icCalendarField}
            type={INPUT_TYPES.TEXT}
          />
          <MaterialTextField
            label="First time Buyer"
            placeholder="Yes"
            editable={false}
            rightIcon={Images.icDropdown}
            type={INPUT_TYPES.TEXT}
          />
          <MaterialTextField
            label="Pre Approved"
            placeholder="Yes"
            editable={false}
            rightIcon={Images.icDropdown}
            type={INPUT_TYPES.TEXT}
          />
        </FormHandler>
        <Text style={styles.heading}>Lenders Info</Text>
        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
          <MaterialTextField
            style={{
              width: '45%',
            }}
            label="Company Name"
            placeholder="Navy Federal CU"
            type={INPUT_TYPES.TEXT}
          />
          <MaterialTextField
            style={{
              width: '45%',
            }}
            label="Amount"
            placeholder="$375,000"
            type={INPUT_TYPES.NUMBER}
          />
        </View>
        <View style={styles.btnContainer}>
          <SmallBtn
            useBold
            style={styles.btn}
            title="Cancel"
            bgColor={Colors.primary.darkslateblue}
          />
          <SmallBtn
            useBold
            title="Save"
            style={styles.btn}
            bgColor={Colors.primary.clearblue}
            onPress={pop}
          />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
    paddingBottom: Metrics.xDoubleBaseMargin,
  },
  heading: {
    ...Fonts.font({
      size: 16,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.slate,
    }),
    marginTop: Metrics.xDoubleBaseMargin,
  },
  btn: {
    width:
      (Metrics.screenWidth - 2 * Metrics.baseMargin - Metrics.smallMargin) / 2,
  },
  btnContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Metrics.xDoubleBaseMargin,
  },
});
