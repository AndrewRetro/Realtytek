import React, {useMemo} from 'react';
import {View, StyleSheet, TextInput} from 'react-native';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {ListingCards, ShadowHeader, SmallBtn} from '../../components';
import {FlatListHandler, ImageHandler} from '../../reuseableComponents';
import {navigate, pop} from '../../services/NavigationService';
import {Colors, Images, Metrics} from '../../theme';

const dummyData = [
  {
    id: '1',
    checked: true,
    amount: '350000',
    image_url: Images.icPlace,
    address: '235 Elm Street, Los Angeles, CA',
    name: 'Luxury Villa Available @ Maddison Valley',
  },
  {
    id: '2',
    checked: false,
    amount: '350000',
    image_url: Images.icPlace2,
    address: '235 Elm Street, Los Angeles, CA',
    name: 'Luxury Villa Available @ Maddison Valley',
  },
];

export default function () {
  const {bottom} = useSafeAreaInsets();
  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
        },
        searchContainer: {
          borderRadius: 4,
          flexDirection: 'row',
          alignItems: 'center',
          marginTop: Metrics.baseMargin,
          marginBottom: Metrics.smallMargin,
          marginHorizontal: Metrics.baseMargin,
          backgroundColor: Colors.primary.white,
          shadowColor: 'rgba(0, 0, 0, 0.1)',
          shadowOffset: {
            width: 0,
            height: 10,
          },
          shadowRadius: 10,
          shadowOpacity: 1,
          elevation: 1,
        },
        searchImg: {
          width: 16,
          height: 16,
          tintColor: Colors.primary.slate,
          marginHorizontal: Metrics.baseMargin,
        },
        footer: {
          alignItems: 'center',
          paddingBottom: bottom,
          justifyContent: 'center',
          backgroundColor: Colors.primary.white,
          height: Metrics.heightRatio(82) + bottom,
        },
        input: {
          color: Colors.primary.darkslateblue,
          paddingVertical: Metrics.heightRatio(14),
          flex: 1,
        },
      }),
    [bottom],
  );

  return (
    <View style={styles.container}>
      <ShadowHeader onBack={pop} useShadows title="Recommend Homes" />
      <FlatListHandler
        ListHeaderComponent={() => (
          <View style={styles.searchContainer}>
            <ImageHandler style={styles.searchImg} source={Images.icSearch} />
            <TextInput
              style={styles.input}
              placeholder="Search here..."
              placeholderTextColor={Colors.primary.slate}
            />
          </View>
        )}
        data={dummyData}
        renderItem={({item}) => <ListingCards item={item} />}
      />
      <View style={styles.footer}>
        <SmallBtn
          onPress={() => navigate('ClientProfile', {isPopToTop: true})}
          useBold
          title="Done"
          style={{width: '48%'}}
          bgColor={Colors.primary.clearblue}
        />
      </View>
    </View>
  );
}
