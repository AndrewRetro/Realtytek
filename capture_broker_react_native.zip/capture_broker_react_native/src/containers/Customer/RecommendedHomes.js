import React from 'react';
import {View} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import PropTypes from 'prop-types';

import {ListingCards, ShadowHeader} from '@components';
import {FlatListHandler} from '@reuseableComponents';

import apis from '@apis';
import {navigate, pop} from '@nav';
import {RECOMENDED_HOMES} from '@actionTypes';
import {request} from '@serviceAction';
import {Metrics} from '@theme';

const RecomendedHomes = ({isHorizontal, idBuyingQuery, route}) => {
  const dispatch = useDispatch();
  const recommendedHomes = useSelector(
    ({recommendedHomes}) => recommendedHomes,
  );

  React.useEffect(() => {
    !recommendedHomes.data.length && fetchRecomendedHomes();
  }, []);

  React.useEffect(() => {
    !recommendedHomes.data.length && fetchRecomendedHomes();
  }, [idBuyingQuery]);

  const fetchRecomendedHomes = (isConcat = false, page = 1) => {
    dispatch(
      request(
        apis.recomendedHomes,
        apis.serviceTypes.GET,
        {
          page,
          limit: 10,
          buyer_id: isHorizontal ? idBuyingQuery : route.params.idBuyingQuery,
        },
        RECOMENDED_HOMES,
        false,
        isConcat,
        null,
        null,
        RECOMENDED_HOMES,
      ),
    );
  };

  const cardStyle = {
    margin: isHorizontal ? 0 : Metrics.baseMargin,
  };

  const imgStyle = isHorizontal
    ? {
        width: Metrics.screenWidth - Metrics.widthRatio(80),
        height: Metrics.widthRatio(145),
      }
    : {};

  const renderProperties = ({item}) => (
    <ListingCards
      onPress={() => navigate('PropertyDetail')}
      item={{...item, ...item.property}}
      style={cardStyle}
      imgStyle={imgStyle}
    />
  );

  const renderItemSeparator = () => (
    <View style={{width: Metrics.baseMargin}} />
  );

  const containerStyle = {
    ...(isHorizontal && {height: Metrics.widthRatio(210)}),
    ...(!isHorizontal && {flex: 1}),
  };

  const contentContainerStyle = {
    ...(isHorizontal && {paddingRight: Metrics.baseMargin}),
  };

  return (
    <View style={containerStyle}>
      {!isHorizontal && (
        <ShadowHeader onBack={pop} useShadows title="Recommended Homes" />
      )}
      <FlatListHandler
        fetchRequest={isHorizontal ? null : fetchRecomendedHomes}
        data={recommendedHomes.data}
        meta={recommendedHomes.meta}
        isFetching={recommendedHomes.isFetching}
        renderItem={renderProperties}
        horizontal={isHorizontal}
        bounces={isHorizontal ? false : true}
        ItemSeparatorComponent={renderItemSeparator}
        contentContainerStyle={contentContainerStyle}
      />
    </View>
  );
};

RecomendedHomes.propTypes = {
  isHorizontal: PropTypes.bool,
  idBuyingQuery: PropTypes.number,
};

RecomendedHomes.defaultProps = {
  isHorizontal: false,
  idBuyingQuery: -1,
};

export default RecomendedHomes;

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//   },
// });
