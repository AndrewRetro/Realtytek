import React, {useState} from 'react';
import {View, Text, StyleSheet, ScrollView, Image} from 'react-native';

import {
  AbsoluteHeader,
  PropertyDetails,
  ContractStatus,
  LoanInfo,
  SmallBtn,
} from '../../components';
import {Colors, Images, Metrics, Fonts} from '../../theme';
import {ImageHandlerUpdated} from '../../reuseableComponents';
import constants from '@constants';
import utility from '@utils';

const dummyData = [
  {
    heading: 'Property Detail',
    tab: 'Details',
  },
  {
    heading: 'Listing Contract Details',
    tab: 'Contract Status',
  },
  {
    heading: 'Listing Contract Details',
    tab: 'Loan Info',
  },
];

export default function ({route}) {
  const {initiate_buyer_property, customer, status} = route.params.contract;
  const {property} = initiate_buyer_property;
  const {image_url} = property;

  const [state, setState] = useState({
    activeTab: 0,
    contractStatus: null,
    loanInfo: null,
  });
  const {activeTab} = state;

  const cbSetContractStatus = contractStatus =>
    setState(s => ({...s, contractStatus}));

  const cbSetLoanInfo = loanInfo => {
    setState(s => ({...s, loanInfo}));
  };

  const Profile = () => {
    const {
      image_url: imgUrlProfile,
      name,
      address,
      email,
      mobile_no,
    } = customer;

    return (
      <View style={styles.personalDetails}>
        <View style={{flexDirection: 'row', flex: 1}}>
          <ImageHandlerUpdated
            style={styles.imgProfile}
            source={{uri: imgUrlProfile}}
          />
          <View style={styles.personalDetailsWrapper}>
            <Text style={styles.nameTxt}>{name}</Text>
            <View style={styles.wrapperLoc}>
              <Image
                style={{tintColor: Colors.primary.white}}
                source={Images.icLocation}
              />
              <Text style={styles.txtAddress}>{address}</Text>
            </View>
          </View>
        </View>
        <View style={styles.wrapperContractStatus}>
          <View>
            <Text style={styles.txtStatusHeader}>Contract Status</Text>
            <Text style={styles.txtStatus}>
              {status == 1 ? constants.CONTRACT_STATUS_ACTIVE : ''}
            </Text>
          </View>
          <View style={{flexDirection: 'row'}}>
            <SmallBtn
              title="Chat"
              tintColor={Colors.primary.clearblue}
              txtColor={Colors.primary.clearblue}
              bgColor={Colors.primary.white}
              icon={Images.icChat}
              onPress={utility.chat(mobile_no)}
            />
            <SmallBtn
              title="Call"
              style={{marginLeft: Metrics.smallMargin}}
              tintColor={Colors.primary.clearblue}
              txtColor={Colors.primary.clearblue}
              bgColor={Colors.primary.white}
              onPress={utility.call(mobile_no)}
              icon={Images.icPhone}
            />
            <SmallBtn
              style={{marginLeft: Metrics.smallMargin}}
              bgColor={Colors.primary.darkslateblue}
              icon={Images.icEmail}
              title="Email"
              onPress={utility.email(email)}
            />
          </View>
        </View>
      </View>
    );
  };

  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <ImageHandlerUpdated style={styles.cover} source={{uri: image_url}} />
      <AbsoluteHeader title="Contract Details" showRight={false} />
      <Profile />
      <View style={styles.content}>
        <View style={styles.btnContainer}>
          {dummyData.map((ele, index) => (
            <SmallBtn
              key={ele.tab}
              useBold
              useRegularTxt
              txtSize={14}
              style={styles.btn}
              title={ele.tab}
              txtColor={
                activeTab === index
                  ? Colors.primary.white
                  : `${Colors.primary.slate}`
              }
              bgColor={
                activeTab === index
                  ? Colors.primary.clearblue
                  : Colors.primary.white
              }
              onPress={() =>
                setState(prevState => ({...prevState, activeTab: index}))
              }
            />
          ))}
        </View>
        {activeTab === 0 ? (
          <PropertyDetails property={property} />
        ) : activeTab === 1 ? (
          <ContractStatus
            property={property}
            cbSetContractStatus={cbSetContractStatus}
            contractStatus={state.contractStatus}
          />
        ) : (
          <LoanInfo
            property={property}
            loanInfo={state.loanInfo}
            cbSetLoanInfo={cbSetLoanInfo}
          />
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  cover: {
    width: Metrics.screenWidth,
    height: Metrics.heightRatio(308),
  },
  personalDetails: {
    paddingVertical: Metrics.smallMargin,
    paddingHorizontal: Metrics.baseMargin,
    backgroundColor: Colors.primary.clearblue,
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
    marginTop: Metrics.baseMargin,
    marginBottom: Metrics.xDoubleBaseMargin,
  },
  nameTxt: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.white,
    }),
  },
  personalDetailsWrapper: {
    marginLeft: Metrics.baseMargin,
    flex: 1,
  },
  btnContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  btn: {
    width:
      (Metrics.screenWidth - 2 * Metrics.baseMargin - 2 * Metrics.smallMargin) /
      3,
  },
  imgProfile: {
    width: Metrics.widthRatio(75),
    height: Metrics.widthRatio(81),
    borderRadius: Metrics.widthRatio(4),
  },
  wrapperLoc: {
    flexDirection: 'row',
    marginTop: Metrics.smallMargin,
    alignItems: 'center',
  },
  txtAddress: {
    ...Fonts.font({
      size: 12,
      color: Colors.primary.white,
    }),
    marginLeft: Metrics.smallMargin,
  },
  wrapperContractStatus: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Metrics.smallMargin,
    alignItems: 'center',
  },
  txtStatusHeader: {
    ...Fonts.font({
      size: 13,
      color: Colors.primary.white,
    }),
  },
  txtStatus: {
    ...Fonts.font({
      size: 15,
      color: Colors.primary.white,
    }),
    marginTop: 6,
  },
  tabs: {
    marginTop: Metrics.baseMargin,
  },
  tabWrapper: {
    marginRight: Metrics.smallMargin,
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
    marginTop: Metrics.baseMargin,
    marginBottom: Metrics.xDoubleBaseMargin,
  },
  btnContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    // marginTop: Metrics.doubleBaseMargin,
  },

  btn: {
    width:
      (Metrics.screenWidth - 2 * Metrics.baseMargin - 2 * Metrics.smallMargin) /
      3,
  },
});
