import apis from '@apis';
import constants from '@constants';
import {request} from '@serviceAction';
import utility from '@utils';
import React, {useState} from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import {useDispatch} from 'react-redux';
import {EventBusSingleton} from 'light-event-bus';

import {
  AbsoluteHeader,
  BigBtn,
  Rating,
  SmallBtn,
  PopupModal,
} from '../../components';
import {
  FormHandler,
  ImageHandler,
  ImageHandlerUpdated,
  MaterialTextField,
} from '../../reuseableComponents';

import {pop} from '@nav';
import {Colors, Fonts, Images, Metrics} from '../../theme';
import {generalSaveAction} from '@serviceAction';
import {UNDER_CONTRACT} from '@actionTypes';
import {BUYERS} from '@actionTypes';

const dummyData = [
  {
    heading: 'Property Detail',
    tab: 'Details',
  },
  {
    heading: 'Listing Contract Details',
    tab: 'Contract Status',
  },
  {
    heading: 'Listing Contract Details',
    tab: 'Lenders Info',
  },
];

export default function ({route: {params: {enableInvite, property} = {}}}) {
  const dispatch = useDispatch();
  const [state, setState] = useState({
    activeTab: 0,
    isVisible: false,
  });
  const {activeTab, isVisible} = state;
  const {buyer_id} = property;
  const {
    id,
    title,
    address,
    asking_price,
    property_type,
    mls_detail,
    image_url,
  } = property.property;

  const onInitiateContract = () => {
    dispatch(
      request(
        apis.initiateContract,
        apis.serviceTypes.POST,
        {
          buyer_id,
          property_id: id,
          initiate_contract_status: constants.STATUS_INITIATE_CONTRACT,
        },
        null,
        true,
        false,
        contract => {
          dispatch(
            generalSaveAction(BUYERS.DELETE, {
              ...contract,
              isDeleteObj: true,
            }),
          );
          setTimeout(() => {
            dispatch(
              generalSaveAction(UNDER_CONTRACT.ADD, {
                ...contract,
                isAddAtZero: true,
              }),
            );
          }, 1000);

          utility.showFlashMessage(
            'Contract initiated successfully',
            'success',
          );
          // had to push index 0 because i was receivng array
          // push('UnderContract', {contract: contract[0]});
          pop(2);
        },
      ),
    );
  };

  const onMlsDetail = () => utility.openLink(mls_detail);

  const contractConfirmation = () =>
    EventBusSingleton.publish('popup', {
      val: 'initiateContract',
      onAccept: () => onInitiateContract(),
    });

  return (
    <ScrollView
      bounces={0}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}>
      <ImageHandlerUpdated style={styles.cover} source={{uri: image_url}} />
      <PopupModal
        onClose={() =>
          setState(prevState => ({...prevState, isVisible: false}))
        }
        isVisible={isVisible}
      />
      <AbsoluteHeader
        title={dummyData[activeTab].heading}
        rightIcon={Images.icMore}
        onRightClick={
          !enableInvite
            ? null
            : () => setState(prevState => ({...prevState, isVisible: true}))
        }
      />
      <View
        style={{
          marginHorizontal: Metrics.baseMargin,
        }}>
        <View style={styles.btnContainer}>
          {dummyData.map((ele, index) => (
            <SmallBtn
              key={ele.tab}
              useBold
              useRegularTxt
              txtSize={14}
              style={styles.btn}
              title={ele.tab}
              txtColor={
                activeTab === index
                  ? Colors.primary.white
                  : `${Colors.primary.slate}66`
              }
              disabled={!!index}
              bgColor={
                activeTab === index
                  ? Colors.primary.clearblue
                  : Colors.primary.white
              }
              onPress={() =>
                setState(prevState => ({...prevState, activeTab: index}))
              }
            />
          ))}
        </View>
        {activeTab === 0 ? (
          <>
            <Text style={styles.tileTxt2}>Title</Text>
            <Text style={styles.tileDesc2}>{title}</Text>
            <Text style={styles.tileTxt2}>Address</Text>
            <Text style={styles.tileDesc2}>{address}</Text>

            <View style={{flexDirection: 'row'}}>
              <View style={{flex: 0.5}}>
                <Text style={styles.tileTxt2}>Price</Text>
                <Text style={styles.tileDesc2}>{`$${asking_price}`}</Text>
              </View>

              <View style={{flex: 0.5}}>
                <Text style={styles.tileTxt2}>
                  {enableInvite ? 'Offer Status' : 'Type'}
                </Text>
                <Text style={styles.tileDesc2}>
                  {enableInvite ? 'Accepted' : 'SF'}
                </Text>
              </View>
            </View>
            <Text style={styles.tileTxt2}>MLS Details</Text>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                marginTop: 8,
              }}>
              <ImageHandler source={Images.icLink} />
              <Text onPress={onMlsDetail} style={styles.linkTxt}>
                {mls_detail}
              </Text>
            </View>

            {enableInvite ? (
              <>
                <View style={{flexDirection: 'row'}}>
                  <View style={{flex: 0.5}}>
                    <Text style={styles.tileTxt2}>Type</Text>
                    <Text style={styles.tileDesc2}>{property_type}</Text>
                  </View>

                  <View style={{flex: 0.5}}>
                    <Text style={styles.tileTxt2}>Rating</Text>
                    <Rating
                      useBig
                      style={styles.tileDesc2}
                      rating={property.rating}
                    />
                  </View>
                </View>
                <Text style={styles.tileTxt2}>Comments</Text>
                <Text style={styles.tileDesc2}>
                  {property.review ? property.review : 'Not reviewed yet'}
                </Text>

                <BigBtn
                  onPress={contractConfirmation}
                  useMargin
                  useSmall
                  title="INITIATE CONTRACT"
                  bgColor={Colors.primary.greenapple}
                />
              </>
            ) : null}
          </>
        ) : activeTab === 1 ? (
          <>
            <FormHandler>
              <MaterialTextField
                label="Contract Offered"
                placeholder="12/08/2020"
                rightIcon={Images.icCalendarField}
              />
              <MaterialTextField
                label="Contract Countered"
                placeholder="12/08/2020"
                rightIcon={Images.icCalendarField}
              />
              <MaterialTextField
                label="Contract Accepted"
                placeholder="12/08/2020"
                rightIcon={Images.icCalendarField}
              />
              <MaterialTextField
                label="Contract Executed"
                placeholder="12/08/2020"
                rightIcon={Images.icCalendarField}
              />
              <MaterialTextField
                label="Offer Decline"
                placeholder="12/08/2020"
                rightIcon={Images.icCalendarField}
              />
              <MaterialTextField
                label="Inspection"
                placeholder="12/08/2020"
                rightIcon={Images.icCalendarField}
              />
              <MaterialTextField
                label="Appraisal"
                placeholder="12/08/2020"
                rightIcon={Images.icCalendarField}
              />
              <MaterialTextField
                label="Final walk-thru"
                placeholder="12/08/2020"
                rightIcon={Images.icCalendarField}
              />
              <MaterialTextField
                label="Settlement Date"
                placeholder="12/08/2020"
                rightIcon={Images.icCalendarField}
              />
              <MaterialTextField
                multiline
                label="ADD Comments"
                placeholder="12/08/2020"
              />
              <MaterialTextField
                style={{width: '45%'}}
                label="Contract Status"
                placeholder="Active"
                rightIcon={Images.icDropdown}
              />
            </FormHandler>
            <SmallBtn
              style={styles.actionBtn}
              title="Save"
              useBold
              alignCenter
            />
          </>
        ) : null}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  cover: {
    width: Metrics.screenWidth,
    height: Metrics.heightRatio(308),
  },
  content: {
    paddingBottom: Metrics.xDoubleBaseMargin,
  },
  btn: {
    width:
      (Metrics.screenWidth - 2 * Metrics.baseMargin - 2 * Metrics.smallMargin) /
      3,
  },
  btnContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Metrics.doubleBaseMargin,
  },
  actionBtn: {
    marginVertical: Metrics.xDoubleBaseMargin,
    width: (Metrics.screenWidth - Metrics.xDoubleBaseMargin) / 2,
  },
  tileTxt2: {
    ...Fonts.font({
      size: 12,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: Metrics.doubleBaseMargin,
  },
  tileDesc2: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginTop: 8,
  },
  linkTxt: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.Italic,
      color: Colors.primary.clearblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
});
