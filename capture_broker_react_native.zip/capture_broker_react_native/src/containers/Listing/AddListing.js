import React, {useEffect, useRef} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableWithoutFeedback,
} from 'react-native';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import moment from 'moment';
import ActionSheet from 'react-native-actionsheet';

import {ShadowHeader, SmallBtn} from '@components';
import {
  ButtonView,
  FormHandlerUpdated,
  MaterialTextField,
  ImageHandlerUpdated,
  BottomActionSheet,
} from '@reuseableComponents';
import {INPUT_TYPES} from '@reuseableComponents/FormHandler/Constants';
import defaultStyles from '@reuseableComponents/BottomActionSheet/DefaultStyles';

import {pop} from '@services/NavigationService';
import {Colors, AppStyles, Fonts, Images, Metrics} from '@theme';
import {selectSingleImage, selectCameraImage} from '@services/MultipickerUtils';
import {useDispatch, useSelector} from 'react-redux';
import {request, generalSaveAction} from '@serviceAction';
import apis from '@apis';
import {PROPERTIES} from '@actionTypes';
import {navigate} from '@nav';
import utility from '@utils';
import constants from '@constants';

export default function ({route}) {
  const property = route.params?.property;
  const cbOnPropertyUpdated = route.params?.cbOnPropertyUpdated;

  const formHandler = useRef();
  const actionSheet = useRef();
  const actionSheetPropertyType = useRef();
  const dateFieldRef = useRef();
  const customerFieldRef = useRef();
  const appointmentFieldRef = useRef();
  const propertyTypeFieldRef = useRef();
  const imageBottomSheetRef = React.useRef();

  const dispatch = useDispatch();
  const user = useSelector(({user}) => user.data);

  let focusByRefCollectorKeyRef = null;
  const [state, setState] = React.useState({
    pickedDate: new Date(),
    isShowDatePicker: false,
    isDatePicked: false,
    isImgPicked: false,
    img: {path: null},
    appointment: null,
    isFormSubmitted: false,
    selectedCustomer: user,
    propertyType: null,
  });

  const APPOINTMENT_OPTIONS = {
    0: 'Yes',
    1: 'No',
  };

  const PROPERTY_TYPES = constants.PROPERTY_TYPES;

  useEffect(() => {
    if (property) {
      setState(s => ({
        ...s,
        isDatePicked: true,
        pickedDate: new Date(property.sell_date),
        appointment: Object.keys(APPOINTMENT_OPTIONS).find(
          key => APPOINTMENT_OPTIONS[key] === property.cma_appointment,
        ),
        propertyType: Object.keys(PROPERTY_TYPES).find(
          key => PROPERTY_TYPES[key] === property.property_type,
        ),
        img: {path: property.image_url},
        selectedCustomer: property.customer,
      }));
    }
  }, []);

  const onCreateProperty = () => {
    setState(s => ({...s, isFormSubmitted: true}));
    const data = formHandler.current.onSubmitForm();
    // if date not picked show error
    if (!state.isDatePicked)
      dateFieldRef.current.setError(true, 'Sell by date is required');

    // if appointment status not selected show error
    if (state.appointment == null)
      appointmentFieldRef.current.setError(
        true,
        'Appointment status is required',
      );

    // if property type not selected show error
    if (state.propertyType == null)
      propertyTypeFieldRef.current.setError(true, 'Property type is required');

    // if customer not selected show error
    if (state.selectedCustomer == null)
      customerFieldRef.current.setError(true, 'Customer is required');

    if (
      data &&
      state.appointment !== null &&
      state.isDatePicked &&
      state.img.path !== null &&
      state.selectedCustomer !== null &&
      state.propertyType !== null
    ) {
      const payload = new FormData();
      Object.keys(data).map(key => payload.append(key, data[key]));

      property && payload.append('_method', 'put');

      payload.append('image_url', {
        uri: state.img.path,
        type: state.img.mime,
        name: 'img',
      });
      payload.append('cma_appointment', APPOINTMENT_OPTIONS[state.appointment]);
      payload.append('property_type', PROPERTY_TYPES[state.propertyType]);
      payload.append(
        'sell_date',
        moment(state.pickedDate).format('YYYY-MM-DD'),
      );

      payload.append('prototype_type', '');
      payload.append('property_status', '');
      payload.append('customer_id', state.selectedCustomer.id);
      dispatch(
        request(
          property
            ? `${apis.createProperty}/${property.slug}`
            : apis.createProperty,
          apis.serviceTypes.POST,
          payload,
          null,
          true,
          false,
          updatedProperty => {
            if (property) {
              dispatch(
                generalSaveAction(PROPERTIES.UPDATE, {
                  isAddAtZero: true,
                  ...updatedProperty,
                }),
              );
              cbOnPropertyUpdated(updatedProperty);
              utility.showFlashMessage(
                'Successfully updated property',
                'success',
              );
            } else {
              dispatch(
                generalSaveAction(PROPERTIES.ADD, {
                  isAddAtZero: true,
                  ...updatedProperty,
                }),
              );
              utility.showFlashMessage(
                'Successfully created property',
                'success',
              );
            }
            pop();
          },
        ),
      );
    }
  };

  // const onPickImg = () =>
  //   selectSingleImage().then(img =>
  //     setState(s => ({...s, img, isImgPicked: true})),
  //   );

  const cbOnSelectCustomer = selectedCustomer => {
    setState(s => ({...s, selectedCustomer}));
    customerFieldRef.current.setError(false, '');
  };

  const onNavigateToSearch = () => {
    navigate('Search', {cbOnSelectCustomer, isLeadSearch: true});
  };

  const cbOnImageSelection = () =>
    setTimeout(imageBottomSheetRef.current.showActionSheet, 300);

  cbImageOptionSelected = index => {
    index && onSelectImg(index);
  };

  const onSelectImg = index =>
    index == 1
      ? setTimeout(
          () =>
            selectCameraImage().then(res => {
              setState(s => ({...s, img: res, isImgPicked: true}));
            }),
          400,
        )
      : setTimeout(
          () =>
            selectSingleImage().then(res =>
              setState(s => ({...s, img: res, isImgPicked: true})),
            ),
          400,
        );

  return (
    <View style={styles.container}>
      <ShadowHeader onBack={pop} title="Seller Information" useShadows />
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}>
        <FormHandlerUpdated ref={formHandler}>
          {(refCollector, onSubmitEditing, focusByRefCollectorKey) => {
            focusByRefCollectorKeyRef = focusByRefCollectorKey;
            const {text, number, website} = FormHandlerUpdated.INPUTS(
              refCollector,
              onSubmitEditing,
            );
            return (
              <>
                <View style={{width: '100%'}}>
                  <MaterialTextField
                    ref={customerFieldRef}
                    error="Customer is required"
                    style={{width: '100%'}}
                    label="Select Customer"
                    placeholder="Customer name"
                    value={state.selectedCustomer?.name}
                    editable={false}
                    rightIcon={Images.icContactList}
                  />
                  <TouchableWithoutFeedback onPress={onNavigateToSearch}>
                    <View
                      style={{
                        position: 'absolute',
                        left: 0,
                        right: 0,
                        top: 0,
                        bottom: 0,
                      }}
                    />
                  </TouchableWithoutFeedback>
                </View>
                <MaterialTextField
                  {...text({identifier: 'title'})}
                  style={{width: '100%'}}
                  label="Community/Building"
                  placeholder="Enter title"
                  error="Community/Building is required"
                  onSubmitEditing={cbOnImageSelection}
                  value={property?.title}
                />
                <View>
                  <ButtonView
                    style={styles.imgWrapper}
                    onPress={cbOnImageSelection}>
                    <ImageHandlerUpdated
                      source={
                        state.img.path
                          ? {uri: state.img.path}
                          : Images.icPlaceHolderProperty
                      }
                      style={{
                        width: Metrics.widthRatio(80),
                        height: Metrics.widthRatio(80),
                        borderRadius: Metrics.smallMargin,
                      }}
                    />
                    <Text style={styles.imgTxt}>Add Property Image</Text>
                  </ButtonView>
                  {state.isFormSubmitted && !state.img.path && (
                    <Text style={styles.imgErr}>
                      Property image is required
                    </Text>
                  )}
                </View>

                <MaterialTextField
                  {...text({identifier: 'address'})}
                  style={{width: '100%'}}
                  label="Address"
                  placeholder="Enter address"
                  error="Address is required"
                  value={property?.address}
                />
                <MaterialTextField
                  {...text({identifier: 'city'})}
                  style={{width: '100%'}}
                  label="City"
                  placeholder="Enter city"
                  error="City is required"
                  value={property?.city}
                />
                <MaterialTextField
                  {...text({identifier: 'state'})}
                  style={{width: '100%'}}
                  label="State"
                  placeholder="Enter state"
                  error="State is required"
                  value={property?.state}
                />
                <MaterialTextField
                  {...text({identifier: 'zipcode'})}
                  style={{width: '100%'}}
                  label="Zip Code"
                  placeholder="Enter zip code"
                  error="Zip code is required"
                  value={property?.zipcode}
                />
                <MaterialTextField
                  {...website({identifier: 'mls_detail'})}
                  style={{width: '100%'}}
                  label="MLS Link URL"
                  placeholder="Enter url"
                  error="Url is required"
                  value={
                    property?.mls_detail ? property.mls_detail : 'https://'
                  }
                />
                <MaterialTextField
                  {...number({identifier: 'asking_price'})}
                  style={{width: '100%'}}
                  label="Asking Price"
                  placeholder="Enter price"
                  error="Price is required"
                  onSubmitEditing={() => focusByRefCollectorKeyRef('sell_date')}
                  value={property?.asking_price}
                  returnKeyType="done"
                  blurOnSubmit
                  isPriceInput
                />
                <MaterialTextField
                  ref={dateFieldRef}
                  identifier="sell_date"
                  style={{width: '100%'}}
                  label="Date"
                  type={INPUT_TYPES.TEXT}
                  placeholder={moment(state.pickedDate).format('YYYY-MM-DD')}
                  rightIcon={Images.icCalendarField}
                  editable={false}
                  onRightPress={() =>
                    setState(s => ({...s, isShowDatePicker: true}))
                  }
                  value={
                    state.isDatePicked
                      ? moment(state.pickedDate).format('YYYY-MM-DD').toString()
                      : undefined
                  }
                  error="Date is required"
                />
                <MaterialTextField
                  ref={appointmentFieldRef}
                  style={{width: '100%'}}
                  label="Request Listing/CMA appointment"
                  type={INPUT_TYPES.TEXT}
                  placeholder="Do you want an appointment"
                  rightIcon={Images.icDropdown}
                  editable={false}
                  onRightPress={() => actionSheet.current.show()}
                  value={
                    state.appointment !== 'null'
                      ? APPOINTMENT_OPTIONS[state.appointment]
                      : undefined
                  }
                  error="Appointment status is required"
                />

                <MaterialTextField
                  ref={propertyTypeFieldRef}
                  style={{width: '100%'}}
                  label="Property type"
                  type={INPUT_TYPES.TEXT}
                  placeholder="Select a property type"
                  rightIcon={Images.icDropdown}
                  editable={false}
                  onRightPress={() => actionSheetPropertyType.current.show()}
                  value={
                    state.propertyType !== 'null'
                      ? PROPERTY_TYPES[state.propertyType]
                      : undefined
                  }
                  error="Appointment status is required"
                />
              </>
            );
          }}
        </FormHandlerUpdated>
        <SmallBtn
          style={{width: '48%', marginTop: Metrics.xDoubleBaseMargin}}
          bgColor={Colors.primary.darkslateblue}
          useBold
          title="Cancel"
          onPress={pop}
        />
        <SmallBtn
          style={{width: '48%', marginTop: Metrics.xDoubleBaseMargin}}
          bgColor={Colors.primary.clearblue}
          useBold
          title={property ? 'Update' : 'Add'}
          onPress={onCreateProperty}
        />
      </ScrollView>

      <DateTimePickerModal
        date={state.pickedDate}
        isVisible={state.isShowDatePicker}
        minimumDate={new Date()}
        mode="date"
        onConfirm={date => {
          setState(s => ({
            ...s,
            isDatePicked: true,
            isShowDatePicker: false,
            pickedDate: date,
          }));
          dateFieldRef.current.setError(false, '');
        }}
        onCancel={() => setState(s => ({...s, isShowDatePicker: false}))}
      />

      <ActionSheet
        ref={actionSheet}
        options={['Yes', 'No', 'Cancel']}
        cancelButtonIndex={2}
        destructiveButtonIndex={2}
        onPress={index => {
          if (index !== 2) setState(s => ({...s, appointment: index}));
          appointmentFieldRef.current.setError(false, '');
        }}
        styles={defaultStyles(false)}
        tintColor={'#000'}
      />

      <ActionSheet
        ref={actionSheetPropertyType}
        options={constants.PROPERTY_TYPES_OPTIONS}
        cancelButtonIndex={constants.PROPERTY_TYPES_OPTIONS.length - 1}
        destructiveButtonIndex={constants.PROPERTY_TYPES_OPTIONS.length - 1}
        onPress={index => {
          if (index !== constants.PROPERTY_TYPES_OPTIONS.length - 1) {
            setState(s => ({...s, propertyType: index}));
            propertyTypeFieldRef.current.setError(false, '');
          }
        }}
        styles={defaultStyles(false)}
        tintColor={'#000'}
      />

      <BottomActionSheet
        ref={imageBottomSheetRef}
        options={['Cancel', 'Camera', 'Photo Album']}
        cbOnPressActionSheet={cbImageOptionSelected}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
    paddingBottom: Metrics.xDoubleBaseMargin,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  imgTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginLeft: Metrics.baseMargin,
  },
  imgWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: Metrics.doubleBaseMargin,
  },
  imgErr: {
    paddingTop: Metrics.widthRatio(4),
    ...AppStyles.gbRe(10, Colors.primary.vermillion),
  },
});
