import React, {useState} from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import {EventBusSingleton} from 'light-event-bus';

import {AbsoluteHeader, SmallBtn, BigBtn} from '@components';
import {Colors, Images, Metrics, Fonts} from '@theme';
import {ImageHandler, ImageHandlerUpdated} from '@reuseableComponents';
import {navigate} from '@nav';
import utility from '@utils';
import {useDispatch} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';

export default function ({route}) {
  const dispatch = useDispatch();

  const isShowContractDetailsBtn = route.params?.isShowContractDetailsBtn;

  const [state, setState] = useState({
    property: route.params?.property,
  });

  const onDeactivate = () =>
    EventBusSingleton.publish('popup', {
      val: +state.property.status == 1 ? 'deactivate' : 'activate',
      onAccept: () => {
        state.property &&
          dispatch(
            request(
              apis.deactivateProperty,
              apis.serviceTypes.GET,
              {
                slug: state.property.slug,
                status: +state.property.status == 1 ? 0 : 1,
              },
              null,
              true,
              false,
              property => {
                setState(s => ({
                  ...s,
                  property: {...s.property, status: property.status},
                }));
              },
            ),
          );
      },
    });

  const {
    title,
    address,
    asking_price,
    mls_detail,
    customer,
    sell_date,
    image_url,
    cma_appointment,
    property_type,
    zipcode,
    city,
    state: property_state,
  } = state.property;

  const cbOnPropertyUpdated = property => setState(s => ({...s, property}));

  const onMls = () => utility.openLink(mls_detail);

  const onContractDetails = () =>
    navigate('ContactDetails', {property: state.property});

  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <ImageHandlerUpdated style={styles.cover} source={{uri: image_url}} />
      <AbsoluteHeader
        title="Listing"
        onPressCall={utility.call(customer.mobile_no)}
        onPressEmail={utility.email(customer.email)}
      />
      <View style={styles.personalDetails}>
        <ImageHandlerUpdated
          source={{uri: customer.image_url}}
          style={{
            width: Metrics.widthRatio(64),
            height: Metrics.widthRatio(64),
            borderRadius: Metrics.widthRatio(6),
          }}
        />
        <View style={styles.personalDetailsWrapper}>
          <Text style={styles.nameTxt}>{customer.name}</Text>
          <View style={{flexDirection: 'row', marginTop: Metrics.smallMargin}}>
            <View style={{flex: 0.5}}>
              <Text style={styles.tileHeader}>Asking Price</Text>
              <Text style={styles.tileDesc}>
                {utility.formateCurrency(asking_price)}
              </Text>
            </View>
            <View style={{flex: 0.5}}>
              <Text style={styles.tileHeader}>Sell by Date</Text>
              <Text style={styles.tileDesc}>{sell_date}</Text>
            </View>
          </View>
        </View>
      </View>

      <View style={styles.content}>
        {isShowContractDetailsBtn &&
          state.property.initiate_contract == '1' && (
            <BigBtn
              useSmall
              onPress={onContractDetails}
              bgColor={Colors.primary.greenapple}
              title="Contract Details"
              style={styles.btnContractDetails}
            />
          )}

        <View style={{flexDirection: 'row'}}>
          <View style={{flex: 0.5}}>
            <Text style={styles.tileTxt2}>Community/Building</Text>
            <Text style={styles.tileDesc2}>{title}</Text>
          </View>
          <View style={{flex: 0.5}}>
            <Text style={styles.tileTxt2}>Status</Text>
            <View
              style={{
                marginTop: 8,
                flexDirection: 'row',
                alignItems: 'center',
                width: Metrics.screenWidth / 3,
                justifyContent: 'space-between',
              }}>
              <Text style={[styles.tileDesc2, {marginTop: 0}]}>
                {+state.property.status == 1 ? 'Active' : 'De-activated'}
              </Text>
            </View>
          </View>
        </View>

        <View style={{flexDirection: 'row'}}>
          <View style={{flex: 0.5}}>
            <Text style={styles.tileTxt2}>Address</Text>
            <Text style={styles.tileDesc2}>{address}</Text>
          </View>

          <View style={{flex: 0.5}}>
            <Text style={styles.tileTxt2}>City</Text>
            <Text style={styles.tileDesc2}>{city}</Text>
          </View>
        </View>

        <View style={{flexDirection: 'row'}}>
          <View style={{flex: 0.5}}>
            <Text style={styles.tileTxt2}>State</Text>
            <Text style={styles.tileDesc2}>{property_state}</Text>
          </View>

          <View style={{flex: 0.5}}>
            <Text style={styles.tileTxt2}>Zipcode</Text>
            <Text style={styles.tileDesc2}>{zipcode}</Text>
          </View>
        </View>

        <View style={{flexDirection: 'row'}}>
          <View style={{flex: 0.5}}>
            <Text style={styles.tileTxt2}>Listing/CMA appointment</Text>
            <Text style={styles.tileDesc2}>
              {cma_appointment ? cma_appointment : 'No'}
            </Text>
          </View>

          <View style={{flex: 0.5}}>
            <Text style={styles.tileTxt2}>Property Type</Text>
            <Text style={styles.tileDesc2}>{property_type}</Text>
          </View>
        </View>

        <Text style={styles.tileTxt2}>MLS Details</Text>

        <View
          style={{flexDirection: 'row', alignItems: 'center', marginTop: 8}}>
          <ImageHandler source={Images.icLink} />
          <Text style={styles.linkTxt} onPress={onMls}>
            {mls_detail}
          </Text>
        </View>

        <View style={styles.btnContainer}>
          <SmallBtn
            useBold
            style={styles.btn}
            title={+state.property.status == 1 ? 'Deactivate' : 'Activate'}
            bgColor={Colors.primary.coral}
            onPress={onDeactivate}
          />
          <SmallBtn
            useBold
            title="Edit"
            style={styles.btn}
            bgColor={Colors.primary.darkslateblue}
            onPress={() =>
              customer
                ? navigate('AddListing', {
                    property: state.property,
                    cbOnPropertyUpdated,
                  })
                : undefined
            }
          />
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  cover: {
    width: Metrics.screenWidth,
    height: Metrics.heightRatio(308),
  },
  personalDetails: {
    paddingVertical: Metrics.smallMargin,
    paddingHorizontal: Metrics.baseMargin,
    backgroundColor: Colors.primary.clearblue,
    flexDirection: 'row',
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
    marginBottom: Metrics.xDoubleBaseMargin,
  },
  nameTxt: {
    ...Fonts.font({
      size: 20,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.white,
    }),
  },
  personalDetailsWrapper: {
    marginLeft: Metrics.baseMargin,
    justifyContent: 'space-between',
    flex: 1,
  },
  tileHeader: {
    ...Fonts.font({
      size: 12,
      color: Colors.primary.white,
    }),
    opacity: 0.5,
  },
  tileDesc: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.white,
    }),
    marginTop: Metrics.heightRatio(9),
  },
  tileTxt2: {
    ...Fonts.font({
      size: 12,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: Metrics.doubleBaseMargin,
  },
  tileDesc2: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginTop: 8,
  },
  linkTxt: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.Italic,
      color: Colors.primary.clearblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
  btn: {
    width:
      (Metrics.screenWidth - 2 * Metrics.baseMargin - Metrics.smallMargin) / 2,
  },
  btnContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Metrics.xDoubleBaseMargin,
  },
  btnContractDetails: {marginTop: Metrics.baseMargin},
});
