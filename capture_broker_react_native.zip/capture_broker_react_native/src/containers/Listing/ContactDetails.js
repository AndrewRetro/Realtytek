import React, {useState} from 'react';
import {View, StyleSheet, ScrollView} from 'react-native';

import {AbsoluteHeader, SmallBtn, ContractStatus, LoanInfo} from '@components';
import {ImageHandlerUpdated} from '../../reuseableComponents';

import {Colors, Metrics} from '../../theme';

const dummyData = [
  {
    heading: 'Contract Details',
    tab: 'Contract Info',
  },
  {
    heading: 'Listing Contract Details',
    tab: 'Contract Status',
  },
];

export default function ({route}) {
  const property = route.params.property;
  const [activeTab, setActiveTab] = useState(0);

  const [state, setState] = useState({
    contractStatus: null,
    loanInfo: null,
  });

  const cbSetContractStatus = contractStatus =>
    setState(s => ({...s, contractStatus}));

  const cbSetLoanInfo = loanInfo => {
    setState(s => ({...s, loanInfo}));
  };

  const {image_url} = property;

  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <ImageHandlerUpdated
        resizeMode="cover"
        style={styles.cover}
        source={{uri: image_url}}
      />
      <AbsoluteHeader title="Contract Details" showRight={false} />
      <View
        style={{
          marginHorizontal: Metrics.baseMargin,
        }}>
        <View style={styles.btnContainer}>
          <SmallBtn
            useBold
            useRegularTxt
            txtSize={14}
            style={styles.btn}
            title={dummyData[0].tab}
            txtColor={
              activeTab === 0
                ? Colors.primary.white
                : Colors.primary.darkslateblue
            }
            bgColor={
              activeTab === 0 ? Colors.primary.clearblue : Colors.primary.white
            }
            onPress={() => setActiveTab(0)}
          />
          <SmallBtn
            useBold
            txtSize={14}
            useRegularTxt
            title={dummyData[1].tab}
            style={styles.btn}
            txtColor={
              activeTab === 1
                ? Colors.primary.white
                : Colors.primary.darkslateblue
            }
            bgColor={
              activeTab === 1 ? Colors.primary.clearblue : Colors.primary.white
            }
            onPress={() => setActiveTab(1)}
          />
        </View>
        {activeTab === 0 ? (
          <ContractStatus
            property={property}
            cbSetContractStatus={cbSetContractStatus}
            contractStatus={state.contractStatus}
          />
        ) : (
          <LoanInfo
            property={property}
            loanInfo={state.loanInfo}
            cbSetLoanInfo={cbSetLoanInfo}
          />
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  cover: {
    width: Metrics.screenWidth,
    height: Metrics.heightRatio(308),
  },
  btn: {
    width:
      (Metrics.screenWidth - 2 * Metrics.baseMargin - Metrics.smallMargin) / 2,
  },
  btnContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Metrics.doubleBaseMargin,
  },
  actionBtn: {
    marginVertical: Metrics.xDoubleBaseMargin,
    width: (Metrics.screenWidth - Metrics.xDoubleBaseMargin) / 2,
  },
});
