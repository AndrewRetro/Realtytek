import React from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';

import {ShadowHeader, SmallBtn} from '../../components';
import {
  MaterialTextField,
  FormHandler,
  ImageHandler,
} from '../../reuseableComponents';
import {INPUT_TYPES} from '../../reuseableComponents/FormHandler/Constants';
import {navigate, pop} from '../../services/NavigationService';
import {Colors, Fonts, Images, Metrics} from '../../theme';

export default function () {
  return (
    <View style={styles.container}>
      <ShadowHeader onBack={pop} useShadows title="Edit Listing" />
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}>
        <FormHandler>
          <MaterialTextField
            label="Customer"
            type={INPUT_TYPES.TEXT}
            placeholder="Ryan Marshall"
            // rightIcon={Images.icContactList}
          />
          <MaterialTextField
            label="Add Title"
            type={INPUT_TYPES.TEXT}
            placeholder="Title"
          />
          <View style={styles.imgWrapper}>
            <ImageHandler source={Images.icPlaceHolderProperty} />
            <Text style={styles.imgTxt}>Add Property Image</Text>
          </View>
          <MaterialTextField
            label="Address"
            type={INPUT_TYPES.TEXT}
            placeholder="Debra Pierce"
          />
          <MaterialTextField
            label="City"
            type={INPUT_TYPES.TEXT}
            placeholder="Debra Pierce"
          />
          <MaterialTextField
            label="State"
            type={INPUT_TYPES.TEXT}
            placeholder="Debra Pierce"
          />
          <MaterialTextField
            label="Zip Code"
            type={INPUT_TYPES.TEXT}
            placeholder="Debra Pierce"
          />
          <MaterialTextField
            editable={false}
            label="Property Type"
            type={INPUT_TYPES.TEXT}
            placeholder="Debra Pierce"
            rightIcon={Images.icDropdown}
          />
          <MaterialTextField
            label="MLS Details"
            type={INPUT_TYPES.TEXT}
            placeholder="Debra Pierce"
          />
          <MaterialTextField
            label="Asking Price"
            type={INPUT_TYPES.NUMBER}
            placeholder="$2,500"
          />
          <MaterialTextField
            label="What’s your “Sell by” date?"
            type={INPUT_TYPES.TEXT}
            placeholder="12/08/2020"
            rightIcon={Images.icCalendarField}
          />
          <MaterialTextField
            label="Request Listing/CMA appointment"
            type={INPUT_TYPES.TEXT}
            editable={false}
            placeholder="Yes"
            rightIcon={Images.icDropdown}
          />
        </FormHandler>
        <View style={styles.btnContainer}>
          <SmallBtn
            useBold
            style={styles.btn}
            title="Cancel"
            bgColor={Colors.primary.darkslateblue}
          />
          <SmallBtn
            useBold
            title="Save"
            style={styles.btn}
            bgColor={Colors.primary.clearblue}
            onPress={() => navigate('EditListings')}
          />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
    paddingBottom: Metrics.xDoubleBaseMargin,
  },
  imgTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginLeft: Metrics.baseMargin,
  },
  imgWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: Metrics.doubleBaseMargin,
  },
  imgContainer: {
    marginVertical: Metrics.baseMargin,
  },
  btn: {
    width:
      (Metrics.screenWidth - 2 * Metrics.baseMargin - Metrics.smallMargin) / 2,
  },
  btnContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Metrics.xDoubleBaseMargin,
  },
});
