import React, {useRef, useState} from 'react';
import {View, StyleSheet, SafeAreaView} from 'react-native';
import _ from 'lodash';

import {BigBtn, ListingCards, ShadowHeader, UserLead} from '@components';
import {ButtonView, FlatListHandler} from '@reuseableComponents';
import SearchBar from './SearchBar';

import {navigate, pop} from '@nav';
import {Colors, Metrics} from '@theme';

import {useDispatch, useSelector} from 'react-redux';
import {request, generalSaveAction} from '@serviceAction';
import {SEARCH} from '@actionTypes';
import apis from '@apis';

export default function ({route}) {
  const cbOnSelectCustomer = route?.params?.cbOnSelectCustomer;
  const cbSelectedProperties = route?.params?.cbSelectedProperties;
  const selectedPropertyIds = route.params?.selectedPropertyIds;
  const isSearchRecommended = route.params?.isSearchRecommended;
  const isShowSelection = route.params?.isShowSelection; //only passing this true from recommend home
  const dispatch = useDispatch();
  const searchBarRef = useRef();
  const search = useSelector(({search}) => search);

  let isLeadSearch = route.params?.isLeadSearch;
  let isPropertySearch = route.params?.isPropertySearch;

  const [state, setState] = useState({selectedProperties: {}});

  React.useEffect(() => {
    if (selectedPropertyIds) {
      const properties = {};
      selectedPropertyIds.map(id => (properties[id] = true));
      setState(s => ({...s, selectedProperties: properties}));
    }
    fetch();
    return () => dispatch(generalSaveAction(SEARCH.SUCCESS, []));
  }, []);

  const fetch = (isConcat = false, page = 1) => {
    let apiToHit;

    if (isLeadSearch) apiToHit = apis.addLead;

    if (isPropertySearch) apiToHit = apis.createProperty;

    dispatch(
      request(
        apiToHit,
        apis.serviceTypes.GET,
        {
          lead_type: 'search',
          property_type: isSearchRecommended ? 'search_recommended' : 'search',
          value: searchBarRef.current?.getValue(),
          page,
          limit: 10,
        },
        SEARCH,
        false,
        isConcat,
        null,
        null,
        SEARCH,
      ),
    );
  };

  const cbOnSearch = txt => fetch();
  const onCustomerSelected = customer => ev => {
    cbOnSelectCustomer(customer);
    pop();
  };

  const cbOnPropertySelected = item =>
    setState(s => {
      const selectedProperties = {...s.selectedProperties};
      if (selectedProperties[item.id]) {
        selectedProperties[item.id] = false;
      } else {
        selectedProperties[item.id] = true;
      }
      return {...s, selectedProperties};
    });

  const renderItem = ({item}) =>
    isLeadSearch ? (
      cbOnSelectCustomer ? (
        <View>
          <UserLead data={item} />
          <ButtonView
            onPress={onCustomerSelected(item)}
            style={{position: 'absolute', left: 0, right: 0, bottom: 0, top: 0}}
          />
        </View>
      ) : (
        <UserLead data={item} />
      )
    ) : (
      <ListingCards
        onPress={() => navigate('PropertyDetails', {property: item})}
        item={item}
        style={{marginTop: 0}}
        isSelected={state.selectedProperties[item.id]}
        isShowSelection={isShowSelection}
        cbOnPropertySelected={cbOnPropertySelected}
      />
    );

  const itemSeparator = () => <View style={styles.separator} />;

  const onDone = () => {
    cbSelectedProperties(
      Object.keys(state.selectedProperties).filter(
        key => state.selectedProperties[key],
      ),
    );
    pop();
  };

  return (
    <View style={styles.container}>
      <ShadowHeader onBack={pop} useShadows title="Search" />
      <SearchBar
        ref={searchBarRef}
        cbOnSearch={_.debounce(cbOnSearch, 300)}
        isLeadSearch={isLeadSearch}
      />
      <FlatListHandler
        fetchRequest={fetch}
        isFetching={search.isFetching}
        data={search.data}
        meta={search.meta}
        renderItem={renderItem}
        ItemSeparatorComponent={itemSeparator}
        keyExtractor={item => item.id}
      />
      <SafeAreaView
        style={{
          marginHorizontal: Metrics.doubleBaseMargin - Metrics.widthRatio(8),
          marginTop: Metrics.baseMargin,
          marginBottom: Metrics.baseMargin,
        }}>
        {cbSelectedProperties && <BigBtn title="Done" onPress={onDone} />}
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.primary.palegrey,
  },
  separator: {
    height: Metrics.baseMargin,
  },
});
