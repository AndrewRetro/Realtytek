import React, {forwardRef, useImperativeHandle, useState} from 'react';
import {View, Image, TextInput} from 'react-native';

import {Metrics, Images, Colors, AppStyles} from '@theme';

const Search = forwardRef(({cbOnSearch, isLeadSearch}, ref) => {
  const [txt, setTxt] = useState('');

  useImperativeHandle(ref, () => ({
    getValue: () => txt,
  }));

  const onChangeText = txt => {
    cbOnSearch(txt);
    setTxt(txt);
  };

  return (
    <View
      style={[
        styles.containerSearch,
        {
          marginBottom: Metrics.baseMargin,
        },
      ]}>
      <Image source={Images.icSearch} />
      <TextInput
        placeholder="Search here..."
        style={styles.txtSearch}
        onChangeText={onChangeText}
        value={txt}
        placeholderTextColor={Colors.primary.lightgreyblue}
      />
    </View>
  );
});

export default Search;

const styles = {
  containerSearch: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.primary.white,
    padding: Metrics.smallMargin * 1.5,
    margin: Metrics.baseMargin,
    marginTop: Metrics.smallMargin,
    ...AppStyles.heavyShadow,
    borderRadius: Metrics.widthRatio(4),
  },
  txtSearch: {
    flex: 1,
    ...AppStyles.gbRe(14, Colors.primary.darkslateblue),
    marginLeft: Metrics.baseMargin,
  },
};
