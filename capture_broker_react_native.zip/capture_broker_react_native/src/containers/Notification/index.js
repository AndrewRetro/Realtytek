import apis from '@apis';
import {request} from '@serviceAction';
import React from 'react';
import {View, StyleSheet, Text} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import moment from 'moment';

import {ShadowHeader} from '../../components';
import {
  FlatListHandler,
  ImageHandlerUpdated,
  ButtonView,
} from '../../reuseableComponents';

import {pop} from '../../services/NavigationService';
import {AppStyles, Colors, Metrics} from '../../theme';
import {handleBadgeCount, onNotificationOpened} from '../../reuseableFunctions';

import {NOTIFICATIONS} from '@actionTypes';

export default function () {
  const dispatch = useDispatch();
  const notifications = useSelector(({notifications}) => notifications);

  React.useEffect(() => {
    fetchNotifications();
    handleBadgeCount({badge_count: 0});
  }, []);

  const fetchNotifications = (isConcat = false, page = 1) => {
    dispatch(
      request(
        apis.notification,
        apis.serviceTypes.GET,
        {page, limit: 10},
        NOTIFICATIONS,
        false,
        isConcat,
        null,
        null,
        NOTIFICATIONS,
      ),
    );
  };

  const onNotification =
    ({identifier, reference_slug}) =>
    () => {
      onNotificationOpened({
        additionalData: {
          custom_data: {
            identifier,
            data: {
              slug: reference_slug,
            },
          },
        },
      });
    };

  const NotificationItem = ({data}) => {
    const {title, description, actor_image_url: uri, created_at} = data;
    return (
      <ButtonView style={styles.containerItem} onPress={onNotification(data)}>
        <ImageHandlerUpdated
          source={{
            uri,
          }}
          style={styles.imgProfile}
        />
        <View style={styles.containerDesc}>
          <Text style={styles.txtTitle}>{title}</Text>
          <Text style={styles.txtDesc}>{description}</Text>
        </View>
        <Text style={styles.txtCreatedAt}>
          {moment.utc(created_at).fromNow()}
        </Text>
      </ButtonView>
    );
  };

  const renderNotification = ({item}) => <NotificationItem data={item} />;

  return (
    <View style={styles.container}>
      <ShadowHeader onBack={pop} useShadows title="Notification" />
      <View style={styles.separator} />
      <FlatListHandler
        fetchRequest={fetchNotifications}
        data={notifications.data}
        isFetching={notifications.isFetching}
        meta={notifications.meta}
        renderItem={renderNotification}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.primary.palegrey,
  },
  separator: {height: Metrics.baseMargin},
  txtSearch: {
    flex: 1,
    ...AppStyles.gbRe(14, Colors.primary.darkslateblue),
    marginLeft: Metrics.baseMargin,
  },
  containerItem: {
    flexDirection: 'row',
    padding: Metrics.baseMargin,
    marginBottom: Metrics.baseMargin,
    marginHorizontal: Metrics.baseMargin,
    backgroundColor: Colors.primary.white,
    borderRadius: Metrics.smallMargin,
    ...AppStyles.lightShadow,
  },
  imgProfile: {
    width: Metrics.widthRatio(50),
    height: Metrics.widthRatio(50),
    borderRadius: Metrics.widthRatio(25),
  },
  containerDesc: {flex: 1, marginHorizontal: Metrics.baseMargin},
  txtTitle: AppStyles.gbRe(15, Colors.primary.darkslateblue),
  txtDesc: {
    ...AppStyles.gbRe(13, Colors.primary.blueyGrey),
    marginTop: Metrics.widthRatio(4),
  },
  txtCreatedAt: AppStyles.gbRe(12, Colors.primary.darkslateblue),
});
