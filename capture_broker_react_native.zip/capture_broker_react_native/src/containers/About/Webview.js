import React, {useState} from 'react';
import {View, StyleSheet, ActivityIndicator} from 'react-native';
import WebView from 'react-native-webview';

import {ShadowHeader} from '../../components';
import {pop} from '../../services/NavigationService';
import {Metrics, Fonts, Colors, AppStyles} from '../../theme';

export default function ({route}) {
  const {title, link} = route.params;

  const [isLoading, setIsLoading] = useState(true);

  return (
    <View style={styles.container}>
      <ShadowHeader useShadows title={title} onBack={pop} />

      <WebView
        source={{uri: link}}
        style={{flex: 1}}
        onLoadEnd={() => setIsLoading(false)}
      />

      {isLoading && (
        <View style={styles.wrapperLoader}>
          <ActivityIndicator size="large" color={Colors.primary.theme} />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
    marginTop: Metrics.baseMargin,
  },
  txtStyle: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkslateblue,
    }),
    lineHeight: Metrics.heightRatio(18),
  },
  wrapperLoader: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    top: 0,
    ...AppStyles.centerAligned,
  },
});
