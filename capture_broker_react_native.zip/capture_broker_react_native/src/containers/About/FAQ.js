import React, {useCallback, useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  LayoutAnimation,
  Platform,
  UIManager,
} from 'react-native';

import {ShadowHeader} from '../../components';
import {ButtonView, ImageHandler} from '../../reuseableComponents';
import {pop} from '../../services/NavigationService';
import {Colors, Fonts, Images, Metrics} from '../../theme';

const dummyData = [
  {
    question: 'What is Capture?',
    answer:
      'Capture App is a mobile app technology designed specifically for real estate agents. It combines prospecting, home search, tours feedback and transaction tracking into a simple accessible format for agents, their customer and clients. Capture understands the industry and works from the prospective of the real estate agent to win more business, advance the process and close more sales.',
  },
  {
    question:
      'What’s the difference between a Lead, Customer and Client in this app?',
    answer:
      'Capture App is a mobile app technology designed specifically for real estate agents. It combines prospecting, home search, tours feedback and transaction tracking into a simple accessible format for agents, their customer and clients. Capture understands the industry and works from the prospective of the real estate agent to win more business, advance the process and close more sales.',
  },
];

if (
  Platform.OS === 'android' &&
  UIManager.setLayoutAnimationEnabledExperimental
) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

export default function () {
  const [expandedIndex, setExpandedIndex] = useState(-1);

  const handleExpand = useCallback(
    index => () => {
      LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
      setExpandedIndex(prevState => (prevState === index ? -1 : index));
    },
    [],
  );

  return (
    <View style={styles.container}>
      <ShadowHeader useShadows title="FAQs" onBack={pop} />
      <ScrollView contentContainerStyle={styles.content}>
        {dummyData.map((ele, index) => {
          const isActive = index === expandedIndex;
          return (
            <View
              key={ele.question}
              style={isActive ? styles.cardActive : styles.cardInactive}>
              <View style={styles.card}>
                <Text style={styles.headerTxt}>{ele.question}</Text>
                <ButtonView style={styles.expBtn} onPress={handleExpand(index)}>
                  <ImageHandler
                    source={isActive ? Images.icDropup : Images.icDropdown}
                  />
                </ButtonView>
              </View>
              {isActive ? <Text style={styles.desc}>{ele.answer}</Text> : null}
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginTop: Metrics.baseMargin,
  },
  card: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  cardInactive: {
    borderBottomWidth: 1,
    margin: Metrics.baseMargin,
    paddingBottom: Metrics.smallMargin,
    borderColor: Colors.primary.lightgreyblue,
  },
  cardActive: {
    padding: Metrics.baseMargin,
    backgroundColor: Colors.primary.white,
  },
  expBtn: {
    padding: Metrics.smallMargin,
    paddingBottom: 0,
  },
  headerTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkslateblue,
    }),
    lineHeight: Metrics.heightRatio(17),
    maxWidth: '85%',
  },
  desc: {
    marginTop: Metrics.smallMargin,
    ...Fonts.font({
      size: 12,
      color: Colors.primary.darkslateblue,
    }),
    lineHeight: Metrics.heightRatio(18),
  },
});
