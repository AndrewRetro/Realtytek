import React from 'react';
import {View, Text, StyleSheet} from 'react-native';

import {ShadowHeader} from '../../components';
import {ButtonView, ImageHandler} from '../../reuseableComponents';
import {navigate, pop} from '../../services/NavigationService';
import {Colors, Fonts, Metrics, Images} from '../../theme';

import constants from '@constants';
import apis from '@apis';

export default function () {
  return (
    <View style={styles.container}>
      <ShadowHeader useShadows title="About" onBack={pop} />
      <ButtonView
        onPress={() =>
          navigate('Webview', {
            title: 'Terms and Conditions',
            link: apis.terms,
          })
        }
        style={styles.cardContainer}>
        <ImageHandler source={Images.icTerms} />
        <Text style={styles.txt}>Terms & Conditions</Text>
      </ButtonView>

      <ButtonView
        onPress={() =>
          navigate('Webview', {
            title: 'Privacy Policy',
            link: apis.privacy,
          })
        }
        style={styles.cardContainer}>
        <ImageHandler source={Images.icPrivacy} />
        <Text style={styles.txt}>Privacy Policy</Text>
      </ButtonView>

      <ButtonView
        onPress={() =>
          navigate('Webview', {
            title: 'FAQs',
            link: apis.faqs,
          })
        }
        style={styles.cardContainer}>
        <ImageHandler source={Images.icFAQ} />
        <Text style={styles.txt}>FAQs</Text>
      </ButtonView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  cardWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cardContainer: {
    marginBottom: 0,
    borderRadius: 5,
    alignItems: 'center',
    flexDirection: 'row',
    margin: Metrics.baseMargin,
    padding: Metrics.smallMargin,
    paddingLeft: Metrics.baseMargin,
    minHeight: Metrics.heightRatio(50),
    backgroundColor: Colors.primary.white,
  },
  txt: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.darkslateblue,
    }),
    marginLeft: Metrics.baseMargin,
  },
});
