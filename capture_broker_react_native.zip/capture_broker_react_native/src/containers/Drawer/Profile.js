import utility from '@utils';
import React from 'react';
import {View, Text, StyleSheet, ScrollView, Image} from 'react-native';
import {useSelector} from 'react-redux';

import {ShadowHeader} from '../../components';
import {ButtonView, ImageHandlerUpdated} from '@reuseableComponents';
import ic_doc from '@reuseableComponents/MediaPicker/icon/ic_doc.png';
import {navigate, pop} from '../../services/NavigationService';
import {Colors, Fonts, Metrics, AppStyles, Images} from '../../theme';

export default function () {
  const user = useSelector(({user}) => user.data);
  const {
    name,
    mobile_no,
    email,
    image_url,
    licence_state,
    license_number,
    agent_agrement,
  } = user;

  const onLink = () => utility.openLink(agent_agrement);

  const Raw = ({title, desc, img, isLink}) => (
    <View style={styles.containerRaw}>
      <Image source={img} style={styles.icImg} />
      <View>
        <Text style={styles.tileTxt}>{title}</Text>
        <Text onPress={onLink} style={isLink ? styles.link : styles.tileDesc}>
          {desc}
        </Text>
      </View>
    </View>
  );

  const AgreementDoc = () => (
    <View style={styles.containerRaw}>
      <Image source={Images.icOther} style={styles.icImg} />
      <View>
        <Text style={styles.tileTxt}>Agreement Document</Text>
        <View style={{flexDirection: 'row'}}>
          <ButtonView
            onPress={onLink}
            style={{
              backgroundColor: 'white',
              borderRadius: Metrics.smallMargin,
              marginTop: Metrics.smallMargin,
            }}>
            <Image
              source={ic_doc}
              style={{
                tintColor: Colors.primary.clearblue,
                width: Metrics.widthRatio(80),
                height: Metrics.widthRatio(80),
              }}
            />
          </ButtonView>
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <ShadowHeader
        useShadows
        onBack={pop}
        title="Agent Profile"
        onRightPress={() => navigate('EditProfile')}
        rightTxt="Edit Profile"
      />
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}>
        <View style={styles.containerImg}>
          <ImageHandlerUpdated
            source={{uri: image_url}}
            style={styles.imgProfile}
            isProfileImage
          />
          <Text style={styles.nameTxt}>{name}</Text>
        </View>
        <Raw title="Phone Number" desc={mobile_no} img={Images.icPhone} />
        <Raw title="Email Address" desc={email} img={Images.icEmail} />
        <Raw
          title="License Number"
          desc={license_number}
          img={Images.icOther}
        />
        <Raw title="Licensed In" desc={licence_state} img={Images.icOther} />
        {!!agent_agrement && <AgreementDoc />}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
  },
  containerImg: {
    width: '100%',
    ...AppStyles.centerAligned,
    marginVertical: Metrics.doubleBaseMargin,
  },
  imgProfile: {
    width: Metrics.widthRatio(130),
    height: Metrics.widthRatio(130),
    borderRadius: Metrics.smallMargin,
  },
  containerRaw: {
    flexDirection: 'row',
    marginBottom: Metrics.doubleBaseMargin,
    width: Metrics.screenWidth - Metrics.doubleBaseMargin,
  },
  nameTxt: {
    marginTop: Metrics.baseMargin,
    ...Fonts.font({
      size: 24,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkTwo,
    }),
  },
  tileTxt: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
  },
  tileDesc: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.darkTwo,
    }),
    marginTop: 8,
    width: Metrics.widthRatio(300),
  },
  link: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.clearblue,
    }),
    marginTop: 8,
    width: Metrics.widthRatio(300),
  },
  icImg: {
    marginRight: Metrics.baseMargin,
    width: Metrics.widthRatio(30),
    width: Metrics.widthRatio(30),
    resizeMode: 'contain',
    tintColor: 'black',
  },
});
