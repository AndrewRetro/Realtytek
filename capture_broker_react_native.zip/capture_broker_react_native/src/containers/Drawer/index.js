import React, {useContext, useMemo} from 'react';
import {StyleSheet, FlatList, View, Text} from 'react-native';
import {EventBusSingleton} from 'light-event-bus';

import {LoginContext} from '../../contexts';
import {Colors, Images, Metrics, Fonts} from '../../theme';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {navigate, toggleDrawer} from '../../services/NavigationService';
import {
  ImageHandler,
  ButtonView,
  ImageHandlerUpdated,
} from '../../reuseableComponents';
import {useSelector} from 'react-redux';
import moment from 'moment';

const drawerRoutes = [
  {
    title: 'Home',
    route: 'TabStack',
    icon: Images.icHome,
  },
  {
    title: 'E-Business Card',
    route: 'BusinessCard',
    icon: Images.icBusiness,
  },
  {
    title: 'Subscriptions',
    route: 'Subscription',
    icon: Images.icSubscription,
  },
  {
    title: 'Lenders &  State Agency \nDisclosure ',
    route: 'Disclosure',
    icon: Images.icLender,
  },
  {
    title: 'Settings',
    route: 'Settings',
    icon: Images.icSettings,
  },
  {
    title: 'About',
    route: 'AboutStack',
    icon: Images.icAccount,
  },
  {
    title: 'Logout',
    route: '',
    icon: Images.icLogout,
  },
];

function handleNavigateProfile() {
  navigate('Profile');
}

const index = props => {
  const {} = props;
  const {setLogin} = useContext(LoginContext);
  const {top} = useSafeAreaInsets();

  const user = useSelector(({user}) => user.data);

  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
          backgroundColor: Colors.primary.darkslateblue,
        },
        header: {
          height: 127 + top,
          alignItems: 'center',
          flexDirection: 'row',
          paddingTop: Metrics.baseMargin,
          backgroundColor: Colors.primary.clearblue,
        },
        closeBtn: {
          padding: Metrics.baseMargin,
        },
        profileCard: {
          flexDirection: 'row',
          alignItems: 'center',
        },
        profileImageWrapper: {
          width: 44,
          height: 44,
          borderRadius: 22,
        },
        profileTxt: {
          ...Fonts.font({
            size: 18,
            type: Fonts.Type.SemiBold,
            color: Colors.primary.white,
          }),
        },
        profileSubtitle: {
          ...Fonts.font({
            size: 14,
            color: Colors.primary.white,
          }),
          marginTop: 8,
          opacity: 0.6,
        },
        profileTxtWrapper: {
          marginLeft: Metrics.smallMargin,
        },
        routeTxt: {
          ...Fonts.font({
            size: 16,
            color: Colors.primary.white,
          }),
          // marginLeft: Metrics.baseMargin,
          lineHeight: 24,
        },
        routeWrapper: {
          flexDirection: 'row',
          alignItems: 'center',
          paddingTop: Metrics.baseMargin,
          paddingBottom: Metrics.heightRatio(15),
        },
        routeIcon: {
          width: 40,
        },
      }),
    [top],
  );

  const onPress = (item, setLogin) => ev => {
    toggleDrawer();
    if (item.title === 'Logout') {
      EventBusSingleton.publish('popup', {
        val: 'logout',
        onAccept: () => {},
      });
    } else {
      navigate(item.route);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <ButtonView style={styles.closeBtn} onPress={toggleDrawer}>
          <ImageHandler source={Images.icClose} />
        </ButtonView>
        <ButtonView onPress={handleNavigateProfile} style={styles.profileCard}>
          <ImageHandlerUpdated
            style={{
              ...styles.profileImageWrapper,
              backgroundColor: 'white',
            }}
            source={
              user.image_url ? {uri: user.image_url} : Images.person_black
            }
          />
          <View style={styles.profileTxtWrapper}>
            <Text style={styles.profileTxt}>{user.name}</Text>
            <Text style={styles.profileSubtitle}>{`Member since ${moment(
              user.created_at,
            ).format('MMM yyy')}`}</Text>
          </View>
        </ButtonView>
      </View>
      <FlatList
        data={drawerRoutes}
        renderItem={({item}) => (
          <ButtonView
            onPress={onPress(item, setLogin)}
            style={styles.routeWrapper}>
            <View style={styles.routeIcon}>
              <ImageHandler source={item.icon} />
            </View>
            <Text style={styles.routeTxt}>{item.title}</Text>
          </ButtonView>
        )}
        contentContainerStyle={{
          paddingVertical: 15,
          paddingHorizontal: Metrics.baseMargin,
        }}
        keyExtractor={item => item.route}
      />
    </View>
  );
};

export default index;
