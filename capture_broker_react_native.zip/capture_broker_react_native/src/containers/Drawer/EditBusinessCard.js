import React, {useEffect} from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';

import {ShadowHeader, SmallBtn} from '../../components';
import {
  ImageHandlerUpdated,
  MaterialTextField,
  ButtonView,
  FormHandlerUpdated,
  BottomActionSheet,
} from '../../reuseableComponents';

import {pop} from '@services/NavigationService';
import {Colors, Fonts, Images, Metrics} from '../../theme';
import {selectSingleImage, selectCameraImage} from '@services/MultipickerUtils';

import {request} from '@serviceAction';
import apis from '@apis';
import {USER} from '@actionTypes';
import _ from 'lodash';

export default function () {
  const dispatch = useDispatch();

  const formHandlerRef = React.useRef();
  const imageBottomSheetRef = React.useRef();

  const user = useSelector(({user}) => user.data);
  const {
    tag_line,
    logo_url,
    about_us,
    website,
    company_name,
    company_description,
    address,
    city,
    state: userState,
    zipcode,
  } = user;

  const [state, setState] = React.useState({
    logo: {path: logo_url},
    isLogoSelected: false,
    imgSelectionKey: null,
    web: website && website.length ? website : '',
    iscompanyEntered:
      company_name &&
      company_name.length &&
      company_description &&
      company_description.length
        ? true
        : false,
  });

  const ImageInput = ({title, placeholder, url, onPress}) => (
    <ButtonView style={styles.imgWrapper} onPress={onPress}>
      <ImageHandlerUpdated
        style={styles.imgProfile}
        source={url ? {uri: url} : placeholder}
        isProfileImage
      />
      <Text style={styles.imgTxt}>{title}</Text>
    </ButtonView>
  );

  const onSubmitForm = () => {
    const data = formHandlerRef.current.onSubmitForm();

    if (data) {
      const payload = new FormData();
      Object.keys(data).map(key => payload.append(key, data[key]));
      payload.append('_method', 'put');
      payload.append('mobile_no', user.mobile_no);

      if (state.isImgSelected) {
        payload.append('image_url', {
          uri: state.img.path,
          type: state.img.mime,
          name: 'img',
        });
      }

      if (state.isLogoSelected) {
        payload.append('logo_url', {
          uri: state.logo.path,
          type: state.logo.mime,
          name: 'img',
        });
      }

      dispatch(
        request(
          `${apis.signup}/${user.slug}`,
          apis.serviceTypes.POST,
          payload,
          USER,
          true,
          false,
          () => {
            pop();
          },
        ),
      );
    }
  };

  const onSelectImg = index =>
    index == 1
      ? setTimeout(
          () =>
            selectCameraImage().then(img => {
              setState(s => ({
                ...s,
                [s.imgSelectionKey]: img,
                ...(s.imgSelectionKey == 'img' && {isImgSelected: true}),
                ...(s.imgSelectionKey == 'logo' && {isLogoSelected: true}),
              }));
            }),
          400,
        )
      : setTimeout(
          () =>
            selectSingleImage().then(img =>
              setState(s => ({
                ...s,
                [s.imgSelectionKey]: img,
                ...(s.imgSelectionKey == 'img' && {isImgSelected: true}),
                ...(s.imgSelectionKey == 'logo' && {isLogoSelected: true}),
              })),
            ),
          400,
        );

  const cbOnImageSelection = imgSelectionKey => () => {
    setState(s => ({...s, imgSelectionKey}));
    imageBottomSheetRef.current.showActionSheet();
  };

  const cbImageOptionSelected = index => {
    index && onSelectImg(index);
  };

  const onChangeCompanyName = companyName => {
    setState(s => {
      const {iscompanyEntered} = s;

      // if company name entered then lock both company name and description
      // to required
      if (companyName.length && !iscompanyEntered) {
        return {...s, iscompanyEntered: true};
      }

      // if both company name and description are not entered set lock to false
      // to make input optional
      if (
        !companyName.length &&
        !formHandlerRef.current
          .getRefByIdentifier('company_description')
          .getValue().length &&
        iscompanyEntered
      ) {
        return {...s, iscompanyEntered: false};
      }

      return s;
    });
  };

  const onChangeCompanyDescription = companyDescirption => {
    setState(s => {
      const {iscompanyEntered} = s;

      // if company description entered then lock both company name and description
      // to required
      if (companyDescirption.length && !iscompanyEntered) {
        return {...s, iscompanyEntered: true};
      }

      // if both company name and description are not entered set lock to false
      // to make input optional
      if (
        !companyDescirption.length &&
        !formHandlerRef.current.getRefByIdentifier('company_name').getValue()
          .length &&
        iscompanyEntered
      ) {
        return {...s, iscompanyEntered: false};
      }

      return s;
    });
  };

  const onChangeWebsite = web => {
    setState(s => ({...s, web}));
  };

  const isWebType = state.web.length ? true : false;

  return (
    <View style={styles.container}>
      <ShadowHeader useShadows title="Edit Agent Profile" onBack={pop} />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}>
        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
          <ImageInput
            title="Add logo"
            placeholder={Images.imageHolder}
            stateKey="logo"
            url={state.logo.path}
            onPress={cbOnImageSelection('logo')}
          />
        </View>

        <FormHandlerUpdated ref={formHandlerRef}>
          {(refCollector, onSubmitEditing) => {
            const {
              text,
              website: webType,
              optional,
            } = FormHandlerUpdated.INPUTS(refCollector, onSubmitEditing);
            return (
              <>
                <MaterialTextField
                  {...optional({
                    label: 'Tag Line',
                    placeholder: 'Enter tags',
                    identifier: 'tag_line',
                    error: 'Tag line is required',
                    blurOnSubmit: false,
                  })}
                  value={tag_line}
                />
                <MaterialTextField
                  {...optional({
                    label: 'About',
                    placeholder: 'Write about yourself',
                    identifier: 'about_us',
                    error: 'About is required',
                    blurOnSubmit: false,
                  })}
                  multiline
                  value={about_us}
                />
                <MaterialTextField
                  {...(state.iscompanyEntered
                    ? text({
                        label: 'Company Name',
                        placeholder: 'Enter company name',
                        identifier: 'company_name',
                        error: 'Company name is required',
                        blurOnSubmit: false,
                      })
                    : optional({
                        label: 'Company Name',
                        placeholder: 'Enter company name',
                        identifier: 'company_name',
                        error: 'Company name is required',
                        blurOnSubmit: false,
                      }))}
                  value={company_name}
                  onChangeText={_.debounce(onChangeCompanyName, 500)}
                />
                <MaterialTextField
                  {...(state.iscompanyEntered
                    ? text({
                        label: 'Company Description',
                        placeholder: 'Enter description',
                        identifier: 'company_description',
                        error: 'Company description is required',
                        blurOnSubmit: false,
                      })
                    : optional({
                        label: 'Company Description',
                        placeholder: 'Enter description',
                        identifier: 'company_description',
                        error: 'Company description is required',
                        blurOnSubmit: false,
                      }))}
                  value={company_description}
                  onChangeText={_.debounce(onChangeCompanyDescription, 500)}
                />
                <MaterialTextField
                  {...optional({
                    label: 'Address',
                    placeholder: 'Enter address',
                    identifier: 'address',
                    error: 'Address is required',
                    blurOnSubmit: false,
                  })}
                  value={address}
                />

                <MaterialTextField
                  {...optional({
                    label: 'City',
                    placeholder: 'Enter city',
                    identifier: 'city',
                    error: 'City is required',
                    blurOnSubmit: false,
                  })}
                  value={city}
                />
                <MaterialTextField
                  {...optional({
                    label: 'State',
                    placeholder: 'Enter state',
                    identifier: 'state',
                    error: 'State is required',
                    blurOnSubmit: false,
                  })}
                  value={userState}
                />
                <MaterialTextField
                  {...optional({
                    label: 'Zipcode',
                    placeholder: 'Enter zipcode',
                    identifier: 'zipcode',
                    error: 'Zipcode is required',
                    blurOnSubmit: false,
                  })}
                  value={zipcode}
                />

                <MaterialTextField
                  {...(isWebType
                    ? webType({
                        label: 'Website',
                        placeholder: 'Enter website link',
                        identifier: 'website',
                        error: 'Website is required',
                        blurOnSubmit: true,
                      })
                    : optional({
                        label: 'Website',
                        placeholder: 'https://abc.com',
                        identifier: 'website',
                        error: 'Website is required',
                        blurOnSubmit: true,
                      }))}
                  value={website && website.length ? website : 'https://'}
                  onChangeText={_.debounce(onChangeWebsite, 500)}
                />
              </>
            );
          }}
        </FormHandlerUpdated>
        <SmallBtn
          style={styles.btn}
          title="SAVE"
          alignCenter
          useBold
          onPress={onSubmitForm}
        />
      </ScrollView>
      <BottomActionSheet
        ref={imageBottomSheetRef}
        options={['Cancel', 'Camera', 'Photo Album']}
        cbOnPressActionSheet={cbImageOptionSelected}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginTop: Metrics.baseMargin,
    marginHorizontal: Metrics.baseMargin,
    paddingBottom: Metrics.xDoubleBaseMargin,
  },
  imgProfile: {
    width: Metrics.widthRatio(80),
    height: Metrics.widthRatio(80),
    borderRadius: Metrics.smallMargin,
    tintColor: 'white',
  },
  imgTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginLeft: Metrics.baseMargin,
  },
  imgWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  imgContainer: {
    marginVertical: Metrics.baseMargin,
  },
  btn: {
    marginVertical: Metrics.xDoubleBaseMargin,
  },
});
