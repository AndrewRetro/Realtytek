import {request} from '@serviceAction';
import React, {useContext} from 'react';
import {View, Text, StyleSheet} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import {EventBusSingleton} from 'light-event-bus';

import {ShadowHeader} from '../../components';
import {ImageHandler, ButtonView} from '../../reuseableComponents';
import {navigate, pop} from '../../services/NavigationService';
import {Colors, Fonts, Images, Metrics} from '../../theme';

import {LoginContext} from '@contexts';
import apis from '@apis';

import {generalSaveAction} from '@serviceAction';
import {LOGOUT} from '@actionTypes';
import utility from '@utils';

export default function () {
  const dispatch = useDispatch();

  const slug = useSelector(({user}) => user.data.slug);

  const onNotificationSettings = () => navigate('NotificationSettings');

  const {setLogin} = useContext(LoginContext);

  const onDeleteAccount = () => {
    dispatch(
      request(
        `${apis.signup}/${slug}`,
        apis.serviceTypes.DELETE,
        {},
        null,
        true,
        false,
        () => {
          setLogin(false);
          dispatch(generalSaveAction(LOGOUT, {}));
        },
      ),
    );
  };

  const onShowDeletePopup = () => {
    EventBusSingleton.publish('popup', {
      val: 'delete_account',
      onAccept: onDeleteAccount,
    });
  };

  return (
    <View style={styles.container}>
      <ShadowHeader onBack={pop} title="Settings" useShadows />

      <ButtonView
        onPress={() => navigate('ChangePassword')}
        style={styles.cardContainer}>
        <View style={styles.cardWrapper}>
          <ImageHandler source={Images.icPassword} />
          <Text style={styles.txt}>Change Password</Text>
        </View>
      </ButtonView>

      <ButtonView style={styles.cardContainer} onPress={onNotificationSettings}>
        <View style={styles.cardWrapper}>
          <ImageHandler source={Images.icNotificationTwo} />
          <Text style={styles.txt}>Notification Settings</Text>
        </View>
      </ButtonView>

      {utility.isPlatformIOS() && (
        <ButtonView style={styles.cardContainer} onPress={onShowDeletePopup}>
          <View style={styles.cardWrapper}>
            <ImageHandler
              source={Images.icDeleteOutline}
              style={{
                width: Metrics.widthRatio(22),
                height: Metrics.widthRatio(22),
                resizeMode: 'contain',
                marginLeft: -Metrics.widthRatio(4),
                tintColor: Colors.primary.slate,
              }}
            />
            <Text style={styles.txt}>Delete Account</Text>
          </View>
        </ButtonView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  cardWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cardContainer: {
    marginBottom: 0,
    borderRadius: 5,
    alignItems: 'center',
    flexDirection: 'row',
    margin: Metrics.baseMargin,
    padding: Metrics.smallMargin,
    paddingLeft: Metrics.baseMargin,
    justifyContent: 'space-between',
    minHeight: Metrics.heightRatio(50),
    backgroundColor: Colors.primary.white,
  },
  txt: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.darkslateblue,
    }),
    marginLeft: Metrics.baseMargin,
  },
});
