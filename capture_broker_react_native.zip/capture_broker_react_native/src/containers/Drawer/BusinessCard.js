import React, {useRef} from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import ViewShot from 'react-native-view-shot';
import {SafeAreaView} from 'react-native-safe-area-context';

import {pop, push} from '../../services/NavigationService';
import {
  ButtonView,
  ImageHandler,
  ImageHandlerUpdated,
} from '../../reuseableComponents';
import {ShadowHeader, SmallBtn} from '../../components';
import {Colors, Images, Metrics, Fonts, AppStyles} from '../../theme';
import {useDispatch, useSelector} from 'react-redux';
import utility from '@utils';
import {request} from '@serviceAction';
import apis from '@apis';

export default function () {
  const user = useSelector(({user}) => user.data);
  const {
    name,
    mobile_no,
    email,
    image_url,
    about_us,
    website,
    logo_url,
    licence_state,
    license_number,
    company_description,
    company_name,
    address,
    city,
    state,
    zipcode,
    tag_line,
  } = user;

  const dispatch = useDispatch();
  const viewShotRef = useRef();

  const onWebsite = () => utility.openLink(website);

  const onShare = () => {
    viewShotRef.current.capture().then(uri => onUploadShot(uri));
  };

  const onUploadShot = uri => {
    const payload = new FormData();
    payload.append('share_profile_image', {
      uri,
      type: 'image/jpeg',
      name: 'shot',
    });

    dispatch(
      request(
        apis.shareProfile,
        apis.serviceTypes.POST,
        payload,
        null,
        true,
        false,
        res =>
          setTimeout(
            () =>
              utility.rnShare(
                res.share_profile_image,
                `Nice to meet you ! Here's my e-business card!\nphone ${mobile_no}`,
              ),
            500,
          ),
      ),
    );
  };

  const handleEditBusinessCard = () => push('EditBusinessCard');

  return (
    <View style={styles.container}>
      <ShadowHeader
        onBack={pop}
        title="E Business Card"
        rightTxt="Edit"
        onRightPress={handleEditBusinessCard}
      />

      <ScrollView
        alwaysBounceVertical={false}
        showsVerticalScrollIndicator={false}>
        <SafeAreaView edges={['bottom']}>
          <ViewShot
            style={styles.viewShot}
            ref={viewShotRef}
            options={{format: 'jpg', quality: 1}}>
            <View style={styles.headerCover} />
            <View style={styles.logoWrapper}>
              <View style={styles.wrapperImg}>
                <ImageHandlerUpdated
                  source={{uri: image_url}}
                  style={styles.img}
                />
              </View>
              <View style={styles.wrapperLogo}>
                <ImageHandlerUpdated
                  source={{uri: logo_url}}
                  style={styles.logo}
                />
              </View>
            </View>
            <View style={styles.content}>
              <Text style={styles.nameTxt}>{name}</Text>
              <View style={styles.tileWrapper}>
                <ImageHandler source={Images.icPhoneTile} />
                <Text style={styles.tileTxt}>{mobile_no}</Text>
              </View>
              <View style={styles.tileWrapper}>
                <ImageHandler source={Images.icEmailTile} />
                <Text style={styles.tileTxt}>{email}</Text>
              </View>

              <View style={styles.tileContainer}>
                <View style={styles.seperator}>
                  <Text style={styles.tileTxtHeading}>License Number</Text>
                  <Text style={styles.tileDesc}>{license_number}</Text>
                </View>
                <View style={styles.seperator}>
                  <Text style={styles.tileTxtHeading}>Licensed In</Text>
                  <Text style={styles.tileDesc}>{licence_state}</Text>
                </View>
              </View>

              {!!company_name && (
                <View>
                  <Text style={styles.heading}>{company_name}</Text>
                  <Text style={styles.desc}>{company_description}</Text>
                </View>
              )}

              <View style={{flexDirection: 'row'}}>
                <View style={{flex: 1}}>
                  {!!address && (
                    <View>
                      <Text style={styles.headingTwo}>Address</Text>
                      <Text style={styles.desTwo}>{address}</Text>
                    </View>
                  )}
                  {!!state && (
                    <View>
                      <Text style={styles.headingTwo}>State</Text>
                      <Text style={styles.desTwo}>{state}</Text>
                    </View>
                  )}
                  {!!tag_line && (
                    <View>
                      <Text style={styles.headingTwo}>Tag Line</Text>
                      <Text style={styles.desTwo}>{tag_line}</Text>
                    </View>
                  )}
                </View>
                <View style={{flex: 1}}>
                  {!!city && (
                    <View>
                      <Text style={styles.headingTwo}>City</Text>
                      <Text style={styles.desTwo}>{city}</Text>
                    </View>
                  )}

                  {!!zipcode && (
                    <View>
                      <Text style={styles.headingTwo}>Zipcode</Text>
                      <Text style={styles.desTwo}>{zipcode}</Text>
                    </View>
                  )}
                </View>
              </View>

              {!!website && (
                <View>
                  <Text style={styles.headingTwo}>Website</Text>
                  <ButtonView onPress={onWebsite}>
                    <Text
                      style={[
                        styles.desTwo,
                        {color: Colors.primary.clearblue},
                      ]}>
                      {website}
                    </Text>
                  </ButtonView>
                </View>
              )}
              {!!about_us && (
                <View>
                  <Text style={styles.headingTwo}>About Us</Text>
                  <Text style={styles.desTwo}>{about_us}</Text>
                </View>
              )}
            </View>
          </ViewShot>
        </SafeAreaView>
        <View style={styles.btnContainer}>
          <SmallBtn
            useBold
            title="Share"
            bgColor={Colors.primary.clearblue}
            onPress={onShare}
          />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerCover: {
    height: 100,
    width: '100%',
    backgroundColor: Colors.primary.clearblue,
  },
  viewShot: {paddingBottom: Metrics.baseMargin},
  logoWrapper: {
    marginTop: -50,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: Metrics.baseMargin,
    marginBottom: Metrics.baseMargin,
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
  },
  nameTxt: {
    ...Fonts.font({
      size: 18,
      color: Colors.primary.darkTwo,
    }),
  },
  tileWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: Metrics.baseMargin,
  },
  tileTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginLeft: Metrics.smallMargin,
  },
  tileTxtHeading: {
    ...Fonts.font({
      size: 13,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
  },
  tileDesc: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginTop: Metrics.smallMargin,
  },
  tileContainer: {
    flexDirection: 'row',
    marginTop: Metrics.xDoubleBaseMargin,
  },
  seperator: {
    flex: 0.5,
  },
  heading: {
    ...Fonts.font({
      size: 18,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkTwo,
    }),
    marginTop: Metrics.heightRatio(50),
  },
  desc: {
    ...Fonts.font({
      type: Fonts.Type.Italic,
      size: 13,
      color: Colors.primary.darkTwo,
    }),
    marginTop: Metrics.smallMargin,
  },
  headingTwo: {
    ...Fonts.font({
      size: 13,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: Metrics.heightRatio(30),
  },
  desTwo: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginTop: Metrics.smallMargin,
  },
  btnContainer: {
    marginTop: Metrics.baseMargin,
    alignItems: 'center',
    marginBottom: Metrics.baseMargin,
  },
  wrapperImg: {
    ...AppStyles.roundImg(100),
    ...AppStyles.heavyShadow,
    backgroundColor: Colors.primary.white,
  },
  img: AppStyles.roundImg(100),
  wrapperLogo: {
    width: Metrics.widthRatio(100),
    height: Metrics.widthRatio(100),
    borderRadius: Metrics.widthRatio(16),
    ...AppStyles.heavyShadow,
    backgroundColor: Colors.primary.white,
  },
  logo: {
    width: Metrics.widthRatio(100),
    height: Metrics.widthRatio(100),
    borderRadius: Metrics.widthRatio(16),
  },
});
