import React from 'react';
import {View, Text, StyleSheet, Image, ScrollView} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import {EventBusSingleton} from 'light-event-bus';

import {ShadowHeader, SmallBtn} from '../../components';
import {
  ImageHandlerUpdated,
  MaterialTextField,
  ButtonView,
  FormHandler,
  BottomActionSheet,
} from '../../reuseableComponents';
import {INPUT_TYPES} from '../../reuseableComponents/FormHandler/Constants';
import ic_doc from '../../reuseableComponents/MediaPicker/icon/ic_doc.png';

import {pop} from '@services/NavigationService';
import {Colors, Fonts, Images, Metrics} from '../../theme';
import {selectSingleImage, selectCameraImage} from '@services/MultipickerUtils';

import {request} from '@serviceAction';
import apis from '@apis';
import {USER} from '@actionTypes';

export default function () {
  const dispatch = useDispatch();

  const formHandler = React.useRef();
  const imageBottomSheetRef = React.useRef();

  const user = useSelector(({user}) => user.data);
  const {
    name,
    image_url,
    logo_url,
    licence_state,
    license_number,
    agent_agrement,
  } = user;

  const [state, setState] = React.useState({
    img: {path: image_url},
    logo: {path: logo_url},
    isImgSelected: false,
    isLogoSelected: false,
    imgSelectionKey: null,
  });

  const ImageInput = ({title, placeholder, url, onPress}) => (
    <ButtonView style={styles.imgWrapper} onPress={onPress}>
      <ImageHandlerUpdated
        style={styles.imgProfile}
        source={url ? {uri: url} : placeholder}
        isProfileImage
      />
      <Text style={styles.imgTxt}>{title}</Text>
    </ButtonView>
  );

  const onDoc = () => EventBusSingleton.publish('showAddAgreementModal');

  const Agreement = () => (
    <View style={{flexDirection: 'row', marginTop: Metrics.baseMargin}}>
      <View>
        <Text style={{marginBottom: Metrics.widthRatio(8), flex: 1}}>
          Agreement Document
        </Text>
        <View style={{flexDirection: 'row'}}>
          <ButtonView onPress={onDoc} style={styles.btnDoc}>
            <Image source={ic_doc} style={styles.icDoc} />
          </ButtonView>
        </View>
      </View>
    </View>
  );

  const onSubmitForm = () => {
    const data = formHandler.current.onSubmitForm();

    if (data) {
      const payload = new FormData();
      Object.keys(data).map(key => payload.append(key, data[key]));
      payload.append('_method', 'put');
      payload.append('mobile_no', user.mobile_no);

      if (state.isImgSelected) {
        payload.append('image_url', {
          uri: state.img.path,
          type: state.img.mime,
          name: 'img',
        });
      }

      if (state.isLogoSelected) {
        payload.append('logo_url', {
          uri: state.logo.path,
          type: state.logo.mime,
          name: 'img',
        });
      }

      dispatch(
        request(
          `${apis.signup}/${user.slug}`,
          apis.serviceTypes.POST,
          payload,
          USER,
          true,
          false,
          () => {
            pop();
          },
        ),
      );
    }
  };

  const onSelectImg = index =>
    index == 1
      ? setTimeout(
          () =>
            selectCameraImage().then(img => {
              setState(s => ({
                ...s,
                [s.imgSelectionKey]: img,
                ...(s.imgSelectionKey == 'img' && {isImgSelected: true}),
                ...(s.imgSelectionKey == 'logo' && {isLogoSelected: true}),
              }));
            }),
          400,
        )
      : setTimeout(
          () =>
            selectSingleImage().then(img =>
              setState(s => ({
                ...s,
                [s.imgSelectionKey]: img,
                ...(s.imgSelectionKey == 'img' && {isImgSelected: true}),
                ...(s.imgSelectionKey == 'logo' && {isLogoSelected: true}),
              })),
            ),
          400,
        );

  const cbOnImageSelection = imgSelectionKey => () => {
    setState(s => ({...s, imgSelectionKey}));
    imageBottomSheetRef.current.showActionSheet();
  };

  const cbImageOptionSelected = index => {
    index && onSelectImg(index);
  };

  return (
    <View style={styles.container}>
      <ShadowHeader useShadows title="Edit Agent Profile" onBack={pop} />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}>
        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
          <ImageInput
            title="Add image"
            placeholder={Images.icAddImage}
            url={state.img.path}
            onPress={cbOnImageSelection('img')}
          />
        </View>
        <FormHandler ref={formHandler}>
          <MaterialTextField
            label="Full Name"
            placeholder="Enter full name"
            type={INPUT_TYPES.TEXT}
            identifier="name"
            value={name}
            error="Name is required"
            blurOnSubmit={false}
          />
          <MaterialTextField
            label="License No."
            placeholder="Enter license number"
            type={INPUT_TYPES.TEXT}
            identifier="license_number"
            value={license_number}
            error="License no is required"
            blurOnSubmit={false}
          />
        </FormHandler>
        <Agreement />
      </ScrollView>

      <SmallBtn
        style={styles.btn}
        title="SAVE"
        alignCenter
        useBold
        onPress={onSubmitForm}
      />
      <BottomActionSheet
        ref={imageBottomSheetRef}
        options={['Cancel', 'Camera', 'Photo Album']}
        cbOnPressActionSheet={cbImageOptionSelected}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginTop: Metrics.baseMargin,
    marginHorizontal: Metrics.baseMargin,
    paddingBottom: Metrics.xDoubleBaseMargin,
  },
  imgProfile: {
    width: Metrics.widthRatio(80),
    height: Metrics.widthRatio(80),
    borderRadius: Metrics.smallMargin,
    tintColor: 'white',
  },
  imgTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginLeft: Metrics.baseMargin,
  },
  imgWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  imgContainer: {
    marginVertical: Metrics.baseMargin,
  },
  btn: {
    // marginVertical: Metrics.xDoubleBaseMargin,
  },
  icDoc: {
    tintColor: Colors.primary.clearblue,
    width: Metrics.widthRatio(80),
    height: Metrics.widthRatio(80),
    resizeMode: 'contain',
  },
  btnDoc: {
    backgroundColor: 'white',
    borderRadius: Metrics.smallMargin,
    padding: Metrics.smallMargin,
  },
});
