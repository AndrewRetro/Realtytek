import React from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import {EventBusSingleton} from 'light-event-bus';

import {BigBtn, ShadowHeader} from '../../components';
import {pop} from '../../services/NavigationService';
import {Colors, Fonts, Metrics} from '../../theme';

const SubscriptionDetails = ({route}) => {
  const selectedSubId = route.params.selectedSubId;

  React.useEffect(() => {}, []);

  const onCancelSub = () => {
    EventBusSingleton.publish('popup', {val: 'sub', onAccept: () => {}});
  };
  const onUpgradeSub = () => {
    EventBusSingleton.publish('popup', {val: 'upgradeSub', onAccept: () => {}});
  };

  return (
    <View style={styles.container}>
      <ShadowHeader onBack={pop} title="Subscriptions" useShadows />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}>
        <View style={styles.subContainer}>
          <Text style={styles.subTxt}>Introductory Annual Subscription</Text>
          <Text style={styles.amount}>$99</Text>
        </View>

        <View style={styles.tileWrapper}>
          <Text style={styles.tileName}>Subscription Date</Text>
          <Text style={styles.tileValue}>12 May, 2020</Text>
        </View>

        <View style={styles.tileWrapper}>
          <Text style={styles.tileName}>Subscription Expriry</Text>
          <Text style={styles.tileValue}>12 Aug, 2020</Text>
        </View>

        <BigBtn
          useMargin
          bgColor={Colors.primary.slate}
          title="CANCEL SUBSCRIPTION"
          onPress={onCancelSub}
        />
        <BigBtn
          margin={Metrics.smallMargin}
          useMargin
          title="UPGRADE SUBSCRIPTION"
          onPress={onUpgradeSub}
        />

        <Text style={styles.desc}>
          • Payment will be processed through your iTunes account at
          confirmation of purchase. {'\n\n'}• Your subscription will
          automatically renew per the billing cycle of your subscription (i.e.,
          yearly) 24-hours before the end of the current period, and your credit
          card will be charged through your iTunes account. {'\n\n'}• The
          renewal charge for your Subscription shall be the same as the original
          purchase price, unless you are otherwise notified in advance. {'\n\n'}
          • To avoid the billing of fees for the next Subscription period, you
          must switch off your yearly Subscription at least 24-hours before the
          end of the current period. {'\n\n'}• You can turn off auto-renew at
          any time from your iTunes account settings. {'\n\n'}• You will not
          receive a refund for the fees you already paid for you current
          Subscription period and you will continue to have access to your
          Subscription until the end of your current Subscription period.{' '}
          {'\n\n'}• Capture provides no refunds and you may cancel auto-renewal
          at any time.
        </Text>
      </ScrollView>
    </View>
  );
};

export default SubscriptionDetails;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginHorizontal: Metrics.baseMargin,
  },
  subContainer: {
    width: 150,
    height: 150,
    borderWidth: 1,
    borderRadius: 10,
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'space-around',
    borderColor: Colors.primary.clearblue,
    marginVertical: Metrics.doubleBaseMargin,
  },
  amount: {
    ...Fonts.font({
      size: 36,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.clearblue,
    }),
  },
  subTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.clearblue,
    }),
    textAlign: 'center',
  },
  tileWrapper: {
    borderRadius: 5,
    flexDirection: 'row',
    alignItems: 'center',
    padding: Metrics.baseMargin,
    marginTop: Metrics.baseMargin,
    justifyContent: 'space-between',
    backgroundColor: Colors.primary.white,
  },
  tileName: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.Regular,
      color: Colors.primary.greyishpurple,
    }),
  },
  tileValue: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.Regular,
      color: Colors.primary.blackTwo,
    }),
  },
  desc: {
    marginVertical: Metrics.xDoubleBaseMargin,
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkindigo,
    }),
  },
});
