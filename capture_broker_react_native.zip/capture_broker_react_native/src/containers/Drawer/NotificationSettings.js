import {USER} from '@actionTypes';
import apis from '@apis';
import _ from 'lodash';
import {generalSaveAction} from '@serviceAction';
import {request} from '@serviceAction';
import React, {useCallback, useState} from 'react';
import {StyleSheet, Switch, Text, View} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import {ShadowHeader} from '../../components';
import {pop} from '../../services/NavigationService';
import {AppStyles, Colors, Metrics} from '../../theme';

export default () => {
  const dispatch = useDispatch();

  const user = useSelector(({user}) => user.data);

  const [isNotificatiosOn, setisNotificatiosOn] = useState(
    !!user?.user_notification_setting[0].meta_value,
  );

  const postNotificationSetting = isOn => {
    const payload = new FormData();
    payload.append('notification_setting[notification_all]', isOn ? 1 : 0);
    dispatch(
      request(
        apis.toggleNotifications,
        apis.serviceTypes.POST,
        payload,
        null,
        false,
        false,
        ({notification_all}) => {
          setisNotificatiosOn(!!notification_all);
          const tmpUsr = _.cloneDeep(user);
          tmpUsr['user_notification_setting'][0].meta_value = notification_all;
          dispatch(generalSaveAction(USER.SUCCESS, tmpUsr));
        },
      ),
    );
  };

  const onValueChange = useCallback(() => {
    setisNotificatiosOn(isOn => {
      postNotificationSetting(!isOn);
      return !isOn;
    });
  }, []);

  const Setting = ({title}) => (
    <View style={styles.containerSetting}>
      <Text style={styles.title}>{title}</Text>
      <Switch value={isNotificatiosOn} onValueChange={onValueChange} />
    </View>
  );

  return (
    <View style={styles.container}>
      <ShadowHeader title="Notification Settings" useShadows onBack={pop} />
      <Setting title="Notifiaction On" />
      {/*
      <Setting title="Appointment Accepted" />
      <Setting title="Appointment Rejected" />
      <Setting title="Appointment Edit" />
      <Setting title="Feedback Received" />
      <Setting title="Offer Accepted" />
      <Setting title="Offer Countered" />
      <Setting title="Offer Rejected" />
      <Setting title="Property Ranking" />
      <Setting title="Findings Addition" /> */}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.primary.palegrey,
  },
  containerSetting: {
    flexDirection: 'row',
    backgroundColor: Colors.primary.white,
    ...AppStyles.lightShadow,
    borderRadius: 4,
    marginHorizontal: Metrics.baseMargin,
    marginTop: Metrics.baseMargin,
    alignItems: 'center',
    paddingLeft: Metrics.baseMargin,
    padding: Metrics.smallMargin,
  },
  title: {flex: 1, ...AppStyles.gbRe(14, Colors.primary.darkslateblue)},
});
