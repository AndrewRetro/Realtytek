import React, {useState, useEffect} from 'react';
import {View, Text, StyleSheet, ScrollView, Image} from 'react-native';
import moment from 'moment';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import {Calendar} from 'react-native-calendars';

import ListEmpty from '@reuseableComponents/FlatListHandler/ListEmpty';
import {Loader, ButtonView} from '@reuseableComponents';
import {BackHeader, CardAppointmentCalender} from '@components';

import {Colors, Fonts, Images, Metrics} from '../../theme';
import {useSelector, useDispatch} from 'react-redux';
import constants from '@constants';
import {request} from '@serviceAction';
import apis from '@apis';

export default function () {
  const dispatch = useDispatch();

  const user = useSelector(({user}) => user.data);
  const [state, setState] = useState({
    currentDate: moment(new Date()).format(constants.DB_DATE_FORMAT),
    markedDate: [],
    pickedDate: new Date(),
    appointments: [],
    isFetching: false,
    isShowDatePicker: false,
  });
  const {currentDate, markedDate, pickedDate} = state;
  const momentPickedDate = moment(pickedDate);

  useEffect(() => {
    fetchAppointments(state.pickedDate);
  }, []);

  const fetchAppointments = date => {
    setState(s => ({...s, isFetching: true}));
    dispatch(
      request(
        apis.appointments,
        apis.serviceTypes.GET,
        {
          year: moment(date).format('YYYY'),
          month: moment(date).format('MM'),
        },
        null,
        false,
        false,
        appointments =>
          setState(s => ({
            ...s,
            appointments,
            isFetching: false,
            markedDate: appointments.map(
              ({appointment_date}) => appointment_date,
            ),
          })),
      ),
    );
  };

  const RenderAppointments = () =>
    state.appointments.map(appointment => (
      <CardAppointmentCalender
        key={appointment.id}
        appointment={appointment}
        agentName={appointment?.client?.name}
      />
    ));

  const RenderLoader = () =>
    state.isFetching ? (
      <Loader
        size={'small'}
        spinerColor={Colors.secondary.xGray}
        style={{
          justifyContent: 'flex-start',
          flexDirection: 'column-reverse',
          height: Metrics.widthRatio(130),
          width: Metrics.screenWidth,
        }}
      />
    ) : null;

  const RenderEmpty = () =>
    !state.appointments.length && !state.isFetching && <ListEmpty />;

  const onPickDate = () =>
    setState(s => ({
      ...s,
      isShowDatePicker: true,
    }));

  const onDateTimePicked = date => {
    setState(s => ({
      ...s,
      isShowDatePicker: false,
      pickedDate: date,
      isFetching: true,
      markedDate: [],
      appointments: [],
    }));
    fetchAppointments(date);
  };

  const onCancelDatePicker = () =>
    setState(s => ({...s, isShowDatePicker: false}));

  return (
    <View style={styles.container}>
      <BackHeader useDrawer title="Calendar" user={user} />
      <ScrollView bounces={false} contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
            }}>
            <Text style={styles.heading}>
              {momentPickedDate.format('MMMM')}
            </Text>
            <ButtonView onPress={onPickDate} style={styles.containerDownArrow}>
              <Image
                style={{marginLeft: Metrics.baseMargin}}
                source={Images.icIconAwesomeCaretDown}
              />
            </ButtonView>
          </View>
          <Text style={styles.yearTxt}>{momentPickedDate.format('YYYY')}</Text>
        </View>
        <Calendar
          key={state.pickedDate}
          renderHeader={() => null}
          theme={{
            textDayHeaderFontWeight: '500',
            calendarBackground: 'transparent',
            textSectionTitleColor: Colors.primary.darkslateblue,
            textDayHeaderFontFamily: `Gibson-${Fonts.Type.Regular}`,
          }}
          hideArrows={true}
          current={momentPickedDate.format(constants.DB_DATE_FORMAT)}
          dayComponent={({date, state}) => {
            const isMarked = markedDate.includes(date.dateString);
            const isSelected = date.dateString == currentDate;
            return (
              <View
                style={[
                  styles.dateContainer,
                  isSelected && {
                    backgroundColor: `${Colors.primary.clearblue}21`,
                  },
                ]}>
                <View
                  style={[
                    styles.dot,
                    !isMarked && {backgroundColor: 'transparent'},
                  ]}
                />
                <Text
                  style={
                    state === 'disabled' ? styles.disableTxt : styles.activeTxt
                  }>
                  {date.day}
                </Text>
              </View>
            );
          }}
        />
        <View>
          <Text style={styles.listHeader}>
            {momentPickedDate.format('DD MMMM, YYYY')}
          </Text>
          <RenderAppointments />
          <RenderLoader />
          <RenderEmpty />
        </View>

        <DateTimePickerModal
          date={state.pickedDate}
          isVisible={state.isShowDatePicker}
          mode={'date'}
          onConfirm={onDateTimePicked}
          onCancel={onCancelDatePicker}
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingBottom: Metrics.xDoubleBaseMargin,
  },
  header: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Metrics.baseMargin,
    marginHorizontal: Metrics.baseMargin,
  },
  heading: {
    ...Fonts.font({
      size: 30,
      color: Colors.primary.clearblue,
    }),
    letterSpacing: -0.6,
  },
  yearTxt: {
    ...Fonts.font({
      size: 14,
    }),
    letterSpacing: -0.28,
    opacity: 0.7,
  },
  activeTxt: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.purplishbrown,
    }),
    letterSpacing: -0.28,
    textAlign: 'center',
  },
  disableTxt: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.purplishbrown,
    }),
    opacity: 0.4,
    letterSpacing: -0.28,
    textAlign: 'center',
  },
  dateContainer: {
    width: 50,
    height: 50,
    borderRadius: 50,
    justifyContent: 'center',
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 8,
    marginBottom: 4,
    alignSelf: 'center',
    backgroundColor: Colors.primary.clearblue,
  },
  listHeader: {
    ...Fonts.font({
      size: 24,
      color: Colors.primary.darkslateblue,
    }),
    marginLeft: Metrics.baseMargin,
    marginTop: Metrics.doubleBaseMargin,
  },
  cardContainer: {
    borderRadius: 4,
    flexDirection: 'row',
    padding: Metrics.baseMargin,
    shadowColor: 'rgba(0, 0, 0, 0.04)',
    marginVertical: Metrics.smallMargin,
    marginHorizontal: Metrics.baseMargin,
    backgroundColor: Colors.primary.white,
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowRadius: 10,
    shadowOpacity: 1,
    elevation: 2,
  },
  cardHeading: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.darkslateblue,
    }),
  },
  cardDesc: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: 8,
  },
  containerDownArrow: {
    paddingHorizontal: Metrics.baseMargin,
  },
});
