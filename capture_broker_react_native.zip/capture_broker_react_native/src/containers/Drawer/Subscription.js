import React, {useCallback, useRef, useState} from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import ListEmpty from '../../reuseableComponents/FlatListHandler/ListEmpty';

import {BigBtn, ShadowHeader} from '../../components';
import {
  ImageHandler,
  Loader,
  ButtonView,
  TermsAndConditionsModal,
} from '../../reuseableComponents';
import {pop} from '../../services/NavigationService';
import {Colors, Fonts, Metrics, Images, AppStyles} from '../../theme';
import {WithSubscription} from '@hoc';
import utility from '@utils';
import apis from '@apis';

const dummyData = [
  'Field Agent App',
  'Unlimited Prospecting',
  'Customer/Client Tracking',
  'Complete access to all features',
  'Home Search and Transaction Tracking',
  // 'Full Access to all field agent features',
];

const Subscription = props => {
  const [state, setState] = useState({
    selectedSub: null,
    isTermsAccepted: false,
  });

  const {
    isFetching,
    subscriptions,
    onRequestSubscription,
    purchases,
    restoreSubscription,
  } = props;

  const termsModal = useRef();

  const onBuy = () => {
    onRequestSubscription(state.selectedSub);
  };

  const onSubSelected = productId => () =>
    setState(s => ({...s, selectedSub: productId}));

  const Packages = () => {
    return (
      <View style={styles.subWrapper}>
        {subscriptions.map(sub => {
          const isSelected = sub.productId == state.selectedSub?.productId;

          const containerStyle = {
            ...styles.subContainer,
            ...(isSelected && {borderColor: Colors.primary.clearblue}),
          };

          const subTxtStyle = {
            ...styles.subTxt,
            ...(isSelected && styles.inative),
          };

          const priceTxtStyle = {
            ...styles.amount,
            ...(isSelected && styles.inative),
          };

          return (
            <ButtonView
              onPress={onSubSelected(sub)}
              key={sub.productId}
              style={containerStyle}>
              <Text style={subTxtStyle}>{sub.title}</Text>
              <Text style={priceTxtStyle}>{sub.localizedPrice}</Text>
            </ButtonView>
          );
        })}
      </View>
    );
  };

  const onRestoreSubscription = useCallback(() => {
    if (Array.isArray(purchases) && !purchases.length) {
      utility.showFlashMessage('No purchases found to restore', 'error');
    } else {
      restoreSubscription(purchases, true);
    }
  }, [purchases]);

  const cbOnAcceptTerms = () => {};

  return (
    <View style={styles.container}>
      <ShadowHeader useShadows title="Subscriptions" onBack={pop} />
      {isFetching ? (
        <Loader />
      ) : subscriptions.length ? (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.content}>
          <Packages />
          {utility.isPlatformIOS() && (
            <RestorePurchase onPress={onRestoreSubscription} />
          )}
          <View style={{marginRight: Metrics.baseMargin}}>
            {dummyData.map(ele => (
              <View key={ele} style={styles.checkContainer}>
                <ImageHandler source={Images.icCheck} />
                <Text style={styles.checkDesc}>{ele}</Text>
              </View>
            ))}
            <Text style={styles.desc}>
              • Payment will be processed through your iTunes account at
              confirmation of purchase. {'\n\n'}• Your subscription will
              automatically renew per the billing cycle of your subscription
              (i.e., yearly) 24-hours before the end of the current period, and
              your credit card will be charged through your iTunes account.{' '}
              {'\n\n'}• The renewal charge for your Subscription shall be the
              same as the original purchase price, unless you are otherwise
              notified in advance. {'\n\n'}• To avoid the billing of fees for
              the next Subscription period, you must switch off your yearly
              Subscription at least 24-hours before the end of the current
              period. {'\n\n'}• You can turn off auto-renew at any time from
              your iTunes account settings. {'\n\n'}• You will not receive a
              refund for the fees you already paid for your current Subscription
              period and you will continue to have access to your Subscription
              until the end of your current Subscription period. {'\n\n'}•
              Realtytek provides no refunds and you may cancel auto-renewal at
              any time.
            </Text>
            {utility.isPlatformIOS() && (
              <ButtonView
                onPress={() => termsModal.current.show()}
                style={{marginBottom: Metrics.doubleBaseMargin}}>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Text
                    style={{
                      ...AppStyles.gbRe(16, Colors.primary.theme.clearblue),
                      textDecorationLine: 'underline',
                    }}>
                    Terms of Use(EULA)
                  </Text>
                </View>
              </ButtonView>
            )}
            {state.selectedSub && <BigBtn onPress={onBuy} title="Buy" />}
          </View>
        </ScrollView>
      ) : (
        <ListEmpty />
      )}
      <TermsAndConditionsModal
        ref={termsModal}
        cbOnAcceptTerms={cbOnAcceptTerms}
        url={apis.terms}
        title="EULA"
      />
    </View>
  );
};

const RestorePurchase = ({onPress}) => {
  return (
    <BigBtn
      title="Restore Purchase"
      onPress={onPress}
      style={{
        width: Metrics.screenWidth - Metrics.widthRatio(32),
        marginBottom: Metrics.doubleBaseMargin,
      }}
    />
  );
};

// true reperesents fetching packages bool
export default WithSubscription(Subscription, {
  isFetchPackages: true,
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginLeft: Metrics.baseMargin,
    paddingBottom: Metrics.xDoubleBaseMargin,
  },
  subWrapper: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  subContainer: {
    width:
      (Metrics.screenWidth - 2 * Metrics.baseMargin - Metrics.smallMargin) / 2,
    height: Metrics.heightRatio(150),
    borderWidth: 1,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: Metrics.doubleBaseMargin,
    marginRight: Metrics.smallMargin,
  },
  amount: {
    ...Fonts.font({
      size: 18,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: Metrics.baseMargin,
  },
  subTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkslateblue,
    }),
    textAlign: 'center',
  },
  inative: {
    color: Colors.primary.clearblue,
  },
  checkContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Metrics.baseMargin,
  },
  checkDesc: {
    marginLeft: Metrics.baseMargin,
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkslateblue,
    }),
  },
  desc: {
    marginBottom: Metrics.doubleBaseMargin,
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkindigo,
    }),
  },
});
