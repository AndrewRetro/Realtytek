import React, {useEffect, useRef, useState} from 'react';
import {View, ScrollView, Text, StyleSheet, Image} from 'react-native';
import {useDispatch} from 'react-redux';
import _ from 'lodash';

import {BigBtn, ShadowHeader, AddLinkModal} from '../../components';
import {ButtonView, Loader} from '../../reuseableComponents';
import ListEmpty from '@reuseableComponents/FlatListHandler/ListEmpty';

import {Colors, Fonts, Images, Metrics, AppStyles} from '../../theme';
import {pop} from '../../services/NavigationService';
import {openDocumentPicker} from '@services/MultipickerUtils';
import {request} from '@serviceAction';
import apis from '@apis';
import utility from '@utils';

export default function () {
  const dispatch = useDispatch();

  const addLinkModalRef = useRef();

  useEffect(() => {
    getDisclosures();
  }, []);

  const [state, setState] = useState({links: [], docs: [], isFetching: false});

  const onPickDocument = () =>
    openDocumentPicker(doc => {
      const payload = new FormData();
      payload.append('document', {
        uri: doc.uri,
        name: doc.name.split(' ').join('_'),
        type: doc.type,
      });
      payload.append('filename', doc.name.split(' ').join('_'));
      uploadDocOrLink(payload);
    }, onDocumentError);
  const onDocumentError = err => console.log('doc err : ', err);

  const uploadDocOrLink = payload => {
    dispatch(
      request(
        apis.uploadDoc,
        apis.serviceTypes.POST,
        payload,
        null,
        true,
        false,
        ({document, link}) =>
          setState(s => ({...s, links: link, docs: document})),
      ),
    );
  };

  const getDisclosures = () => {
    setState(s => ({...s, isFetching: true}));
    dispatch(
      request(
        apis.getDisclosures,
        apis.serviceTypes.GET,
        {},
        null,
        false,
        false,
        ({link, document}) => {
          setState(s => ({
            ...s,
            links: link,
            docs: document,
            isFetching: false,
          }));
        },
      ),
    );
  };

  const onAddLink = ({title, link}) => {
    const payload = new FormData();
    payload.append('link', link);
    payload.append('title', title);
    uploadDocOrLink(payload);
  };

  const onShowAddLinkModal = () => addLinkModalRef.current.show();

  const Docs = () => {
    return (
      <View style={styles.containerRow}>
        {state.docs.map((doc, index) => {
          return (
            <ButtonView
              style={styles.doc}
              key={`doc_${index}`}
              onPress={() => utility.openLink(doc.file_url)}>
              <Image style={styles.icDoc} source={Images.icDoc} />
              <Text
                style={styles.txtDocTitle}
                numberOfLines={3}
                ellipsizeMode="tail">
                {doc.filename ? doc.filename : 'Doc'}
              </Text>
              <ButtonView
                onPress={onDeleteLinkOrDocRequest(doc.id, 'docs')}
                style={{
                  position: 'absolute',
                  top: 0,
                  right: 0,
                  paddingTop: Metrics.widthRatio(1),
                  paddingRight: Metrics.widthRatio(1),
                  paddingLeft: Metrics.widthRatio(5),
                  paddingBottom: Metrics.widthRatio(5),
                }}>
                <Image
                  style={{
                    width: Metrics.widthRatio(30),
                    height: Metrics.widthRatio(30),
                    resizeMode: 'contain',
                    tintColor: 'red',
                  }}
                  source={Images.icCloseCircle}
                />
              </ButtonView>
            </ButtonView>
          );
        })}
      </View>
    );
  };

  const onLink = link => () => utility.openLink(link);

  const onDeleteLinkOrDoc = (id, type) => {
    if (type == 'docs') {
      const clonedDocs = _.cloneDeep(state.docs);
      clonedDocs.splice(
        clonedDocs.findIndex(item => item.id == id),
        1,
      );
      setState(s => ({...s, docs: clonedDocs}));
    } else {
      const clonedLinks = _.cloneDeep(state.links);
      clonedLinks.splice(
        clonedLinks.findIndex(item => item.id == id),
        1,
      );
      setState(s => ({...s, links: clonedLinks}));
    }
  };

  const onDeleteLinkOrDocRequest = (id, type) => () => {
    dispatch(
      request(
        apis.deleteDocOrLink,
        apis.serviceTypes.GET,
        {
          type: type == 'docs' ? 'document' : 'link',
          record_id: id,
        },
        null,
        false,
        false,
        () => {
          onDeleteLinkOrDoc(id, type);
        },
      ),
    );
  };

  const LinkItem = ({data}) => {
    const {id, title, link} = data;

    return (
      <ButtonView style={styles.content} onPress={onLink(link)}>
        <View style={styles.card}>
          <View style={styles.cardWrapper}>
            <Text style={styles.cardTxt}>{title ? title : 'Title'}</Text>
            <ButtonView
              style={styles.deleteBtnLink}
              onPress={onDeleteLinkOrDocRequest(id, 'links')}>
              <Image source={Images.icDelete} />
            </ButtonView>
          </View>
          <Text numberOfLines={2} style={styles.cardLink}>
            {link}
          </Text>
        </View>
      </ButtonView>
    );
  };

  const Links = () => {
    return state.links.map((link, index) => (
      <LinkItem data={link} index={index} key={link.id} />
    ));
  };

  const Buttons = () => {
    return (
      <View style={styles.containerBtn}>
        <BigBtn
          dashed
          bgColor="transparent"
          borderColor={Colors.primary.lightgreyblue}
          txtColor={Colors.primary.lightgreyblue}
          title="Attach Documents"
          onPress={onPickDocument}
          style={styles.bigBtn}
        />
        <BigBtn
          alignCenter
          useBold
          title="Add Link"
          style={styles.bigBtn}
          onPress={onShowAddLinkModal}
        />
      </View>
    );
  };

  const isEmpty = !state.docs.length && !state.links.length;

  return (
    <View style={styles.container}>
      <ShadowHeader
        onBack={pop}
        title="Lenders & State Agency Disclosure"
        useShadows
      />
      {state.isFetching ? (
        <Loader />
      ) : isEmpty ? (
        <ListEmpty />
      ) : (
        <ScrollView contentContainerStyle={{paddingBottom: Metrics.baseMargin}}>
          <Text style={styles.txtTitleDoc}>Documents</Text>
          <Docs />
          <Text style={styles.txtTitleLinks}>Links</Text>
          <Links />
          <AddLinkModal ref={addLinkModalRef} onSave={onAddLink} />
        </ScrollView>
      )}
      {!state.isFetching && <Buttons />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'space-between',
    marginHorizontal: Metrics.baseMargin,
    marginTop: Metrics.widthRatio(18),
  },
  card: {
    borderRadius: 6,
    padding: Metrics.baseMargin,
    backgroundColor: Colors.primary.white,
  },
  cardTxt: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.darkslateblue,
    }),
  },
  cardWrapper: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  cardLink: {
    ...Fonts.font({
      size: 12,
      color: Colors.primary.clearblue,
    }),
    lineHeight: Metrics.heightRatio(20),
  },
  containerRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginRight: Metrics.baseMargin,
  },
  doc: {
    width: Metrics.widthRatio(
      Metrics.screenWidth / 3 - Metrics.baseMargin * 1.4,
    ),
    marginTop: Metrics.baseMargin,
    backgroundColor: 'white',
    ...AppStyles.heavyShadow,
    ...AppStyles.centerAlign,
    borderRadius: Metrics.widthRatio(6),
    marginLeft: Metrics.baseMargin,
  },
  icDoc: {
    width: Metrics.widthRatio(80),
    height: Metrics.widthRatio(80),
    resizeMode: 'contain',
    tintColor: Colors.primary.clearblue,
  },
  bigBtn: {
    marginBottom: Metrics.baseMargin,
    width: '93%',
    marginLeft: Metrics.baseMargin,
  },
  containerBtn: {
    width: Metrics.screenWidth,
    backgroundColor: 'white',
    padding: Metrics.baseMargin,
    ...AppStyles.heavyShadow,
    marginTop: Metrics.widthRatio(1),
  },
  txtTitleDoc: {
    ...AppStyles.gbSb(16, Colors.primary.black),
    marginLeft: Metrics.baseMargin,
    marginTop: Metrics.baseMargin,
  },
  txtTitleLinks: {
    marginTop: Metrics.doubleBaseMargin,
    ...AppStyles.gbSb(16, Colors.primary.black),
    marginLeft: Metrics.baseMargin,
  },
  deleteBtnLink: {
    paddingLeft: Metrics.baseMargin,
    paddingBottom: Metrics.smallMargin,
  },
  icDeleteDoc: {
    width: Metrics.widthRatio(30),
    height: Metrics.widthRatio(30),
    resizeMode: 'contain',
    tintColor: Colors.primary.coral,
  },
  containerIcDeleteDoc: {
    position: 'absolute',
    top: 0,
    right: 0,
    paddingLeft: Metrics.smallMargin,
    paddingBottom: Metrics.smallMargin,
  },
  txtDocTitle: {
    marginHorizontal: Metrics.baseMargin,
    paddingBottom: Metrics.smallMargin,
    ...AppStyles.gbRe(13, Colors.primary.darkslateblue),
  },
});
