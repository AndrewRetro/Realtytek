import React, {useEffect} from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import OneSignal from 'react-native-onesignal';

import {
  BackHeader,
  BigBtn,
  GradientContainer,
  MaskedInput,
} from '../../components';
import {
  FormHandler,
  ImageHandler,
  MaterialTextField,
} from '../../reuseableComponents';

import {INPUT_TYPES} from '../../reuseableComponents/FormHandler/Constants';
import {pop} from '../../services/NavigationService';
import {Images, Metrics, Fonts, Colors} from '../../theme';
import Apis from '@apis';
import Utils from '@utils';

// redux imports
import {useDispatch} from 'react-redux';
import {request} from '../../actions/ServiceAction';
import constants from '@constants';

export default () => {
  const dispatch = useDispatch();
  const intervalRef = React.useRef(null);
  const formHandler = React.useRef();

  const [state, setState] = React.useState({
    isPassVisible: false,
    isCPassVisible: false,
    device_token: null,
  });

  useEffect(() => {
    intervalRef.current = setInterval(() => fetchDeviceState(), 5000);
  }, []);

  const fetchDeviceState = async () => {
    const {userId} = await OneSignal.getDeviceState();
    userId && setState(s => ({...s, device_token: userId}));
  };

  onSignup = () => {
    const data = formHandler.current.onSubmitForm();
    if (data) {
      dispatch(
        request(
          Apis.signup,
          Apis.serviceTypes.POST,
          {
            ...data,
            device_type: Utils.isPlatformAndroid ? 'android' : 'ios',
            device_token: state.device_token,
            user_group_id: constants.USER_GROUPS.USER_GROUP_ID_1,
          },
          null,
          true,
          false,
          success => {
            pop();
            Utils.showFlashMessage(
              'Check your email for verification link. Login after your email has been verified ',
              'success',
            );
          },
        ),
      );
    }
  };

  const onShowPass = () =>
    setState(s => ({...s, isPassVisible: !s.isPassVisible}));

  const onShowCPass = () =>
    setState(s => ({...s, isCPassVisible: !s.isCPassVisible}));

  return (
    <GradientContainer>
      <BackHeader onBack={pop} />
      <ScrollView
        alwaysBounceVertical={false}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <ImageHandler source={Images.icLoginLogo} />
        </View>
        <Text style={styles.description}>Please Register here</Text>
        <Text style={styles.mainTxt}>Agent Registration</Text>
        <FormHandler ref={formHandler}>
          <MaterialTextField
            placeholder="Name"
            type={INPUT_TYPES.TEXT}
            leftIcon={Images.icName}
            identifier="name"
            blurOnSubmit={false}
            error="Name is required"
          />
          <MaterialTextField
            placeholder="Email"
            type={INPUT_TYPES.EMAIL}
            leftIcon={Images.icEmail}
            identifier="email"
            blurOnSubmit={false}
          />
          <MaskedInput
            label="Phone Number"
            placeholder="Phone number"
            type={INPUT_TYPES.NUMBER}
            identifier="mobile_no"
            error="Phone number is required"
            leftIcon={Images.icPhone}
            isLabeledField={false}
            blurOnSubmit={false}
          />
          <MaterialTextField
            placeholder="License Number"
            type={INPUT_TYPES.TEXT}
            leftIcon={Images.icOther}
            identifier="license_number"
            blurOnSubmit={false}
            error="License is required"
          />
          <MaterialTextField
            placeholder="License State"
            type={INPUT_TYPES.TEXT}
            leftIcon={Images.icOther}
            identifier="licence_state"
            blurOnSubmit={false}
            error="License state is required"
          />
          <MaterialTextField
            placeholder="Password"
            type={state.isPassVisible ? INPUT_TYPES.TEXT : INPUT_TYPES.PASSWORD}
            leftIcon={Images.icOther}
            identifier="password"
            onRightPress={onShowPass}
            rightIcon={state.isPassVisible ? Images.icEyeOff : Images.icEye}
            blurOnSubmit={false}
          />
          <MaterialTextField
            placeholder="Confirm password"
            type={
              state.isCPassVisible
                ? INPUT_TYPES.TEXT
                : INPUT_TYPES.CONFIRM_PASSWORD
            }
            leftIcon={Images.icOther}
            identifier="confirm_password"
            onRightPress={onShowCPass}
            rightIcon={state.isCPassVisible ? Images.icEyeOff : Images.icEye}
            blurOnSubmit={true}
          />
        </FormHandler>
        <BigBtn onPress={onSignup} title="NEXT" useMargin />
      </ScrollView>
    </GradientContainer>
  );
};

const styles = StyleSheet.create({
  header: {
    flex: Metrics.screenHeight < 800 ? 0.2 : 0.15,
  },
  content: {
    marginHorizontal: 25,
    paddingBottom: Metrics.xDoubleBaseMargin,
  },
  description: {
    marginTop: Metrics.xDoubleBaseMargin,
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkslateblue,
    }),
  },
  mainTxt: {
    ...Fonts.font({
      type: Fonts.Type.SemiBold,
      size: 33,
      color: Colors.primary.darkslateblue,
    }),
    lineHeight: 42,
    marginTop: 8,
  },
});
