import React, {useRef} from 'react';
import {ScrollView, Text, View, Image, SafeAreaView} from 'react-native';

import {
  MaterialTextField,
  FormHandler,
  ButtonView,
} from '../../reuseableComponents';
import {BigBtn} from '../../components';
import {INPUT_TYPES} from '../../reuseableComponents/FormHandler/Constants';
import {AppStyles, Metrics, Images, Colors} from '../../theme';
import {pop} from '@services/NavigationService';
import apis from '@apis';
import utility from '@utils';

// redux imports
import {useDispatch} from 'react-redux';
import {request} from '@serviceAction';
import constants from '@constants';

export default ForgotPass = () => {
  const dispatch = useDispatch();
  const formHandler = React.useRef();
  const onForgotPass = payload => {
    dispatch(
      request(
        apis.forgotPass,
        apis.serviceTypes.POST,
        payload,
        null,
        true,
        false,
        () => {
          utility.showFlashMessage(
            'Check your email for reset password link',
            'success',
          );
          pop();
        },
      ),
    );
  };

  const onSubmitForm = () => {
    const data = formHandler.current.onSubmitForm();
    if (data)
      onForgotPass({email: data.email, type: constants.USER_TYPE_BROKER});
  };

  const Header = () => (
    <View>
      <ButtonView onPress={pop}>
        <Image
          source={Images.icBackArrow}
          style={{
            marginLeft: Metrics.doubleBaseMargin,
            marginTop: Metrics.baseMargin,
          }}
        />
      </ButtonView>
      <Image
        source={Images.icLoginLogo}
        style={{marginTop: Metrics.baseMargin}}
      />
    </View>
  );

  return (
    <ScrollView
      contentContainerStyle={{
        width: Metrics.screenWidth,
        height: Metrics.screenHeight,
        backgroundColor: Colors.primary.white,
      }}>
      <SafeAreaView style={{flex: 1}}>
        <Header />
        <View
          style={{
            flex: 1,
            justifyContent: 'center',
            padding: Metrics.doubleBaseMargin,
            marginBottom: Metrics.widthRatio(90),
          }}>
          <Text style={AppStyles.gbSb(24, Colors.primary.darkslateblue)}>
            Forgot Password
          </Text>
          <Text
            style={{
              ...AppStyles.gbRe(14, Colors.primary.lightgreyblue),
              marginBottom: Metrics.baseMargin * 1.5,
              marginTop: Metrics.baseMargin,
            }}>
            Please enter your email address associated with your account
          </Text>

          <FormHandler ref={formHandler}>
            <MaterialTextField
              leftIcon={Images.icEmail}
              placeholder="Email"
              identifier="email"
              type={INPUT_TYPES.EMAIL}
              errror="Email is required"
            />
          </FormHandler>
          <BigBtn
            onPress={onSubmitForm}
            title="SEND"
            style={{
              width: Metrics.screenWidth - Metrics.doubleBaseMargin * 2,
              marginTop: Metrics.baseMargin,
            }}
          />
        </View>
      </SafeAreaView>
    </ScrollView>
  );
};
