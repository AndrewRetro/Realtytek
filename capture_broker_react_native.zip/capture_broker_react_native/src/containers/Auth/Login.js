import React, {useContext, useEffect} from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import OneSignal from 'react-native-onesignal';

import {LoginContext} from '../../contexts';
import {GradientContainer, BigBtn} from '../../components';
import {Colors, Metrics, Fonts, Images} from '../../theme';
import {
  ButtonView,
  FormHandler,
  ImageHandler,
  MaterialTextField,
} from '../../reuseableComponents';
import {INPUT_TYPES} from '../../reuseableComponents/FormHandler/Constants';
import {navigate} from '../../services/NavigationService';
import Apis from '@apis';
import Utils from '@utils';
import HttpServiceManager from '../../services/HttpServiceManager';

// redux imports
import {useDispatch} from 'react-redux';
import {request} from '../../actions/ServiceAction';
import {USER} from '@actionTypes';
import constants from '@constants';

const Login = () => {
  const {setLogin} = useContext(LoginContext);
  const [isShowPass, setShowPass] = React.useState(false);
  const [state, setState] = React.useState({
    device_token: null,
  });
  const dispatch = useDispatch();
  const formHandler = React.useRef();
  const intervalRef = React.useRef(null);

  useEffect(() => {
    intervalRef.current = setInterval(() => fetchDeviceState(), 5000);
  }, []);

  const fetchDeviceState = async () => {
    const {userId} = await OneSignal.getDeviceState();
    userId && setState(s => ({...s, device_token: userId}));
  };

  const onForgotPass = () => navigate('ForgotPass');

  const onShowPass = () => {
    setShowPass(s => !s);
  };

  onLogin = () => {
    const data = formHandler.current.onSubmitForm();
    if (data) {
      dispatch(
        request(
          Apis.login,
          Apis.serviceTypes.POST,
          {
            ...data,
            device_type: Utils.isPlatformAndroid ? 'android' : 'ios',
            device_token: state.device_token,
            user_group_id: 1,
            user_type: constants.USER_TYPE_BROKER,
          },
          USER,
          true,
          false,
          success => {
            HttpServiceManager.getInstance().userToken = success.api_token;
            setLogin(true);
          },
        ),
      );
    }
  };

  return (
    <ScrollView
      keyboardShouldPersistTaps="handled"
      showsVerticalScrollIndicator={false}
      bounces={0}
      contentContainerStyle={{flexGrow: 1}}>
      <GradientContainer style={styles.container}>
        <View style={styles.header}>
          <ImageHandler source={Images.icLoginLogo} />
        </View>
        <View style={styles.content}>
          <Text style={styles.description}>Please Login to your account</Text>
          <Text style={styles.mainTxt}>Login Here</Text>
          <FormHandler ref={formHandler}>
            <MaterialTextField
              leftIcon={Images.icEmail}
              placeholder="Email"
              type={INPUT_TYPES.EMAIL}
              identifier="email"
              blurOnSubmit={false}
            />
            <MaterialTextField
              leftIcon={Images.icPassword}
              placeholder="Password"
              type={isShowPass ? INPUT_TYPES.TEXT : INPUT_TYPES.PASSWORD}
              rightIcon={isShowPass ? Images.icEyeOff : Images.icEye}
              onRightPress={onShowPass}
              identifier="password"
              blurOnSubmit={true}
            />
          </FormHandler>
          <ButtonView style={styles.forgotPasswordBtn} onPress={onForgotPass}>
            <Text style={styles.forgotPasswordTxt}>Forgot Password?</Text>
          </ButtonView>
          <BigBtn onPress={onLogin} title="SIGN IN" />
        </View>
        <View style={styles.footer}>
          <View style={styles.signInBtn}>
            <Text style={styles.footerText}>Don’t have an account?</Text>
            <ButtonView onPress={() => navigate('Signup')}>
              <Text style={styles.signInTxt}>SIGN UP</Text>
            </ButtonView>
          </View>
        </View>
      </GradientContainer>
    </ScrollView>
  );
};

export default Login;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-between',
  },
  header: {
    flex: Metrics.screenHeight < 800 ? 0.3 : 0.4,
    justifyContent: 'center',
  },
  content: {
    flex: Metrics.screenHeight < 800 ? 0.55 : 0.45,
    paddingHorizontal: 25,
  },
  footer: {
    flex: 0.15,
    alignItems: 'center',
    backgroundColor: Colors.primary.white,
  },
  signInBtn: {
    flexDirection: 'row',
    padding: Metrics.baseMargin,
    marginTop: Metrics.heightRatio(8),
  },
  footerText: {
    ...Fonts.font({
      size: 15,
      color: Colors.primary.blueyGrey,
    }),
  },
  signInTxt: {
    ...Fonts.font({
      size: 15,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.brightlightblue,
    }),
    marginLeft: 5,
  },
  description: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkslateblue,
    }),
    lineHeight: 17,
  },
  mainTxt: {
    ...Fonts.font({
      type: Fonts.Type.SemiBold,
      size: 33,
      color: Colors.primary.dark,
    }),
    lineHeight: 42,
    marginTop: Metrics.heightRatio(8),
  },
  forgotPasswordTxt: {
    ...Fonts.font({
      size: 13,
    }),
  },
  forgotPasswordBtn: {
    paddingRight: 0,
    alignSelf: 'flex-end',
    padding: Metrics.baseMargin,
  },
});
