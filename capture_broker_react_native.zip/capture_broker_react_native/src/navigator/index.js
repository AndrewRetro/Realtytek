//
//  index.js:
//  BoilerPlate
//
//  Created by Retrocube on 10/4/2019, 9:14:05 AM.
//  Copyright © 2019 Retrocube. All rights reserved.
//
import React, {forwardRef, useContext} from 'react';
import {NavigationContainer} from '@react-navigation/native';
import MainStack from './Drawer';
import {AuthStack} from './Stacks';
import {LoginContext} from '../contexts';
import {createStackNavigator} from '@react-navigation/stack';

import AddListing from '@containers/Listing/AddListing';
import ListingDetails from '@containers/Listing/ListingDetails';
import ContactDetails from '@containers/Listing/ContactDetails';
import TouredHomes from '@containers/Customer/TouredHomes';
import RecommendedHomes from '@containers/Customer/RecommendedHomes';
import Search from '@containers/Search';
import PropertyDetail from '@containers/Customer/PropertyDetail';
import Listings from '@containers/Tabs/Listings';

const Stack = createStackNavigator();

const rootNavigator = forwardRef((props, ref) => {
  const {isLogin} = useContext(LoginContext);
  return (
    <NavigationContainer ref={ref}>
      {isLogin ? (
        <Stack.Navigator headerMode="none">
          <Stack.Screen
            name="MainStack"
            component={MainStack}
            options={{
              animationEnabled: false,
            }}
          />
          <Stack.Screen name="AddListing" component={AddListing} />
          <Stack.Screen name="ListingDetails" component={ListingDetails} />
          <Stack.Screen name="Search" component={Search} />
          <Stack.Screen name="PropertyDetail" component={PropertyDetail} />
          <Stack.Screen name="ContactDetails" component={ContactDetails} />
          <Stack.Screen name="TouredHomes" component={TouredHomes} />
          <Stack.Screen name="RecommendedHomes" component={RecommendedHomes} />
          <Stack.Screen name="Properties" component={Listings} />
        </Stack.Navigator>
      ) : (
        <Stack.Navigator headerMode="none">
          <Stack.Screen
            name="AuthStack"
            component={AuthStack}
            options={{
              animationEnabled: false,
            }}
          />
        </Stack.Navigator>
      )}
    </NavigationContainer>
  );
});

export default rootNavigator;
