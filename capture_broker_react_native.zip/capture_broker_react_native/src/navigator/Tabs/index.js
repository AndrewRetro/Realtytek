import React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import Home from '../../containers/Tabs/Home';
import Customers from '../../containers/Tabs/Customers';
import {Colors, Images} from '../../theme';

import Listings from '../../containers/Tabs/Listings';
import Calander from '../../containers/Drawer/Calander';
import Appointment from '../../containers/Tabs/Appointment';
import {ImageHandler} from '../../reuseableComponents';

const Tab = createBottomTabNavigator();

const TabNav = ({props}) => {
  const {bottom} = useSafeAreaInsets();
  return (
    <Tab.Navigator
      tabBarOptions={{
        activeTintColor: Colors.primary.clearblue,
        inactiveTintColor: Colors.primary.darkslateblue,
        style: bottom
          ? {height: 90}
          : {
              height: 70,
              paddingBottom: 10,
            },
      }}>
      <Tab.Screen
        name="Dashboard"
        component={Home}
        options={{
          tabBarIcon: ({focused}) => (
            <ImageHandler
              style={{
                marginBottom: -10,
                tintColor: focused
                  ? Colors.primary.clearblue
                  : Colors.primary.darkslateblue,
              }}
              source={Images.icDashboard}
            />
          ),
          tabBarLabel: 'Dashboard',
        }}
      />
      <Tab.Screen
        name="Customer"
        component={Customers}
        options={{
          tabBarIcon: ({focused}) => (
            <ImageHandler
              style={{
                marginBottom: -10,
                tintColor: focused
                  ? Colors.primary.clearblue
                  : Colors.primary.darkslateblue,
              }}
              source={Images.icCustomer}
            />
          ),
          tabBarLabel: 'Customer',
        }}
      />
      <Tab.Screen
        name="Listings"
        component={Listings}
        options={{
          tabBarIcon: ({focused}) => (
            <ImageHandler
              style={{
                marginBottom: -10,
                tintColor: focused
                  ? Colors.primary.clearblue
                  : Colors.primary.darkslateblue,
              }}
              source={Images.icListitng}
            />
          ),
          tabBarLabel: 'Listings',
        }}
      />
      <Tab.Screen
        name="Calendar"
        component={Calander}
        options={{
          tabBarIcon: ({focused}) => (
            <ImageHandler
              style={{
                marginBottom: -10,
                tintColor: focused
                  ? Colors.primary.clearblue
                  : Colors.primary.darkslateblue,
              }}
              source={Images.icCalendar}
            />
          ),
          tabBarLabel: 'Calendar',
        }}
      />
      <Tab.Screen
        name="Appointments"
        component={Appointment}
        options={{
          tabBarIcon: ({focused}) => (
            <ImageHandler
              style={{
                marginBottom: -10,
                tintColor: focused
                  ? Colors.primary.clearblue
                  : Colors.primary.darkslateblue,
              }}
              source={Images.icAppointments}
            />
          ),
          tabBarLabel: 'Appointments',
        }}
      />
    </Tab.Navigator>
  );
};

export default TabNav;
