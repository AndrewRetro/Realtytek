import React from 'react';

import Tabs from '../Tabs';
import {AboutStack, CustomerStack} from '../Stacks';
import AppDrawer from '../../containers/Drawer';
import Settings from '../../containers/Drawer/Settings';
import Disclosure from '../../containers/Drawer/Disclosure';
import {createStackNavigator} from '@react-navigation/stack';
import {createDrawerNavigator} from '@react-navigation/drawer';
import BusinessCard from '../../containers/Drawer/BusinessCard';
import Subscription from '../../containers/Drawer/Subscription';
import EditBusinessCard from '../../containers/Drawer/EditBusinessCard';
import ChangePassword from '../../containers/Drawer/ChangePassword';
import SubscriptionDetails from '../../containers/Drawer/SubscriptionDetails';
import Profile from '../../containers/Drawer/Profile';
import EditProfile from '../../containers/Drawer/EditProfile';
import NotificationSettings from '../../containers/Drawer/NotificationSettings';
import AppointmentDetails from '../../containers/AppointmentDetails';
import Notification from '../../containers/Notification';
import BuyingPreferences from '@containers/Customer/BuyingPreferences';
import UnderContract from '@containers/Customer/UnderContract';
import TouredHomes from '@containers/Customer/TouredHomes';
import ClientProfile from '@containers/Customer/ClientProfile';

const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

const DrawerStack = () => (
  <Stack.Navigator
    screenOptions={{
      headerShown: false,
    }}>
    <Stack.Screen
      name="TabStack"
      component={Tabs}
      options={{
        headerShown: false,
      }}
    />
    <Stack.Screen name="Profile" component={Profile} />
    <Stack.Screen name="Settings" component={Settings} />
    <Stack.Screen name="Disclosure" component={Disclosure} />
    <Stack.Screen name="AboutStack" component={AboutStack} />
    <Stack.Screen name="EditProfile" component={EditProfile} />
    <Stack.Screen name="Subscription" component={Subscription} />
    <Stack.Screen name="BusinessCard" component={BusinessCard} />
    <Stack.Screen name="CustomerStack" component={CustomerStack} />
    <Stack.Screen name="ChangePassword" component={ChangePassword} />
    <Stack.Screen name="EditBusinessCard" component={EditBusinessCard} />
    <Stack.Screen name="AppointmentDetails" component={AppointmentDetails} />
    <Stack.Screen name="SubscriptionDetails" component={SubscriptionDetails} />
    <Stack.Screen name="Notification" component={Notification} />
    <Stack.Screen name="BuyingPreferences" component={BuyingPreferences} />
    <Stack.Screen name="UnderContract" component={UnderContract} />
    <Stack.Screen name="TouredHomes" component={TouredHomes} />
    <Stack.Screen name="ClientProfile" component={ClientProfile} />
    <Stack.Screen
      name="NotificationSettings"
      component={NotificationSettings}
    />
  </Stack.Navigator>
);

export default DrawerNav = () => (
  <Drawer.Navigator drawerContent={props => <AppDrawer {...props} />}>
    <Drawer.Screen name="DrawerStack" component={DrawerStack} />
  </Drawer.Navigator>
);
