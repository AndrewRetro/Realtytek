import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {Login, Signup, ForgotPass} from '../../containers';
import DrawerNav from '../Drawer';
import About from '../../containers/About/About';
import Terms from '../../containers/About/Terms';
import Privacy from '../../containers/About/Privacy';
import Webview from '../../containers/About/Webview';
import FAQ from '../../containers/About/FAQ';
import Lead from '../../containers/Customer/Lead';
import EditClient from '../../containers/Customer/EditClient';
import RecommendedHomes from '../../containers/Customer/RecommendedHomes';
import AddLead from '../../containers/Customer/AddLead';
import MyListing from '../../containers/Customer/MyListing';

const Stack = createStackNavigator();

const AuthStack = () => (
  <Stack.Navigator>
    <Stack.Screen
      name="Login"
      component={Login}
      options={{headerShown: false}}
    />
    <Stack.Screen
      name="Signup"
      component={Signup}
      options={{headerShown: false}}
    />
    <Stack.Screen
      name="ForgotPass"
      component={ForgotPass}
      options={{headerShown: false}}
    />
  </Stack.Navigator>
);

const MainStack = ({navigation}) => (
  <Stack.Navigator headerMode="none">
    <Stack.Screen name="DrawerNav" component={DrawerNav} />
  </Stack.Navigator>
);

const AboutStack = () => (
  <Stack.Navigator headerMode="none" initialRouteName="About">
    <Stack.Screen name="FAQ" component={FAQ} />
    <Stack.Screen name="About" component={About} />
    <Stack.Screen name="Terms" component={Terms} />
    <Stack.Screen name="Privacy" component={Privacy} />
    <Stack.Screen name="Webview" component={Webview} />
  </Stack.Navigator>
);

const CustomerStack = () => (
  <Stack.Navigator headerMode="none" initialRouteName="Customers">
    <Stack.Screen name="Lead" component={Lead} />
    <Stack.Screen name="AddLead" component={AddLead} />
    <Stack.Screen name="MyListing" component={MyListing} />
    <Stack.Screen name="EditClient" component={EditClient} />
    <Stack.Screen name="RecommendedHomes" component={RecommendedHomes} />
  </Stack.Navigator>
);

export {AuthStack, MainStack, AboutStack, CustomerStack};
