import React, {useRef, useEffect} from 'react';
import {Platform} from 'react-native';
import _ from 'lodash';

import constants from '@constants';

import {
  useIAP,
  validateReceiptIos,
  acknowledgePurchaseAndroid,
} from 'react-native-iap';
import {useDispatch, useSelector} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';
import {generalSaveAction} from '@serviceAction';
import {USER} from '@actionTypes';

const IS_IOS = Platform.OS == 'ios';
const SKUS_ID_BACKEND = IS_IOS
  ? {
      'com.realtytekbroker.monthly': 1,
      'com.realtytekbroker.yearly': 2,
    }
  : {
      'com.capturebroker.monthly': 1,
      'com.capturebroker.yearly': 2,
    };

const useSubscriptionValidation = () => {
  const {connected, availablePurchases, getAvailablePurchases} = useIAP();

  const dispatch = useDispatch();

  const user = useSelector(({user}) => user.data);

  useEffect(() => {
    getAvailablePurchases();
  }, [connected, getAvailablePurchases]);

  useEffect(() => {
    availablePurchases && !!availablePurchases.length && lockFunc();
  }, [availablePurchases]);

  const lock = useRef({isExecuted: false});
  const lockFunc = () => {
    if (!lock.current.isExecuted) {
      lock.current = {isExecuted: true};
      restoreSubscription(availablePurchases);
    }
  };

  const restoreSubscription = async purchases => {
    if (purchases.length) {
      let purchase = null;

      if (IS_IOS) purchase = purchases[purchases.length - 1];
      else purchase = purchases[0];

      const receipt = purchase.transactionReceipt;

      let gateway_response = null;
      if (receipt) {
        if (IS_IOS) {
          gateway_response = await validateReceipt(receipt);
          if (gateway_response) {
            registerBoughtSubscription({
              gateway_response,
              selectedSub: null,
            });
          }
        } else {
          gateway_response = purchase;
          registerBoughtSubscription({
            gateway_response,
            selectedSub: null,
          });

          // If not consumable
          acknowledgePurchaseAndroid(purchase.purchaseToken);
        }
      }
    }
  };
  // 4TH STEP VALIDATE RECEIPT FOR IOS ONLY
  // doing receipt validation
  const validateReceipt = async receipt => {
    const response = await validateReceiptIos(
      {
        'receipt-data': receipt,
        password: constants.APP_SPECIFIC_SHARED_SECRET,
      },
      false,
    ); //true for debug and false for live. True indicates its sandbox environment
    // so it request to sandbox and false for live environment

    const {status} = response;

    if (status === 0 && response.latest_receipt_info.length) {
      return response.latest_receipt_info.sort(
        (a, b) => b.expires_date_ms - a.expires_date_ms,
      )[0];
    } else {
      return null;
    }
  };

  const registerBoughtSubscription = ({gateway_response, selectedSub}) => {
    dispatch(
      request(
        apis.buySubscription,
        apis.serviceTypes.POST,
        {
          subscription_package_id:
            SKUS_ID_BACKEND[
              IS_IOS ? gateway_response.product_id : gateway_response.productId
            ],
          ...(selectedSub && {gateway_request: JSON.stringify(selectedSub)}),
          gateway_response: JSON.stringify(gateway_response),
          device_type: IS_IOS ? 'ios' : 'android',
        },
        null,
        false,
        false,
        res => {
          if (res.is_subscribe !== user.is_subscribe) {
            const clonedUser = _.cloneDeep(user);
            clonedUser.is_subscribe = res.is_subscribe;
            dispatch(generalSaveAction(USER.SUCCESS, clonedUser));
          }
        },
        err => {
          if (err?.data?.code == 400)
            dispatch(
              generalSaveAction(USER.SUCCESS, {
                ..._.cloneDeep(user),
                isDifferentAssociation: true,
              }),
            );
        },
      ),
    );
  };
};

export default useSubscriptionValidation;
