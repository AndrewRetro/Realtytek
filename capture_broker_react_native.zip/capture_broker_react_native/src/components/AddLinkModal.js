import React, {forwardRef, useImperativeHandle, useRef} from 'react';
import {View, SafeAreaView} from 'react-native';

import {
  ButtonView,
  Modal,
  FormHandlerUpdated,
  MaterialTextField,
} from '@reuseableComponents';

import {AppStyles, Colors, Metrics} from '@theme';
import {BigBtn} from '@components';

export default forwardRef(({onSave}, ref) => {
  const formHandlerRef = useRef();
  const modalRef = useRef();

  useImperativeHandle(ref, () => ({show, hide}));

  const show = () => {
    modalRef.current.setModalVisibility(true);
  };
  const hide = () => modalRef.current.setModalVisibility(false);
  const onSubmit = () => {
    const data = formHandlerRef.current.onSubmitForm();
    if (data) {
      data && onSave(data);
      hide();
    }
  };

  return (
    <Modal ref={modalRef}>
      <ButtonView
        onPress={hide}
        style={{
          alignItems: 'center',
          height: '100%',
          backgroundColor: 'rgba(0,0,0,0.5)',
        }}>
        <SafeAreaView>
          <ButtonView
            disableRipple
            onPress={() => {}}
            style={{marginTop: Metrics.widthRatio(60)}}>
            <View
              style={{
                backgroundColor: Colors.primary.palegrey,
                width: Metrics.screenWidth - Metrics.doubleBaseMargin,
                marginHorizontal: Metrics.baseMargin,
                padding: Metrics.baseMargin,
                borderRadius: Metrics.widthRatio(4),
              }}>
              <FormHandlerUpdated ref={formHandlerRef}>
                {(refCollector, onSubmitEditing) => {
                  const {text, website, focusByRefCollectorKey} =
                    FormHandlerUpdated.INPUTS(refCollector, onSubmitEditing);
                  return (
                    <>
                      <MaterialTextField
                        {...text({
                          identifier: 'title',
                          label: 'Title',
                          placeholder: 'Enter title',
                          error: 'Title is required',
                        })}
                        autoFocus
                      />

                      <MaterialTextField
                        {...website({
                          identifier: 'link',
                          label: 'Link',
                          placeholder: 'Paste link',
                          error: 'Enter a valid url',
                        })}
                      />
                    </>
                  );
                }}
              </FormHandlerUpdated>

              <View
                style={{
                  flexx: 1,
                  ...AppStyles.centerAligned,
                  marginTop: Metrics.doubleBaseMargin,
                }}>
                <BigBtn
                  title="Save"
                  style={{width: '100%'}}
                  onPress={onSubmit}
                />
              </View>
            </View>
          </ButtonView>
        </SafeAreaView>
      </ButtonView>
    </Modal>
  );
});

const styles = {
  txtTitle: {
    ...AppStyles.gbRe(14, Colors.primary.darkslateblue),
  },
  txtLink: {
    ...AppStyles.gbRe(14, Colors.primary.darkslateblue),
    marginTop: Metrics.baseMargin,
  },
};
