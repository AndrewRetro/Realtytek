import React, {useMemo} from 'react';
import {Text, StyleSheet} from 'react-native';

import {Colors, Fonts, Metrics} from '../theme';
import {ButtonView} from '../reuseableComponents';

export default ({
  title,
  bgColor,
  txtColor,
  onPress,
  useMargin,
  margin,
  dashed,
  borderColor,
  useSmall,
  style,
}) => {
  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          borderColor,
          width: '100%',
          borderRadius: 5,
          alignItems: 'center',
          justifyContent: 'center',
          height: Metrics.heightRatio(useSmall ? 42 : 52),
          minHeight: 40,
          borderStyle: dashed ? 'dashed' : 'solid',
          borderWidth: dashed ? 1 : 0,
          backgroundColor: bgColor || Colors.primary.clearblue,
          marginTop: useMargin ? margin || Metrics.xDoubleBaseMargin : 0,
        },
        txt: {
          ...Fonts.font({
            size: 16,
            type: dashed ? Fonts.Type.Regular : Fonts.Type.SemiBold,
            color: txtColor || Colors.primary.white,
          }),
          letterSpacing: 0.8,
        },
      }),
    [],
  );

  return (
    <ButtonView onPress={onPress} style={[styles.container, style]}>
      <Text style={styles.txt}>{title}</Text>
    </ButtonView>
  );
};
