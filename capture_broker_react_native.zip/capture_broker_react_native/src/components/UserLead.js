import React from 'react';
import {View, Text, Image} from 'react-native';

import {ButtonView, ImageHandlerUpdated} from '../reuseableComponents';

import {Metrics, Colors, Fonts, Images, AppStyles} from '../theme';
import {navigate} from '../services/NavigationService';
import utility from '@utils';

export default ({data, style}) => {
  const {name, image_url, mobile_no, email} = data;

  return (
    <ButtonView
      onPress={() =>
        navigate('CustomerStack', {screen: 'Lead', params: {lead: data}})
      }
      style={[stylesCards.container, style]}>
      <View style={stylesCards.wrapper}>
        <ImageHandlerUpdated
          style={stylesCards.img}
          source={{uri: image_url}}
          isProfileImage
          resizeMode="cover"
        />
        <Text style={stylesCards.nameTxt}>{name}</Text>
      </View>

      <View style={stylesCards.wrapper}>
        <Contact
          ic={Images.icChat}
          bgColor={Colors.primary.clearblue}
          isMarginRight
          onPress={utility.chat(mobile_no)}
        />
        <Contact
          ic={Images.icCall}
          bgColor={Colors.primary.clearblue}
          isMarginRight
          onPress={utility.call(mobile_no)}
        />
        <Contact
          ic={Images.icEmail}
          bgColor={Colors.primary.darkslateblue}
          onPress={utility.email(email)}
        />
      </View>
    </ButtonView>
  );
};

const Contact = ({ic, bgColor, isMarginRight, onPress}) => (
  <ButtonView
    style={{
      ...stylesCards.containerContact,
      backgroundColor: bgColor,
      ...(isMarginRight && {marginRight: Metrics.smallMargin}),
    }}
    onPress={onPress}>
    <Image source={ic} style={stylesCards.icContact} />
  </ButtonView>
);

const stylesCards = {
  container: {
    borderRadius: 5,
    alignItems: 'center',
    flexDirection: 'row',
    padding: Metrics.smallMargin,
    marginBottom: Metrics.baseMargin,
    justifyContent: 'space-between',
    marginHorizontal: Metrics.baseMargin,
    backgroundColor: Colors.primary.white,

    shadowColor: 'rgba(0, 0, 0, 0.04)',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowRadius: 6,
    shadowOpacity: 1,

    elevation: 1,
  },
  emailWrapper: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.primary.darkslateblue,
  },
  wrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  img: {
    height: Metrics.widthRatio(44),
    width: Metrics.widthRatio(44),
    borderRadius: Metrics.widthRatio(22),
  },
  nameTxt: {
    ...Fonts.font({size: 16, color: Colors.primary.slate}),
    marginLeft: Metrics.baseMargin,
  },
  containerContact: {
    width: Metrics.widthRatio(32),
    height: Metrics.widthRatio(32),
    borderRadius: Metrics.widthRatio(16),
    ...AppStyles.centerAligned,
  },
  icContact: {
    width: Metrics.widthRatio(18),
    height: Metrics.widthRatio(18),
    tintColor: Colors.primary.white,
    resizeMode: 'contain',
  },
};
