import React, {useMemo} from 'react';
import {View, Text, StyleSheet, Image} from 'react-native';

import {Metrics, Colors, Fonts, Images} from '../theme';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {ButtonView, ImageHandler} from '../reuseableComponents';

export default function ({
  onBack,
  title,
  rightTxt,
  onRightPress,
  useShadows,
  useBorderLess,
  rightImg,
}) {
  const {top} = useSafeAreaInsets();
  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          minHeight: 50,
          paddingTop: top,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: useShadows ? Metrics.smallMargin : 0,
          backgroundColor: Colors.primary.white,

          shadowColor: '#000',
          shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.25,
          shadowRadius: 3.84,

          elevation: 5,
        },
        backBtn: {
          zIndex: 1,
          minHeight: 50,
          justifyContent: 'center',
          paddingHorizontal: Metrics.baseMargin,
        },
        title: {
          ...Fonts.font({
            size: 16,
            color: Colors.primary.darkslateblue,
          }),
          left: 0,
          right: 0,
          textAlign: 'center',
          alignSelf: 'center',
          position: 'absolute',
          bottom: 15,
        },
        rightBtn: {
          borderWidth: 1,
          borderRadius: 4,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          width: Metrics.widthRatio(80),
          height: Metrics.heightRatio(30),
          marginHorizontal: Metrics.baseMargin,
          borderColor: Colors.primary.darkslateblue,
        },
        rightTxtStyle: {
          ...Fonts.font({
            size: 13,
            color: Colors.primary.darkslateblue,
          }),
        },
      }),
    [top],
  );

  return (
    <View style={styles.container}>
      <ButtonView onPress={onBack} style={styles.backBtn}>
        <ImageHandler source={Images.icBackArrow} />
      </ButtonView>
      <Text style={styles.title}>{title}</Text>
      {rightTxt ? (
        <ButtonView
          style={[styles.rightBtn, useBorderLess && {borderWidth: 0}]}
          onPress={onRightPress}>
          {useBorderLess && (
            <Image
              source={rightImg ? rightImg : Images.icDownload}
              style={{marginRight: 4}}
            />
          )}
          <Text
            style={[
              styles.rightTxtStyle,
              useBorderLess && {color: Colors.primary.clearblue, marginLeft: 4},
            ]}>
            {rightTxt}
          </Text>
        </ButtonView>
      ) : null}
    </View>
  );
}
