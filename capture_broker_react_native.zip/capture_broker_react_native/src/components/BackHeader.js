import React from 'react';
import {View, Text, StyleSheet} from 'react-native';

import {AppStyles, Colors, Fonts, Images, Metrics} from '../theme';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {
  ButtonView,
  ImageHandler,
  ImageHandlerUpdated,
} from '../reuseableComponents';
import {push, toggleDrawer} from '@nav';
import {useSelector} from 'react-redux';

export default ({
  onBack,
  useDrawer,
  user,
  onSearch,
  useNotification,
  title,
}) => {
  const {top} = useSafeAreaInsets();

  return (
    <View style={[styles.container, {marginTop: top}]}>
      <View style={styles.leftHeaderWrapper}>
        {onBack && (
          <ButtonView onPress={onBack} style={styles.headerLeft}>
            <ImageHandler source={Images.icBackArrow} />
          </ButtonView>
        )}
        {useDrawer && (
          <ButtonView onPress={toggleDrawer} style={styles.headerLeft}>
            <ImageHandler source={Images.icDrawer} />
          </ButtonView>
        )}
        {user && (
          <>
            <ImageHandlerUpdated
              source={
                user.image_url ? {uri: user.image_url} : Images.person_black
              }
              style={AppStyles.roundImg(40)}
              isZoomViewerEnabled
            />
            <Text style={styles.userNameTxt}>
              {title || `Hi, ${user.name}`}
            </Text>
          </>
        )}
      </View>

      <View style={styles.headerRightWrapper}>
        {onSearch && (
          <ButtonView style={styles.headerLeft} onPress={onSearch}>
            <ImageHandler source={Images.icSearch} />
          </ButtonView>
        )}
        {useNotification && <Notification />}
      </View>
    </View>
  );
};

const Notification = () => {
  const count = useSelector(({badgeCount}) => badgeCount.count);

  const onNotification = () => push('Notification');

  const Dot = () => <View style={styles.dot} />;

  return (
    <ButtonView style={styles.containerIcNotification} onPress={onNotification}>
      <ImageHandler source={Images.icNotificaiton} />
      {+count > 0 && <Dot />}
    </ButtonView>
  );
};

const styles = StyleSheet.create({
  container: {
    minHeight: 50,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headerLeft: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingLeft: Metrics.baseMargin,
    paddingRight: Metrics.smallMargin,
  },
  leftHeaderWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  userNameTxt: {
    ...Fonts.font({
      type: Fonts.Type.SemiBold,
      size: 22,
      color: Colors.primary.darkslateblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
  headerRightWrapper: {
    flexDirection: 'row',
  },
  containerIcNotification: {
    alignItems: 'center',
    justifyContent: 'center',
    width: Metrics.widthRatio(40),
    height: Metrics.widthRatio(40),
    paddingRight: Metrics.baseMargin,
  },
  dot: {
    width: Metrics.widthRatio(12),
    height: Metrics.widthRatio(12),
    borderRadius: Metrics.widthRatio(6),
    backgroundColor: Colors.primary.greenapple,
    position: 'absolute',
    top: Metrics.widthRatio(8),
    left: Metrics.widthRatio(11),
    borderWidth: 1,
    borderColor: 'white',
  },
});
