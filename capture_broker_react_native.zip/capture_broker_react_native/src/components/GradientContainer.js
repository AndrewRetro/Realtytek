import React from 'react';
import {StyleSheet} from 'react-native';

import LinearGradient from 'react-native-linear-gradient';
import {Colors} from '../theme';

export default ({children, style}) => {
  return (
    <LinearGradient
      style={[styles.container, style]}
      colors={[Colors.primary.white, Colors.primary.palegrey]}>
      {children}
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
