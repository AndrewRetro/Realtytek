import React from 'react';
import {View, StyleSheet, Text, Image} from 'react-native';
import {Images, Metrics, Colors, Fonts} from '@theme';
import moment from 'moment';
import constant from '@constants';

export default ({appointment, agentName}) => {
  const {property, appointment_time} = appointment;
  const {title, address} = property;

  return (
    <View style={styles.cardContainer}>
      <View
        style={[
          styles.dot,
          {
            marginTop: 4,
            alignSelf: 'baseline',
            marginRight: Metrics.baseMargin,
          },
        ]}
      />
      <View>
        <Text style={styles.cardHeading}>{agentName}</Text>
        <Text style={styles.cardDesc}>{title}</Text>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginTop: Metrics.smallMargin,
          }}>
          <Image
            style={{marginRight: Metrics.smallMargin}}
            source={Images.icWatchLater24Px}
          />
          <Text style={[styles.cardDesc, {marginTop: 0}]}>
            {moment(appointment_time, constant.TIME_FORMAT_DB).format(
              constant.NOON_FORMAT,
            )}
          </Text>
        </View>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginTop: Metrics.smallMargin,
          }}>
          <Image
            style={{marginRight: Metrics.smallMargin}}
            source={Images.icAddress}
          />
          <Text style={[styles.cardDesc, {marginTop: 0, flex: 1}]}>
            {address}
          </Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  cardContainer: {
    borderRadius: 4,
    flexDirection: 'row',
    padding: Metrics.baseMargin,
    shadowColor: 'rgba(0, 0, 0, 0.04)',
    marginVertical: Metrics.smallMargin,
    marginHorizontal: Metrics.baseMargin,
    backgroundColor: Colors.primary.white,
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowRadius: 10,
    shadowOpacity: 1,
    elevation: 3,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 8,
    marginBottom: 4,
    alignSelf: 'center',
    backgroundColor: Colors.primary.clearblue,
  },
  cardHeading: {
    ...Fonts.font({
      size: 16,
      color: Colors.primary.darkslateblue,
    }),
  },
  cardDesc: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: 8,
  },
});
