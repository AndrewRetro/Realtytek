import React from 'react';

import {FloatingBtn, UserLead} from '../components';
import {FlatListHandler} from '../reuseableComponents';
import {navigate, push} from '../services/NavigationService';
import {EventBusSingleton} from 'light-event-bus';

// redux imports
import {useDispatch, useSelector} from 'react-redux';
import apis from '@apis';
import {request} from '@serviceAction';
import {LEADS} from '@actionTypes';

export default function (props) {
  const dispatch = useDispatch();
  const {leads, user} = useSelector(({leads, user}) => ({leads, user}));
  React.useEffect(() => {
    fetchLeads();
  }, []);

  const fetchLeads = (isConcat = false, page = 1) => {
    dispatch(
      request(
        apis.addLead,
        apis.serviceTypes.GET,
        {page, limit: 10},
        LEADS,
        false,
        isConcat,
        null,
        null,
        LEADS,
      ),
    );
  };

  const onAddLead = () => {
    const {is_subscribe, agent_agrement} = user.data;
    if (is_subscribe) {
      // conditions for checking agent agreement
      if (!!agent_agrement) {
        navigate('CustomerStack', {screen: 'AddLead'});
      } else {
        EventBusSingleton.publish('showAddAgreementModal');
      }
    } else {
      EventBusSingleton.publish('popup', {
        val: 'subscribe',
        onAccept: () => push('Subscription'),
      });
    }
  };

  const renderItem = ({item}) => <UserLead data={item} />;

  return (
    <>
      <FlatListHandler
        fetchRequest={fetchLeads}
        renderItem={renderItem}
        data={leads.data}
        isFetching={leads.isFetching}
        meta={leads.meta}
      />
      <FloatingBtn onPress={onAddLead} />
    </>
  );
}
