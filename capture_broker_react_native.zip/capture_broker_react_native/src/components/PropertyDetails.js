import React from 'react';
import {View, Text, Image} from 'react-native';

import {Rating} from '@components';

import {Metrics, Fonts, Colors, Images} from '@theme';
import utility from '@utils';

const PropertyDetails = ({property}) => {
  const {
    title,
    address,
    asking_price,
    mls_detail,
    rating,
    review,
    property_type,
    city,
    state,
    zipcode,
  } = property;

  const onMls = () => utility.openLink(mls_detail);

  return (
    <View style={styles.container}>
      <Tag
        {...{
          t1: 'Community/Building',
          d1: title,
          t2: 'Price',
          d2: asking_price,
        }}
      />

      <Tag {...{t1: 'Address', d1: address, t2: 'City', d2: city}} />
      <Tag {...{t1: 'State', d1: state, t2: 'Zipcode', d2: zipcode}} />

      <Tag {...{t1: 'Type', d1: property_type, t2: 'Rating', rating}} />

      <Text style={styles.tileTxt2}>MLS Details</Text>
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          marginTop: 8,
        }}>
        <Image source={Images.icLink} />
        <Text onPress={onMls} style={styles.linkTxt}>
          {mls_detail}
        </Text>
      </View>

      {!!review && (
        <View>
          <Text style={styles.tileTxt2}>Comments</Text>
          <Text style={styles.tileDesc2}>{review}</Text>
        </View>
      )}
    </View>
  );
};

const Tag = ({t1, d1, t2, d2, rating}) => (
  <View style={{flexDirection: 'row'}}>
    <View style={{flex: 0.5}}>
      <Text style={styles.tileTxt2}>{t1}</Text>
      <Text style={styles.tileDesc2}>{d1}</Text>
    </View>

    <View style={{flex: 0.5}}>
      <Text style={styles.tileTxt2}>{t2}</Text>
      {!!d2 && <Text style={styles.tileDesc2}>{d2}</Text>}
      {rating !== 'null' && rating !== undefined && (
        <Rating useBig style={styles.tileDesc2} rating={rating} />
      )}
    </View>
  </View>
);

export default PropertyDetails;

const styles = {
  container: {flex: 1, marginTop: Metrics.baseMargin},
  txtTitle: {
    ...Fonts.font({
      size: 12,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
  },

  tileTxt2: {
    ...Fonts.font({
      size: 12,
      type: Fonts.Type.SemiBold,
      color: Colors.primary.darkslateblue,
    }),
    marginTop: Metrics.doubleBaseMargin,
  },
  tileDesc2: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginTop: 8,
  },
  linkTxt: {
    ...Fonts.font({
      size: 14,
      type: Fonts.Type.Italic,
      color: Colors.primary.clearblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
};
