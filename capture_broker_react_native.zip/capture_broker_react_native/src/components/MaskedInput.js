import React from 'react';
import {
  View,
  Text,
  Image,
  TextInput,
  ActivityIndicator,
  PermissionsAndroid,
} from 'react-native';
import PropTypes from 'prop-types';
import {selectContactPhone} from 'react-native-select-contact';

import {ButtonView} from '@reuseableComponents';

import {Metrics, Colors, AppStyles} from '@theme';
import utility from '@utils';

export default class MaskedInput extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      val: this.props?.value?.split('-')[1] ?? '',
      isErr: false,
      err: '',
      isFocused: false,
    };
  }

  requestContactPermission = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.READ_CONTACTS,
        {
          title: 'Allow Access Contact?',
          message: 'allow this app to read contact information',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        },
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        console.log('granted');
        this.onShowContacts();
      } else {
        console.log('denied');
      }
    } catch (err) {
      console.warn(err);
    }
  };

  onShowContacts = () =>
    selectContactPhone().then(e => {
      // \s in regex matches spaces, tabs and line breaks
      // [] makes character class whatever specified inside will be replaced
      const purgedPhoneNumber = e.selectedPhone.number.replace(
        /\s|-|[()]/g,
        '',
      );

      this.setState({val: purgedPhoneNumber.replace(/\+1/, '')});
    });

  getValue = () => (this.state.val.length ? `+1-${this.state.val}` : '');
  setError = (isErr, err) => this.setState({isErr, err});

  setFocus = () => this.input.focus();

  onFocus = () => this.setState({isFocused: true});
  onBlur = () => {
    this.setState({isFocused: false});
    this.props.onBlur && this.props.onBlur();
  };

  onChangeText = val => this.setState({val, isErr: false});

  onRightPress = () => {
    utility.isPlatformAndroid()
      ? this.requestContactPermission()
      : this.onShowContacts();
    this.props.onRightPress?.();
  };

  renderRightIcon = () => {
    const {rightIcon, isShowLoader} = this.props;

    if (rightIcon || isShowLoader)
      return (
        <ButtonView
          style={{
            width: 20,
            alignItems: 'center',
            justifyContent: 'center',
            marginRight: Metrics.baseMargin,
          }}
          onPress={this.onRightPress}>
          {isShowLoader ? (
            <ActivityIndicator size="small" />
          ) : (
            <Image
              style={{
                width: Metrics.widthRatio(25),
                height: Metrics.widthRatio(25),
                resizeMode: 'contain',
              }}
              source={this.props.rightIcon}
            />
          )}
        </ButtonView>
      );
  };

  render() {
    const {onFocus, onBlur} = this;
    const {isFocused, val, err, isErr} = this.state;
    const {label, onSubmitEditing, isLabeledField, leftIcon} = this.props;
    const backgroundColor = isFocused
      ? `${Colors.primary.brightlightblue}26`
      : isLabeledField
      ? Colors.primary.white
      : `${Colors.primary.bluegrey}0D`;

    const borderColor = isFocused
      ? Colors.primary.brightlightblue
      : Colors.primary.white;

    return (
      <View style={styles.container}>
        {isLabeledField && <Text style={styles.label}>{label}</Text>}

        <View style={[styles.row, {backgroundColor, borderColor}]}>
          {leftIcon && (
            <Image
              source={leftIcon}
              style={{
                marginLeft: Metrics.baseMargin,
                tintColor: isFocused
                  ? Colors.primary.darkslateblue
                  : Colors.primary.bluegrey,
              }}
            />
          )}

          <Text
            style={{
              paddingLeft: Metrics.baseMargin,
              color:
                isFocused || val.length
                  ? Colors.primary.darkslateblue
                  : Colors.primary.lightgreyblue,
            }}>
            +1-
          </Text>
          <TextInput
            ref={ref => (this.input = ref)}
            onChangeText={this.onChangeText}
            placeholder="0000000000"
            maxLength={10}
            placeholderTextColor={Colors.primary.lightgreyblue}
            style={{
              ...(utility.isPlatformAndroid() && {
                paddingLeft: Metrics.widthRatio(1.3),
              }),
              paddingVertical: Metrics.baseMargin,
              paddingRight: Metrics.baseMargin,
              flex: 1,
              ...AppStyles.gbRe(14, Colors.primary.darkslateblue),
            }}
            onFocus={onFocus}
            onBlur={onBlur}
            onSubmitEditing={onSubmitEditing}
            returnKeyType="next"
            blurOnSubmit={false}
            keyboardType="phone-pad"
            value={val}
          />
          {this.renderRightIcon()}
        </View>
        {isErr && (
          <Text
            style={{
              ...AppStyles.gbRe(10, Colors.primary.vermillion),
              marginTop: Metrics.smallMargin,
            }}>
            {err}
          </Text>
        )}
      </View>
    );
  }
  componentDidUpdate(prevProps) {
    if (this.props.value !== prevProps.value) {
      this.setState({val: this.props.value.split('-')[1] ?? ''});
    }
    if (this.props.isError !== prevProps.isError) {
      this.setState({isError: this.props.isError});
    }
  }
}

MaskedInput.propTypes = {
  label: PropTypes.string,
  onSubmitEditing: PropTypes.func,
  isLabeledField: PropTypes.bool,
  leftIcon: PropTypes.number,
};

MaskedInput.defaultProps = {
  label: 'label here',
  onSubmitEditing: () => {},
  isLabeledField: true,
  leftIcon: undefined,
};

const styles = {
  container: {marginTop: Metrics.widthRatio(24)},
  label: {
    ...AppStyles.gbRe(14, Colors.primary.darkslateblue),
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: Metrics.smallMargin,
    borderRadius: Metrics.widthRatio(6),
    borderWidth: 1,
  },
};
