import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import {EventBusSingleton} from 'light-event-bus';

import {Colors, Fonts, Metrics} from '../theme';
import {ImageHandlerUpdated, ButtonView} from '../reuseableComponents';
import SmallBtn from './SmallBtn';
import {AppointmentStatus} from '@constants';
import {navigate} from '@nav';

import apis from '@apis';
import utils from '@utils';
import {useDispatch} from 'react-redux';
import {request} from '@serviceAction';
import {generalSaveAction} from '@serviceAction';
import {APPOINTMENTS_CONFIRMED, APPOINTMENTS_PENDING} from '@actionTypes';
import {APPOINTMENTS_REJECTED} from '@actionTypes';

export default function ({item}) {
  const dispatch = useDispatch();

  const onReject = () => {
    EventBusSingleton.publish('popup', {
      val: 'reject',
      onAccept: () => onAccept(AppointmentStatus.REJECTED),
    });
  };

  const {property, appointment_date, appointment_time, status, slug, client} =
    item;
  const {asking_price, image_url} = property;

  const onAccept = (appointmentStatus = AppointmentStatus.ACCEPT) =>
    dispatch(
      request(
        `${apis.appointments}/${slug}`,
        apis.serviceTypes.POST,
        {
          _method: 'put',
          status: appointmentStatus,
        },
        null,
        true,
        false,
        appointment => {
          dispatch(
            generalSaveAction(APPOINTMENTS_PENDING.DELETE, {
              ...appointment,
              isDeleteObj: true,
            }),
          );

          appointmentStatus == AppointmentStatus.ACCEPT
            ? setTimeout(() => {
                dispatch(
                  generalSaveAction(APPOINTMENTS_CONFIRMED.ADD, {
                    ...appointment,
                    isAddToZero: true,
                  }),
                );
              }, 500)
            : setTimeout(() => {
                dispatch(
                  generalSaveAction(APPOINTMENTS_REJECTED.ADD, {
                    ...appointment,
                    isAddToZero: true,
                  }),
                );
              }, 500);
        },
      ),
    );

  const onAppointmentDetail = () =>
    navigate('AppointmentDetails', {property: item});

  return (
    <ButtonView onPress={onAppointmentDetail} style={styles.container}>
      <ImageHandlerUpdated style={styles.img} source={{uri: image_url}} />
      <View style={styles.amountWrapper}>
        <Text style={styles.amountTxt}>
          {utils.formateCurrency(asking_price)}
        </Text>
      </View>

      <View style={styles.addressWrapper}>
        <Text style={styles.heading}>Client:</Text>
        <Text style={styles.addressTxt}>{client?.name}</Text>
      </View>
      <View style={{flexDirection: 'row'}}>
        <View style={[styles.addressWrapper, {flex: 0.5, marginVertical: 0}]}>
          <Text style={styles.heading}>Date:</Text>
          <Text style={styles.addressTxt}>{appointment_date}</Text>
        </View>
        <View style={[styles.addressWrapper, {flex: 0.5, marginVertical: 0}]}>
          <Text style={styles.heading}>Time:</Text>
          <Text style={styles.addressTxt}>
            {utils.formattedDisplayTime(appointment_time)}
          </Text>
        </View>
      </View>
      {status === AppointmentStatus.PENDING && (
        <View style={styles.btnContainer}>
          <SmallBtn
            style={{width: '48%'}}
            bgColor={Colors.primary.watermelon}
            title="Reject"
            onPress={onReject}
          />
          <SmallBtn
            style={{width: '48%'}}
            bgColor={Colors.primary.clearblue}
            title="Accept"
            onPress={onAccept}
          />
        </View>
      )}
    </ButtonView>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 4,
    marginHorizontal: Metrics.baseMargin,
    padding: Metrics.widthRatio(6),
    paddingBottom: Metrics.baseMargin,
    backgroundColor: Colors.primary.white,
    shadowColor: 'rgba(0, 0, 0, 0.04)',
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowRadius: 10,
    shadowOpacity: 1,

    elevation: 2,
  },
  img: {
    width: '100%',
    height: Metrics.heightRatio(130),
    borderRadius: Metrics.widthRatio(4),
  },
  addressWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: Metrics.baseMargin,
    marginLeft: Metrics.smallMargin,
  },
  addressTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkslateblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
  nameTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkslateblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
  amountWrapper: {
    left: Metrics.widthRatio(10),
    borderRadius: Metrics.widthRatio(6),
    position: 'absolute',
    backgroundColor: Colors.primary.white,
    padding: Metrics.heightRatio(5),
    top: Metrics.heightRatio(109),
  },
  amountTxt: {
    ...Fonts.font({
      type: Fonts.Type.SemiBold,
      size: 12,
      color: Colors.primary.clearblue,
    }),
  },
  heading: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.lightgreyblue,
    }),
  },
  btnContainer: {
    flexDirection: 'row',
    marginTop: Metrics.baseMargin,
    justifyContent: 'space-between',
  },
});
