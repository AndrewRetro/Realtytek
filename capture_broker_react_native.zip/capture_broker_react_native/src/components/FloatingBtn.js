import React from 'react';
import {View, Text, StyleSheet} from 'react-native';

import {Colors, Metrics, Images} from '../theme';
import {ButtonView, ImageHandler} from '../reuseableComponents';

export default function ({onPress}) {
  return (
    <ButtonView onPress={onPress} style={styles.container}>
      <ImageHandler source={Images.icAddMore} />
    </ButtonView>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    right: Metrics.baseMargin,
    bottom: Metrics.doubleBaseMargin,

    shadowColor: 'rgba(35, 130, 250, 0.16)',
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowRadius: 10,
    shadowOpacity: 1,

    elevation: 3,
  },
});
