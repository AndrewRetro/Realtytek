import React, {useRef, useState, useEffect} from 'react';
import {View, Text} from 'react-native';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import _ from 'lodash';

import {MaterialTextField, BottomActionSheet} from '@reuseableComponents';
import {Metrics, Colors, Fonts, Images} from '@theme';
import {useDispatch} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';
import moment from 'moment';
import constants from '@constants';

export default props => {
  const {property, cbSetContractStatus} = props;
  const dispatch = useDispatch();

  const contractStatusBottomSheetRef = useRef();
  const commentFieldRef = useRef();

  const [state, setState] = useState({
    isShowDatePicker: false,
    key: null,
    contract_offer: {val: null, isUpdating: false, isError: false},
    contract_countered: {val: null, isUpdating: false, isError: false},
    contract_accepted: {val: null, isUpdating: false, isError: false},
    offer_decline: {val: null, isUpdating: false, isError: false},
    contract_executed: {val: null, isUpdating: false, isError: false},
    offer_decline: {val: null, isUpdating: false, isError: false},
    inspection: {val: null, isUpdating: false, isError: false},
    appraisal: {val: null, isUpdating: false, isError: false},
    final_walk_thru: {val: null, isUpdating: false, isError: false},
    sattlement_date: {val: null, isUpdating: false, isError: false},
    add_comment: {val: '', isUpdating: false, isError: false},
    contract_status_updated_date: {val: null},
    contract_status: {val: null, isUpdating: false, isError: false},
  });

  useEffect(() => {
    fetchContractStatus();
    if (props.contractStatus) {
      plotContractStatusIntoState(props.contractStatus);
    }
  }, []);

  const fetchContractStatus = () => {
    dispatch(
      request(
        apis.getContractStatus,
        apis.serviceTypes.GET,
        {property_id: property.id},
        null,
        props.contractStatus ? false : true, // if got contract status from parent don't show loader
        false,
        plotContractStatusIntoState,
      ),
    );
  };

  const plotContractStatusIntoState = contractStatus => {
    setState(s => {
      let state = _.cloneDeep(s);
      Object.keys(state).map(key => {
        if (contractStatus[key]) {
          state[key] = {
            val: contractStatus[key],
            isUpdating: false,
            isError: false,
          };
        }
      });
      return state;
    });
    cbSetContractStatus(contractStatus);
  };

  const onUpdateContract = (val, key) => {
    const payload = {};
    payload[key] = val;
    payload['property_id'] = property.id;
    payload['contract_status'] = state.contract_status.val
      ? state.contract_status.val
      : constants.CONTRACT_STATUS[1];
    payload['contract_status_updated_date'] = moment(new Date()).format(
      constants.DB_DATE_FORMAT,
    );

    dispatch(
      request(
        apis.updateContractStatus,
        apis.serviceTypes.POST,
        payload,
        null,
        false,
        false,
        () => {
          setState(s => {
            const state = _.cloneDeep(s);
            state[key].isUpdating = false;
            return state;
          });
        },
        () => {
          setState(s => {
            const state = _.cloneDeep(s);
            state[key].isError = true;
            state[key].isUpdating = false;
            return state;
          });
        },
      ),
    );
  };

  const onDatePicked = date => {
    const formattedDate = moment(date).format(constants.DB_DATE_FORMAT);
    setState(s => {
      const state = _.cloneDeep(s);
      state[state.key].val = formattedDate;
      state[state.key].isUpdating = true;
      state[state.key].isError = false;
      onUpdateContract(formattedDate, state.key);
      return {
        ...state,
        isShowDatePicker: false,
        key: null,
      };
    });
  };

  const onRight = key => () =>
    setState(s => ({...s, key, isShowDatePicker: true}));

  const onShowContractStatusSheet = () =>
    contractStatusBottomSheetRef.current.showActionSheet();

  const cbOnContractStatusSelected = index =>
    index &&
    setState(s => {
      onUpdateContract(constants.CONTRACT_STATUS[index], 'contract_status');
      return {
        ...s,
        contract_status: {
          val: constants.CONTRACT_STATUS[index],
          isUpdating: true,
        },
      };
    });

  const bottomSheetRef = ref => (contractStatusBottomSheetRef.current = ref);

  const onCommentBlur = () => {
    setState(s => {
      onUpdateContract(commentFieldRef.current.getValue(), 'add_comment');
      return {
        ...s,
        add_comment: {
          val: commentFieldRef.current.getValue(),
          isUpdating: true,
        },
      };
    });
  };

  return (
    <View style={styles.container}>
      <MaterialTextField
        value={state.contract_offer.val}
        label="Contract Offered"
        placeholder="Enter contract offered date"
        editable={false}
        rightIcon={Images.icCalendarField}
        onRightPress={onRight('contract_offer')}
        isShowLoader={state['contract_offer'].isUpdating}
        isError={state.contract_offer.isError}
        error="Failed to update. Pick again"
      />
      <MaterialTextField
        value={state.contract_countered.val}
        label="Contract Countered"
        placeholder="Enter countered date"
        editable={false}
        rightIcon={Images.icCalendarField}
        onRightPress={onRight('contract_countered')}
        isShowLoader={state['contract_countered'].isUpdating}
        isError={state.contract_countered.isError}
        error="Failed to update. Pick again"
      />
      <MaterialTextField
        value={state.contract_accepted.val}
        label="Contract Accepted"
        placeholder="Enter contract accepted date"
        editable={false}
        rightIcon={Images.icCalendarField}
        onRightPress={onRight('contract_accepted')}
        isShowLoader={state['contract_accepted'].isUpdating}
        isError={state.contract_accepted.isError}
        error="Failed to update. Pick again"
      />
      <MaterialTextField
        value={state.contract_executed.val}
        label="Contract Executed"
        placeholder="Enter contract executed date"
        editable={false}
        rightIcon={Images.icCalendarField}
        onRightPress={onRight('contract_executed')}
        isShowLoader={state['contract_executed'].isUpdating}
        isError={state.contract_executed.isError}
        error="Failed to update. Pick again"
      />
      <MaterialTextField
        value={state.offer_decline.val}
        label="Offer Decline"
        placeholder="Enter offere declined date"
        editable={false}
        rightIcon={Images.icCalendarField}
        onRightPress={onRight('offer_decline')}
        isShowLoader={state['offer_decline'].isUpdating}
        isError={state.offer_decline.isError}
        error="Failed to update. Pick again"
      />
      <MaterialTextField
        value={state.inspection.val}
        label="Inspection"
        placeholder="Enter inspection date"
        editable={false}
        rightIcon={Images.icCalendarField}
        onRightPress={onRight('inspection')}
        isShowLoader={state['inspection'].isUpdating}
        isError={state.inspection.isError}
        error="Failed to update. Pick again"
      />
      <MaterialTextField
        value={state.appraisal.val}
        label="Appraisal"
        placeholder="Enter appraisal date"
        editable={false}
        rightIcon={Images.icCalendarField}
        onRightPress={onRight('appraisal')}
        isShowLoader={state['appraisal'].isUpdating}
        isError={state.appraisal.isError}
        error="Failed to update. Pick again"
        isFocused
      />
      <MaterialTextField
        value={state.final_walk_thru.val}
        label="Final walk-thru"
        placeholder="Enter walk-thru date"
        editable={false}
        rightIcon={Images.icCalendarField}
        onRightPress={onRight('final_walk_thru')}
        isShowLoader={state['final_walk_thru'].isUpdating}
        isError={state.final_walk_thru.isError}
        error="Failed to update. Pick again"
      />
      <MaterialTextField
        value={state.sattlement_date.val}
        label="Settlement Date"
        placeholder="Enter settlement date"
        editable={false}
        rightIcon={Images.icCalendarField}
        onRightPress={onRight('sattlement_date')}
        isShowLoader={state['sattlement_date'].isUpdating}
        isError={state.sattlement_date.isError}
        error="Failed to update. Pick again"
      />
      <MaterialTextField
        ref={commentFieldRef}
        value={state.add_comment.val}
        multiline
        label="Add Comments"
        placeholder="Write your comments"
        onBlur={onCommentBlur}
        isShowLoader={state['add_comment'].isUpdating}
        isError={state.add_comment.isError}
        error="Failed to update. Write again"
      />
      <View style={styles.wrapperContractStatus}>
        <MaterialTextField
          value={state.contract_status.val}
          style={{width: '45%'}}
          label="Contract Status"
          placeholder="Active"
          editable={false}
          rightIcon={Images.icDropdown}
          onRightPress={onShowContractStatusSheet}
          isShowLoader={state['contract_status'].isUpdating}
          isError={state.contract_status.isError}
          error="Failed to update. Pick again"
        />

        {state.contract_status_updated_date.val && (
          <Text style={styles.txtStatusDate}>
            {state.contract_status_updated_date.val}
          </Text>
        )}
      </View>

      <DateTimePickerModal
        date={new Date()}
        isVisible={state.isShowDatePicker}
        minimumDate={new Date()}
        mode="date"
        onConfirm={onDatePicked}
        onCancel={() => setState(s => ({...s, isShowDatePicker: false}))}
      />

      <BottomActionSheet
        ref={bottomSheetRef}
        options={['Cancel', 'Yes', 'No']}
        cbOnPressActionSheet={cbOnContractStatusSelected}
      />
    </View>
  );
};

const styles = {
  container: {flex: 1},
  actionBtn: {
    marginVertical: Metrics.xDoubleBaseMargin,
    width: (Metrics.screenWidth - Metrics.xDoubleBaseMargin) / 2,
  },
  txtStatusDate: {
    flex: 1,
    marginTop: Metrics.widthRatio(53),
    textAlign: 'center',
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
  },
  wrapperContractStatus: {
    flexDirection: 'row',
    alignItems: 'center',
  },
};
