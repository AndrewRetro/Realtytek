import React, {useMemo} from 'react';
import {View, Text, StyleSheet, Image} from 'react-native';

import utility from '../utility';
import {SmallBtn} from '../components';
import {ImageHandlerUpdated, ButtonView} from '../reuseableComponents';
import {Images, Metrics, Colors, Fonts, AppStyles} from '../theme';
import moment from 'moment';
import constants from '@constants';

export default ({item, onPress, useFullWidth, isUnderContractCard}) => {
  const stylesCard = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
          borderRadius: 5,
          padding: Metrics.smallMargin,
          width: useFullWidth
            ? Metrics.screenWidth - 2 * Metrics.baseMargin
            : Metrics.screenWidth * 0.8,
          marginHorizontal: useFullWidth ? Metrics.baseMargin : 0,
          marginRight: useFullWidth ? 0 : Metrics.smallMargin,
          marginBottom: Metrics.baseMargin,
          backgroundColor:
            item?.status === 'Sold'
              ? Colors.primary.lightgrey
              : Colors.primary.white,

          shadowColor: '#000',
          shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.25,
          shadowRadius: 3.84,

          elevation: 5,
        },
        wrapper: {
          flexDirection: 'row',
          justifyContent: 'space-between',
        },
        personalDetails: {
          flex: 1,
          flexDirection: 'row',
        },
        nameWrapper: {
          flex: 1,
          marginVertical: 5,
          marginLeft: Metrics.smallMargin,
          justifyContent: 'space-between',
        },
        nameTxt: {
          flex: 1,
          ...Fonts.font({
            size: 16,
            color: Colors.primary.slate,
          }),
        },
        addressTxt: {
          ...Fonts.font({
            size: 12,
            color: Colors.primary.slate,
          }),
          lineHeight: 14,
          marginTop: Metrics.baseMargin,
        },
        amountTxt: {
          ...Fonts.font({
            size: 14,
            type: Fonts.Type.SemiBold,
            color: Colors.primary.clearblue,
          }),
        },
        subWrapper: {
          alignItems: 'center',
          marginTop: Metrics.smallMargin,
        },
        subHeader: {
          ...Fonts.font({
            size: 13,
            color: Colors.primary.verylightpink,
          }),
        },
        subtitle: {
          ...Fonts.font({
            size: 15,
            color: Colors.primary.slate,
          }),
          marginTop: 6,
        },
      }),
    [item?.id],
  );

  const {customer} = item;

  return (
    <ButtonView onPress={onPress} style={stylesCard.container}>
      <View style={stylesCard.personalDetails}>
        <ImageHandlerUpdated
          source={customer ? {uri: customer.image_url} : item.image_url}
          style={styles.img}
        />

        <View style={styles.containerInfo}>
          <View style={styles.wrapperNameAmount}>
            <Text
              style={stylesCard.nameTxt}
              numberOfLines={1}
              ellipsizeMode="tail">
              {customer ? customer.name : item.name}
            </Text>
            <Text style={stylesCard.amountTxt}>
              {utility.formateCurrency(item.price)}
            </Text>
          </View>

          <Text
            numberOfLines={2}
            style={stylesCard.addressTxt}
            ellipsizeMode="tail">
            {customer ? item.requirements : item.address}
          </Text>
        </View>
      </View>

      <View style={[stylesCard.wrapper, stylesCard.subWrapper]}>
        <View>
          <Text style={stylesCard.subHeader}>
            {isUnderContractCard ? 'Status' : 'Moving Date'}
          </Text>
          <Text style={stylesCard.subtitle}>
            {isUnderContractCard
              ? item.status
              : moment(item.move_date).format(constants.DISPLAY_DATE_FORMAT)}
          </Text>
        </View>

        <View style={stylesCard.wrapper}>
          <Contact
            ic={Images.icChat}
            bgColor={Colors.primary.clearblue}
            isMarginRight
            onPress={utility.chat(customer.mobile_no)}
          />
          <Contact
            ic={Images.icCall}
            bgColor={Colors.primary.clearblue}
            isMarginRight
            onPress={utility.call(customer.mobile_no)}
          />
          <Contact
            ic={Images.icEmail}
            bgColor={Colors.primary.darkslateblue}
            onPress={utility.email(customer.email)}
          />
        </View>
      </View>
    </ButtonView>
  );
};

const Contact = ({ic, bgColor, isMarginRight, onPress}) => (
  <ButtonView
    style={{
      ...styles.containerContact,
      backgroundColor: bgColor,
      ...(isMarginRight && {marginRight: Metrics.smallMargin}),
    }}
    onPress={onPress}>
    <Image source={ic} style={styles.icContact} />
  </ButtonView>
);

const styles = {
  img: {
    height: Metrics.widthRatio(64),
    width: Metrics.widthRatio(64),
    borderRadius: Metrics.widthRatio(4),
  },
  wrapperNameAmount: {flexDirection: 'row'},
  wrapperRequirements: {flexDirection: 'row', marginTop: Metrics.baseMargin},
  containerInfo: {flex: 1, marginLeft: Metrics.smallMargin},
  icLoc: {
    marginTop: 1,
    tintColor: Colors.primary.slate,
    marginRight: Metrics.smallMargin,
  },
  containerContact: {
    width: Metrics.widthRatio(32),
    height: Metrics.widthRatio(32),
    borderRadius: Metrics.widthRatio(16),
    ...AppStyles.centerAligned,
  },
  icContact: {
    width: Metrics.widthRatio(18),
    height: Metrics.widthRatio(18),
    tintColor: Colors.primary.white,
    resizeMode: 'contain',
  },
};
