import React from 'react';
import {View, Text, StyleSheet} from 'react-native';

import {ImageHandlerUpdated, ButtonView} from '../reuseableComponents';
import {Colors, Metrics, Fonts} from '../theme';
import utility from '../utility';

export default ({item, onPress}) => {
  return (
    <ButtonView onPress={onPress} style={styles.container}>
      <ImageHandlerUpdated style={styles.img} source={{uri: item.image_url}} />
      <Text numberOfLines={1} ellipsizeMode="tail" style={styles.addressTxt}>
        {item.address}
      </Text>
      <Text style={styles.tag}>Asking Price</Text>
      <Text style={styles.amountTxt}>
        {utility.formateCurrency(item.asking_price)}
      </Text>
    </ButtonView>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 5,
    padding: Metrics.smallMargin,
    width: Metrics.widthRatio(144) + Metrics.baseMargin,
    backgroundColor: Colors.primary.white,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 5,
    marginBottom: Metrics.baseMargin,
  },
  addressTxt: {
    ...Fonts.font({
      size: 13,
      color: Colors.primary.clearblue,
    }),
    fontWeight: '500',
    marginTop: Metrics.widthRatio(6),
  },
  tag: {
    ...Fonts.font({
      size: 13,
      color: Colors.primary.verylightpink,
    }),
    marginTop: Metrics.widthRatio(6),
  },
  amountTxt: {
    ...Fonts.font({
      size: 13,
      color: Colors.primary.clearblue,
    }),
    marginTop: Metrics.widthRatio(6),
  },
  img: {
    height: Metrics.widthRatio(100),
    width: Metrics.widthRatio(144),
    borderRadius: Metrics.widthRatio(4),
  },
});
