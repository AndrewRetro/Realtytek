import React, {useState, useRef, useEffect} from 'react';
import {View, Text} from 'react-native';
import moment from 'moment';
import _ from 'lodash';
import KeyboardManager from 'react-native-keyboard-manager';

import {MaterialTextField, BottomActionSheet} from '@reuseableComponents';

import {Images, Metrics, Colors, Fonts} from '@theme';
import apis from '@apis';
import constants from '@constants';
import {useDispatch} from 'react-redux';
import {request} from '@serviceAction';
import utility from '@utils';
import {MaskedInput} from '@components';

export default props => {
  const {property, cbSetLoanInfo} = props;

  const dispatch = useDispatch();
  const loanStatusSheetRef = useRef();
  const financingSheetRef = useRef();
  const refs = {};

  const [state, setState] = useState({
    company: {val: null, isUpdating: false, isError: false},
    contact: {val: null, isUpdating: false, isError: false},
    contact_number: {val: null, isUpdating: false, isError: false},
    sale_price: {val: null, isUpdating: false, isError: false},
    financing: {val: null, isUpdating: false, isError: false},
    emd_submitted: {val: null, isUpdating: false, isError: false},
    down_payment: {val: null, isUpdating: false, isError: false},
    loan_status: {val: null, isUpdating: false, isError: false},
    loan_status_updated_date: {val: null},
  });

  useEffect(() => {
    if (!utility.isPlatformAndroid())
      KeyboardManager.setToolbarPreviousNextButtonEnable(true);

    fetchLoanInfo();

    if (props.loanInfo) {
      plotLoanInfoIntoState(props.loanInfo);
    }
  }, []);

  const fetchLoanInfo = () => {
    dispatch(
      request(
        apis.getLoanInfo,
        apis.serviceTypes.GET,
        {
          property_id: property.id,
        },
        null,
        props.loanInfo ? false : true,
        false,
        plotLoanInfoIntoState,
      ),
    );
  };

  const plotLoanInfoIntoState = loanInfo => {
    setState(s => {
      let state = _.cloneDeep(s);
      Object.keys(state).map(key => {
        if (loanInfo[key]) {
          state[key] = {
            val: loanInfo[key],
            isUpdating: false,
            isError: false,
          };
        }
      });
      return state;
    });
    cbSetLoanInfo(loanInfo);
  };

  const onUpdateLoanInfo = (val, key) => {
    const payload = {};
    payload[key] = val;
    payload['property_id'] = property.id;
    payload['loan_status_updated_date'] = moment(new Date()).format(
      constants.DB_DATE_FORMAT,
    );
    dispatch(
      request(
        apis.updateLoanInfo,
        apis.serviceTypes.POST,
        payload,
        null,
        false,
        false,
        () => {
          setState(s => {
            const state = _.cloneDeep(s);
            state[key].isUpdating = false;
            return state;
          });
        },
        () => {
          setState(s => {
            const state = _.cloneDeep(s);
            state[key].isError = true;
            state[key].isUpdating = false;
            return state;
          });
        },
      ),
    );
  };

  const refCollector = key => ref => {
    refs[key] = ref;
  };

  const onBlur = key => () => {
    if (refs[key].getValue().length) {
      setState(s => {
        const state = _.cloneDeep(s);
        state[key].isUpdating = true;
        return state;
      });
      onUpdateLoanInfo(refs[key].getValue(), key);
    }
  };

  const onSubmitEditing = key => () => {
    refs[key].setFocus();
  };

  const onShowLoanStatusSheet = () =>
    setTimeout(() => loanStatusSheetRef.current.showActionSheet(), 300);

  const onShowFinancingOptionSheet = () =>
    setTimeout(() => financingSheetRef.current.showActionSheet(), 300);

  const cbOnLoanStatusSelected = index => {
    if (index) {
      setState(s => {
        const state = _.cloneDeep(s);
        state.loan_status.val = constants.LOAN_STATUS_OPTIONS[index];
        state.loan_status.isUpdating = true;
        return state;
      });
      onUpdateLoanInfo(constants.LOAN_STATUS_OPTIONS[index], 'loan_status');
    }
  };

  const cbOnFinancingOptionSelected = index => {
    setTimeout(() => {
      refs['emd_submitted'].setFocus();
      if (index) {
        setState(s => {
          const state = _.cloneDeep(s);
          state.financing.val = constants.FINANCING_OPTIONS[index];
          state.financing.isUpdating = true;
          return state;
        });
        onUpdateLoanInfo(constants.LOAN_STATUS_OPTIONS[index], 'financing');
      }
    }, 300);
  };

  return (
    <>
      <View style={{flexDirection: 'row', flexWrap: 'wrap'}}>
        <MaterialTextField
          ref={refCollector('company')}
          value={state.company.val}
          style={{width: '100%'}}
          label="Company"
          placeholder="Enter company name"
          onBlur={onBlur('company')}
          onSubmitEditing={onSubmitEditing('contact')}
          returnKeyType="next"
          blurOnSubmit={false}
          keyboardType="default"
          isShowLoader={state.company.isUpdating}
          isError={state.company.isError}
          error="Failed to update. Enter again"
        />
        <MaterialTextField
          ref={refCollector('contact')}
          value={state.contact.val}
          style={{width: '100%'}}
          label="Contact Name"
          placeholder="Enter contact name"
          onBlur={onBlur('contact')}
          onSubmitEditing={onSubmitEditing('contact_number')}
          returnKeyType="next"
          blurOnSubmit={false}
          keyboardType="default"
          isShowLoader={state.contact.isUpdating}
          isError={state.contact.isError}
          error="Failed to update. Write again"
        />
        <View style={{width: '100%'}}>
          <MaskedInput
            label="Phone Number"
            error="Phone number is required"
            isLabeledField={true}
            blurOnSubmit={false}
            ref={refCollector('contact_number')}
            value={state.contact_number.val}
            onBlur={onBlur('contact_number')}
            onSubmitEditing={onSubmitEditing('sale_price')}
            keyboardType="phone-pad"
            isShowLoader={state.contact_number.isUpdating}
            isError={state.contact_number.isError}
            error="Failed to update. Write again"
          />
        </View>
        <MaterialTextField
          ref={refCollector('sale_price')}
          value={state.sale_price.val}
          style={{width: '100%'}}
          label="Sale Price $"
          placeholder="Enter sale price"
          onBlur={onBlur('sale_price')}
          onSubmitEditing={onShowFinancingOptionSheet}
          returnKeyType="next"
          blurOnSubmit
          keyboardType="number-pad"
          isShowLoader={state.sale_price.isUpdating}
          isError={state.sale_price.isError}
          error="Failed to update. Write again"
        />
        <MaterialTextField
          value={state.financing.val}
          style={{width: '100%'}}
          label="Financing"
          placeholder="Select financing option"
          editable={false}
          rightIcon={Images.icDropdown}
          onRightPress={onShowFinancingOptionSheet}
          isShowLoader={state.financing.isUpdating}
          isError={state.financing.isError}
          error="Failed to update. Select again"
        />
        <MaterialTextField
          ref={refCollector('emd_submitted')}
          value={state.emd_submitted.val}
          style={{width: '100%'}}
          label="EMD Submitted $"
          placeholder="Enter EMD submitted"
          onBlur={onBlur('emd_submitted')}
          onSubmitEditing={onSubmitEditing('down_payment')}
          returnKeyType="next"
          blurOnSubmit={false}
          keyboardType="number-pad"
          isShowLoader={state.emd_submitted.isUpdating}
          isError={state.emd_submitted.isError}
          error="Failed to update. Write again"
        />
        <MaterialTextField
          ref={refCollector('down_payment')}
          value={state.down_payment.val}
          style={{width: '100%'}}
          label="Down Payment $"
          placeholder="Enter down payment made"
          onBlur={onBlur('down_payment')}
          returnKeyType="next"
          blurOnSubmit
          keyboardType="number-pad"
          isShowLoader={state.down_payment.isUpdating}
          isError={state.down_payment.isError}
          error="Failed to update. Write again"
        />
        <MaterialTextField
          value={state.loan_status.val}
          style={{width: '55%'}}
          label="Loan Status"
          placeholder="Select loan status"
          editable={false}
          rightIcon={Images.icDropdown}
          onRightPress={onShowLoanStatusSheet}
          isShowLoader={state.loan_status.isUpdating}
          isError={state.loan_status.isError}
          error="Failed to update. Select again"
        />
        <View style={styles.containerDate}>
          <Text
            style={{
              textAlign: 'center',
              ...Fonts.font({
                size: 14,
                color: Colors.primary.darkTwo,
              }),
            }}>
            {state.loan_status_updated_date.val}
          </Text>
        </View>
      </View>
      <BottomActionSheet
        title={'Loan approved?'}
        ref={loanStatusSheetRef}
        options={constants.LOAN_STATUS_OPTIONS}
        cbOnPressActionSheet={cbOnLoanStatusSelected}
      />
      <BottomActionSheet
        title={'Financing?'}
        ref={financingSheetRef}
        options={constants.FINANCING_OPTIONS}
        cbOnPressActionSheet={cbOnFinancingOptionSelected}
      />
    </>
  );
};

const styles = {
  actionBtn: {
    marginVertical: Metrics.xDoubleBaseMargin,
    width: (Metrics.screenWidth - Metrics.xDoubleBaseMargin) / 2,
  },
  containerDate: {
    textAlign: 'center',
    flexDirection: 'column-reverse',
    flex: 1,
    paddingBottom: Metrics.widthRatio(16),
  },
};
