import React, {useEffect} from 'react';
import {View, StyleSheet} from 'react-native';
import {EventBusSingleton} from 'light-event-bus';

import {BigCard, FloatingBtn} from '../components';
import {FlatListHandler} from '../reuseableComponents';

import {navigate, push} from '../services/NavigationService';

import {useDispatch, useSelector} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';
import {BUYERS} from '@actionTypes';
import constants from '@constants';

import {AppStyles, Metrics} from '@theme';

export default function (props) {
  const dispatch = useDispatch();
  const {isHorizontal} = props;
  const {buyers, user} = useSelector(({buyers, user}) => ({buyers, user}));

  useEffect(() => {
    fetchBuyers();
  }, []);

  const fetchBuyers = (isConcat = false, page = 1) => {
    dispatch(
      request(
        apis.createBuyer,
        apis.serviceTypes.GET,
        {
          buyer_type: constants.BUYER_TYPE,
          page,
          limit: 10,
        },
        BUYERS,
        false,
        isConcat,
        null,
        null,
        BUYERS,
      ),
    );
  };

  const onBuyer = buyingQuery => () => navigate('ClientProfile', {buyingQuery});

  const renderBuyers = ({item}) => (
    <BigCard
      onPress={onBuyer(item)}
      item={item}
      useFullWidth={isHorizontal ? false : true}
    />
  );

  const onAddBuyingQuery = () => {
    const {is_subscribe} = user.data;
    if (is_subscribe) {
      navigate('BuyingPreferences');
    } else {
      EventBusSingleton.publish('popup', {
        val: 'subscribe',
        onAccept: () => push('Subscription'),
      });
    }
  };

  const isFetchingStyle = {
    height:
      isHorizontal && buyers.isFetching && !buyers.data.length
        ? Metrics.widthRatio(164)
        : undefined,
  };

  return (
    <View
      style={
        isHorizontal
          ? {
              ...styles.horizontalContainer,
              ...isFetchingStyle,
            }
          : {flex: 1}
      }>
      <FlatListHandler
        bounces={isHorizontal ? false : true}
        horizontal={isHorizontal}
        fetchRequest={fetchBuyers}
        data={buyers.data}
        meta={buyers.meta}
        isFetching={buyers.isFetching}
        renderItem={renderBuyers}
      />
      {!isHorizontal && <FloatingBtn onPress={onAddBuyingQuery} />}
    </View>
  );
}

const styles = StyleSheet.create({
  horizontalContainer: {
    ...AppStyles.centerAlign,
  },
  listEmpty: {
    paddingTop: Metrics.widthRatio(30),
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
