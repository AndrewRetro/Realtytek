import React, {useEffect} from 'react';
import {View, StyleSheet} from 'react-native';

import {BigCard} from '../components';
import {FlatListHandler} from '../reuseableComponents';
import {push} from '@nav';

import {useDispatch, useSelector} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';
import {UNDER_CONTRACT} from '@actionTypes';
import constants from '@constants';
import {AppStyles, Metrics} from '@theme';

export default function (props) {
  const dispatch = useDispatch();

  const {isHorizontal} = props;

  const underContract = useSelector(({underContract}) => underContract);

  useEffect(() => {
    fetchUnderContract();
  }, []);

  const fetchUnderContract = (isConcat = false, page = 1) => {
    dispatch(
      request(
        apis.createBuyer,
        apis.serviceTypes.GET,
        {
          limit: 10,
          page,
          buyer_type: constants.UNDER_CONTRACT,
        },
        UNDER_CONTRACT,
        false,
        isConcat,
      ),
    );
  };

  const onContractDetail = contract => () => push('UnderContract', {contract});

  const renderUnderContract = ({item}) => (
    <BigCard
      item={item}
      useFullWidth={isHorizontal ? false : true}
      onPress={onContractDetail(item)}
    />
  );

  const isFetchingStyle = {
    height:
      isHorizontal && underContract.isFetching && !underContract.data.length
        ? Metrics.widthRatio(164)
        : undefined,
  };

  return (
    <View
      style={
        isHorizontal
          ? {
              ...styles.horizontalContainer,
              ...isFetchingStyle,
            }
          : {flex: 1}
      }>
      <FlatListHandler
        bounces={isHorizontal ? false : true}
        horizontal={isHorizontal}
        fetchRequest={fetchUnderContract}
        data={underContract.data}
        meta={underContract.meta}
        isFetching={underContract.isFetching}
        renderItem={renderUnderContract}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  horizontalContainer: {
    ...AppStyles.centerAlign,
  },
});
