import React, {useMemo} from 'react';
import {Image, Text, StyleSheet} from 'react-native';
import {ImageHandler, ButtonView} from '../reuseableComponents';
import {Colors, Fonts, Metrics} from '../theme';

export default ({
  bgColor,
  icon,
  title,
  useMargin,
  style,
  useBold,
  onPress,
  txtColor,
  alignCenter,
  useRegularTxt,
  tintColor,
  txtSize,
  disabled,
  txtStyle,
}) => {
  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          width: useBold ? 120 : 75,
          height: useBold ? 44 : 30,
          borderRadius: 4,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          alignSelf: alignCenter ? 'center' : 'auto',
          backgroundColor: bgColor || Colors.primary.clearblue,
          marginLeft: useMargin ? Metrics.smallMargin : 0,
        },
        title: {
          ...Fonts.font({
            size: txtSize ? txtSize : useBold ? 16 : 11,
            type:
              useBold && !useRegularTxt
                ? Fonts.Type.SemiBold
                : Fonts.Type.Regular,
            color: txtColor || Colors.primary.white,
          }),
          marginLeft: icon ? 6 : 0,
        },
        img: {
          tintColor: tintColor || Colors.primary.white,
          width: Metrics.widthRatio(16),
          height: Metrics.widthRatio(16),
          resizeMode: 'contain',
        },
      }),
    [bgColor],
  );

  return (
    <ButtonView
      disabled={disabled}
      onPress={onPress}
      style={[styles.container, style]}>
      {icon && <Image style={styles.img} source={icon} />}
      <Text style={[styles.title, txtStyle]}>{title}</Text>
    </ButtonView>
  );
};
