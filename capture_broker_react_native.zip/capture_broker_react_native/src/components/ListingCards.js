import React from 'react';
import {View, Text, StyleSheet, Image} from 'react-native';

import {
  ImageHandler,
  ButtonView,
  ImageHandlerUpdated,
} from '@reuseableComponents';
import {Rating} from '@components';

import utility from '@utils';
import {Colors, Fonts, Images, Metrics} from '@theme';
import {push} from '@nav';

export default function ({
  item,
  isSelected,
  isShowSelection,
  style,
  cbOnPropertySelected,
  imgStyle = {},
  enableInvite = false,
}) {
  const onProperty = () =>
    enableInvite
      ? push('PropertyDetail', {
          property: item,
          enableInvite,
        })
      : push('ListingDetails', {property: item});

  const onToggleCheckbox = () => cbOnPropertySelected(item);

  const CheckBox = () =>
    isShowSelection ? (
      <ButtonView onPress={onToggleCheckbox} style={styles.wrapperIcCheckBox}>
        <Image
          source={isSelected ? Images.icCheckActive : Images.icCheckDisable}
        />
      </ButtonView>
    ) : null;

  return (
    <ButtonView onPress={onProperty} style={[styles.container, style]}>
      <View>
        <ImageHandlerUpdated
          imageStyle={{borderRadius: 4}}
          style={{...styles.img, ...imgStyle}}
          source={
            typeof item.image_url == 'string'
              ? {uri: item.image_url}
              : item.image_url
          }
        />
        <View style={styles.amountWrapper}>
          <Text style={styles.amountTxt}>
            {utility.formateCurrency(item.asking_price ?? 90000)}
          </Text>
        </View>
      </View>

      <View style={styles.addressWrapper}>
        <ImageHandler source={Images.icLocation} />
        <Text style={styles.addressTxt}>{item.address}</Text>
      </View>
      <Text style={styles.nameTxt}>{item.title}</Text>

      <View style={styles.ratingContainer}>
        <Text style={styles.ratingTxt}>Rating: </Text>
        <Rating rating={item.rating} />
      </View>

      <CheckBox />
    </ButtonView>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 4,
    margin: Metrics.baseMargin,
    marginBottom: 0,
    padding: Metrics.widthRatio(6),
    paddingBottom: Metrics.baseMargin,
    backgroundColor: Colors.primary.white,
    shadowColor: 'rgba(0, 0, 0, 0.04)',
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowRadius: 10,
    shadowOpacity: 1,
    elevation: 4,
  },
  img: {
    width: '100%',
    height: Metrics.heightRatio(130),
    borderRadius: Metrics.widthRatio(4),
  },
  addressWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: Metrics.baseMargin,
    marginLeft: Metrics.smallMargin,
    marginBottom: 0,
  },
  addressTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.clearblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
  nameTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkslateblue,
    }),
    marginLeft: Metrics.smallMargin,
    marginTop: Metrics.widthRatio(4),
  },
  amountWrapper: {
    left: 6,
    bottom: 6,
    borderRadius: 4,
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.primary.white,
    padding: Metrics.heightRatio(5),
  },
  amountTxt: {
    ...Fonts.font({
      type: Fonts.Type.SemiBold,
      size: 12,
      color: Colors.primary.clearblue,
    }),
  },
  ratingTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.lightgreyblue,
    }),
    marginLeft: Metrics.smallMargin,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: Metrics.baseMargin,
  },
  wrapperIcCheckBox: {
    position: 'absolute',
    right: Metrics.baseMargin,
    top: Metrics.heightRatio(122),
  },
});
