import React from 'react';
import {Image, View, Text, StyleSheet, SafeAreaView} from 'react-native';

import {ButtonView} from '@reuseableComponents';
import {pop} from '@nav';

export default params => (
  <SafeAreaView style={styles.safeArea}>
    <View style={styles.header}>
      <ButtonView style={styles.back} onPress={pop}>
        <Image source={require('../backArrow/backArrow.png')} />
      </ButtonView>
    </View>
    <View style={styles.container}>
      <Text style={styles.txtErr}>
        This Apple account is already associated with another user
      </Text>
    </View>
  </SafeAreaView>
);

const styles = StyleSheet.create({
  safeArea: {flex: 1, backgroundColor: 'white'},
  container: {flex: 1, alignItems: 'center', justifyContent: 'center'},
  header: {
    flexDirection: 'row',
    backgroundColor: 'white',
    padding: 8,

    shadowColor: 'rgba(0, 0, 0, 0.04)',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowRadius: 6,
    shadowOpacity: 1,
    elevation: 4,
  },
  back: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  txtErr: {
    marginHorizontal: 32,
    textAlign: 'center',
  },
});
