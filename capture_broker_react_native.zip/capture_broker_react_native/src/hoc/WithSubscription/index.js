import React, {useEffect, useRef, useState} from 'react';
import {Platform} from 'react-native';
import {
  useIAP,
  requestSubscription,
  validateReceiptIos,
  acknowledgePurchaseAndroid,
  flushFailedPurchasesCachedAsPendingAndroid,
  clearTransactionIOS,
} from 'react-native-iap';
import _ from 'lodash';
import {showSpinner, hideSpinner} from 'react-native-globalspinner';

import AssociationError from '../AssociationError';
import constants from '@constants';
import utils from '@utils';

import {useDispatch, useSelector} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';
import {generalSaveAction} from '@serviceAction';
import {USER} from '@actionTypes';
import {pop} from '@nav';

const IS_IOS = Platform.OS == 'ios';
const SUB_SKUS = IS_IOS
  ? ['com.realtytekbroker.monthly', 'com.realtytekbroker.yearly']
  : ['com.capturebroker.monthly', 'com.capturebroker.yearly'];

const SKUS_ID_BACKEND = IS_IOS
  ? {
      'com.realtytekbroker.monthly': 1,
      'com.realtytekbroker.yearly': 2,
    }
  : {
      'com.capturebroker.monthly': 1,
      'com.capturebroker.yearly': 2,
    };

const WithSubscription = (
  WrappedComponent,
  {isFetchPackages, isFetchAvailablePurchases},
) => {
  const WithSubs = props => {
    const [state, setState] = useState({isFetching: true, selectedSub: null});
    const dispatch = useDispatch();
    const {
      connected,
      subscriptions,
      availablePurchases,
      currentPurchase,
      finishTransaction,
      getSubscriptions,
      getAvailablePurchases,
    } = useIAP();

    const user = useSelector(({user}) => user.data);

    // MAKING PURCHASE IN THIS SECTIONS

    // 1ST STEP FETCH SUBSCRIPTIONS
    // checking connection status and fetching subscriptions
    useEffect(() => {
      connected && isFetchPackages && getSubscriptions(SUB_SKUS);
      connected && isFetchAvailablePurchases && getAvailablePurchases();
      connected && clearTransactions();
    }, [connected, getSubscriptions, getAvailablePurchases]);

    // this function was present in RNIAP example so i added it
    const clearTransactions = async () => {
      try {
        if (IS_IOS) {
          await clearTransactionIOS();
        } else {
          await flushFailedPurchasesCachedAsPendingAndroid();
        }
      } catch (err) {
        console.warn(err.code, err.message);
      }
    };

    // setting loader to false
    useEffect(
      () => setState(s => ({...s, isFetching: false})),
      [subscriptions],
    );

    // 2ND STEP BUY SUBSCRIPTION
    // buying subscription
    const onRequestSubscription = selectedSub => {
      setState(s => ({...s, selectedSub}));
      showSpinner();
      requestSubscription(selectedSub.productId)
        .then(() => {})
        .catch(hideSpinner);
    };

    // 3RD STEP TRACK PURCHASE
    // tracking purchase response which is received in currentPurchase variable
    useEffect(() => {
      const checkCurrentPurchase = async purchase => {
        if (purchase) {
          const receipt = purchase.transactionReceipt;
          if (receipt) {
            // it is part of ios flow to have receipt validation
            // doing it here
            if (IS_IOS) {
              const gateway_response = await validateReceipt(receipt);

              gateway_response &&
                registerBoughtSubscription({
                  gateway_response,
                  selectedSub: state.selectedSub,
                });
            } else {
              registerBoughtSubscription({
                gateway_response: purchase,
                selectedSub: state.selectedSub,
              });

              // If not consumable
              // acknowledgePurchaseAndroid(purchase.purchaseToken);
            }
          }
          try {
            const ackResult = await finishTransaction(purchase);
          } catch (ackErr) {
            console.warn('ackErr', ackErr);
          }
        }
      };

      // when there are multiple unfinished transactions currentPurchases
      // returns an array
      currentPurchase &&
        checkCurrentPurchase(
          Array.isArray(currentPurchase) ? currentPurchase[0] : currentPurchase,
        );
    }, [currentPurchase]);

    const isLiveEnv = __DEV__;

    // 4TH STEP VALIDATE RECEIPT FOR IOS ONLY
    // doing receipt validation
    const validateReceipt = async receipt => {
      const response = await validateReceiptIos(
        {
          'receipt-data': receipt,
          password: constants.APP_SPECIFIC_SHARED_SECRET,
        },
        false,
      ); //true for debug and false for live. True indicates its sandbox environment
      // so it request to sandbox and false for live environment

      const {status} = response;

      if (status === 0 && response.latest_receipt_info.length) {
        return response.latest_receipt_info.sort(
          (a, b) => b.expires_date_ms - a.expires_date_ms,
        )[0];
      } else {
        return null;
      }
    };

    const registerBoughtSubscription = ({
      gateway_response,
      selectedSub,
      isRestoringSubscription,
    }) => {
      dispatch(
        request(
          apis.buySubscription,
          apis.serviceTypes.POST,
          {
            subscription_package_id:
              SKUS_ID_BACKEND[
                IS_IOS
                  ? gateway_response.product_id
                  : gateway_response.productId
              ],
            ...(selectedSub && {gateway_request: JSON.stringify(selectedSub)}),
            gateway_response: JSON.stringify(gateway_response),
            device_type: IS_IOS ? 'ios' : 'android',
          },
          null,
          isRestoringSubscription ? true : false,
          // selectedSub ? true : false,
          false,
          res => {
            hideSpinner();
            if (res.is_subscribe !== user.is_subscribe) {
              const clonedUser = _.cloneDeep(user);
              clonedUser.is_subscribe = res.is_subscribe;
              // clonedUser.is_subscribe = 0;
              dispatch(generalSaveAction(USER.SUCCESS, clonedUser));
              !!selectedSub &&
                utils.showFlashMessage(
                  'Successfully bought subscription',
                  'success',
                );
              !!selectedSub && pop();

              if (isRestoringSubscription) {
                utils.showFlashMessage(
                  'Successfully restored subscription',
                  'success',
                );
              }
            }
          },
          err => {
            hideSpinner();
            // utils.showFlashMessage('Faild to register subscription');
          },
        ),
      );
    };

    // VALIDATING IF USER IS SUBSCRIBED
    useEffect(() => {
      isFetchAvailablePurchases &&
        availablePurchases &&
        !!availablePurchases.length &&
        lockFunc();
    }, [availablePurchases]);

    const lock = useRef({isExecuted: false});
    const lockFunc = () => {
      if (!lock.current.isExecuted) {
        lock.current = {isExecuted: true};
        restoreSubscription(availablePurchases);
      }
    };

    const restoreSubscription = async (purchases, isRestoringSubscription) => {
      if (purchases.length) {
        let purchase = null;

        if (IS_IOS) purchase = purchases[purchases.length - 1];
        else purchase = purchases[0];

        const receipt = purchase.transactionReceipt;

        let gateway_response = null;
        if (receipt) {
          if (IS_IOS) {
            gateway_response = await validateReceipt(receipt);
            if (gateway_response) {
              registerBoughtSubscription({
                gateway_response,
                selectedSub: null,
                isRestoringSubscription,
              });
            }
          } else {
            gateway_response = purchase;
            registerBoughtSubscription({
              gateway_response,
              selectedSub: null,
            });

            // If not consumable
            acknowledgePurchaseAndroid(purchase.purchaseToken);
          }
        }
      }
    };

    // if apple account is associated to a different email show this screen
    if (user.isDifferentAssociation) return <AssociationError />;

    return (
      <WrappedComponent
        purchases={availablePurchases}
        subscriptions={subscriptions}
        isFetching={state.isFetching}
        restoreSubscription={restoreSubscription}
        onRequestSubscription={onRequestSubscription}
        {...props}
      />
    );
  };

  return WithSubs;
};

export default WithSubscription;
