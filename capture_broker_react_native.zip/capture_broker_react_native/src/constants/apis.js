//
//  index.js:
//  BoilerPlate
//
//  Created by Retrocube on 10/4/2019, 9:13:09 AM.
//  Copyright © 2019 Retrocube. All rights reserved.
//

// const baseUrlDev = 'https://realtytek.dev.retrocubedev.com/';
// const baseUrlQa = 'https://realtytek.qa.retrocubedev.com/';

const live = 'https://realtytek.net/';

const apis = {
  //App Constants
  socketIP: '192.34.60.217',
  socketPort: '1233',
  baseURL: live,
  applicationToken: 'api.Pd*!(5675',

  //Services Constants
  signup: 'api/user',
  login: 'api/user/login',
  forgotPass: 'api/user/forgot-password',
  changePass: 'api/user/change-password',
  logout: 'api/user/logout',
  shareProfile: 'api/share/user-profile',
  notification: 'api/user-notification',
  fetchBadgeCount: 'api/count-notification',

  addLead: 'api/lead',
  createProperty: 'api/property',
  sendInvitationLead: 'api/lead/invitation/send',
  deactivateProperty: 'api/update-property-status',
  createBuyer: 'api/buyer',
  recomendedHomes: 'api/buyer/recommended/homes',
  touredHomes: 'api/buyer/tour/homes',
  appointments: 'api/appointments',
  uploadDoc: 'api/store/disclosure',
  getDisclosures: 'api/get/disclosure',
  initiateContract: 'api/property/initiate/contract',
  touredHomes: 'api/buyer/tour/homes',
  updateContractStatus: 'api/property/contract/status',
  updateLoanInfo: 'api/property/loaninfo/update',
  getContractStatus: 'api/get/property/contract/status',
  getLoanInfo: 'api/get/property/loaninfo/contract',
  deleteDocOrLink: 'api/delete/disclosure',
  buySubscription: 'api/user-subscription',
  toggleNotifications: 'api/notification/setting',
  uploadAgreementDoc: 'api/agent-agrement-store',

  privacy: 'https://realtytek.net/app-content/privacy_policy',
  terms: 'https://realtytek.net/app-content/term_and_condition',

  faqs: 'https://realtytek.net/app-faq',

  LOCATION_TIME_OUT: 10000,
  LOCATION_MAX_AGE: 1000,
  LOCATION_HIGH_ACCURACY: false,

  serviceTypes: {
    GET: 'get',
    POST: 'post',
    PUT: 'put',
    DELETE: 'delete',
  },
};

export default apis;
