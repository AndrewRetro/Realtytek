export const AppointmentStatus = {
  PENDING: 'pending',
  CONFIRMED: 'confirmed',
  REJECTED: 'reject',
  ACCEPT: 'accept',
};

const constants = {
  USER_GROUPS: {
    USER_GROUP_ID_1: 1,
    USER_GROUP_ID_2: 2,
  },

  USER_TYPE_BROKER: '1',
  BUYER_TYPE: 'buyers',
  UNDER_CONTRACT: 'under_contract',
  DISPLAY_DATE_FORMAT: 'DD/MM/YYYY',
  TIME_FORMAT_DB: 'HH:mm:ss',
  DISPLAY_TIME_FORMAT: 'LT',
  NOON_FORMAT: 'h:mm A',
  DB_DATE_FORMAT: 'YYYY-MM-DD',
  STATUS_INITIATE_CONTRACT: '1',

  PROPERTY_TYPES: {
    0: 'Single Family (SF)',
    1: 'Town House (TH)',
    2: 'Condo (C)',
    3: 'Farm (F)',
    4: 'Land (L)',
  },

  FIRST_TIME_BUYER: {
    1: 'Yes',
    2: 'No',
  },

  CONTRACT_STATUS: {1: 'Yes', 2: 'No'},
  CONTRACT_STATUS_ACTIVE: 'Active',

  PRE_APROVED: {1: 'Yes', 2: 'No'},

  PROPERTY_TYPES_OPTIONS: [
    'Single Family (SF)',
    'Town House (TH)',
    'Condo (C)',
    'Farm (F)',
    'Land (L)',
    'Cancel',
  ],

  FIRST_TIME_BUYER_OPTIONS: ['Cancel', 'Yes', 'No'],
  PRE_APPROVED_OPTIONS: ['Cancel', 'Yes', 'No'],
  IMAGE_PICKING_OPTIONS: ['Cancel', 'Camera', 'Photo Album'],

  LOAN_STATUS_OPTIONS: [
    'Cancel',
    'Applied',
    'Approved',
    'Denied',
    'Under Writing',
    'Appraisal',
    'Final Underwriting',
    'cleared to Close',
    'Closed/Settled',
  ],

  FINANCING_OPTIONS: ['Cancel', 'Cash', 'Conventional', 'FHA', 'VA', 'USDA'],

  APP_SPECIFIC_SHARED_SECRET: 'b2f71c14646c4db694b47c563e870c7c',

  NOTIFICATION_IDENTIFIER: {
    CREATE_APPOINTMENT: 'create_appointment',
    PROPERTY_CREATE: 'property_create',
    CREATE_BUYING_QUERY: 'create_buying_query',
  },
  LOGOUT: 'logout',
};

export default constants;
