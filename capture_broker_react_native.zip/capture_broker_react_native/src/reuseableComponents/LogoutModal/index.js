import React from 'react';
import {View, Text, SafeAreaView} from 'react-native';
import {EventBusSingleton} from 'light-event-bus';

import Modal from '../Modal';
import {SmallBtn} from '../../components';

import {Metrics, Colors, AppStyles} from '../../theme';

// redux imports
import {useDispatch} from 'react-redux';
import {generalSaveAction} from '@serviceAction';
import {LOGOUT} from '@actionTypes';
import {request} from '@serviceAction';
import apis from '@apis';
import {handleBadgeCount} from '../../reuseableFunctions';

export default ({setLogin}) => {
  const dispatch = useDispatch();

  const vals = {
    initiateContract: {
      title: 'Initiate Contract?',
      desc: 'Are you sure you want to initiate contract against this property?',
      accept: 'Accept',
      acceptColor: Colors.primary.vermillion,
    },
    lead: {
      title: 'Delete Lead?',
      desc: 'Are you sure you want to delete this lead?',
      accept: 'Yes, Delete',
      acceptColor: Colors.primary.vermillion,
    },
    buyer: {
      title: 'Delete Buyer?',
      desc: 'Are you sure you want to delete this buyer?',
      accept: 'Yes, Delete',
      acceptColor: Colors.primary.vermillion,
    },
    logout: {
      title: 'Logout?',
      desc: 'Are you sure you want to logout',
      accept: 'Yes, Logout',
      acceptColor: Colors.primary.clearblue,
    },
    sub: {
      title: 'Subscribe?',
      desc: 'Are you sure you want to cancel subscription?',
      accept: 'Yes, Cancel',
      acceptColor: Colors.primary.vermillion,
    },
    upgradeSub: {
      title: 'Subscribe?',
      desc: 'Are you sure you want to upgrade subscription?',
      accept: 'Yes, Upgrade',
      acceptColor: Colors.primary.clearblue,
    },
    reject: {
      title: 'Reject Appointment?',
      desc: 'Are you sure you want to reject appointment?',
      accept: 'Yes, Reject',
      acceptColor: Colors.primary.vermillion,
    },
    deactivate: {
      title: 'Deactivate Property?',
      desc: 'Are you sure you want to deactivate this property?',
      accept: 'Yes, Deactivate',
      acceptColor: Colors.primary.vermillion,
    },
    activate: {
      title: 'Activate property?',
      desc: 'Are you sure you want to activate this property?',
      accept: 'Yes, Activate',
      acceptColor: Colors.primary.vermillion,
    },
    subscribe: {
      title: 'Purchase Subscription',
      desc: 'You must purchase susbscription to avail this feature',
      accept: 'Buy',
      acceptColor: Colors.primary.vermillion,
    },
    delete_account: {
      title: 'Delete Account',
      desc: 'Are you sure you want to delete your account?',
      accept: 'Yes, Sure',
      acceptColor: Colors.primary.vermillion,
    },
  };

  const [state, setState] = React.useState({...vals['lead'], cbOnAccept: null});

  const modal = React.useRef();

  React.useEffect(() => {
    EventBusSingleton.subscribe('popup', ({val, onAccept, is401}) => {
      if (is401) logout();
      else {
        setState(s => ({...vals[val], cbOnAccept: onAccept}));
        setTimeout(() => modal.current.setModalVisibility(true), 300);
      }
    });
  }, []);

  const onCancel = () => modal.current.setModalVisibility(false);

  const onAcceptance = () => {
    if (state.cbOnAccept) setTimeout(state.cbOnAccept, 400);

    if (state.title == 'Logout?') {
      setTimeout(requestLogout, 300);
    }
    modal.current.setModalVisibility(false);
  };

  requestLogout = () => {
    dispatch(
      request(
        apis.logout,
        apis.serviceTypes.POST,
        {},
        null,
        true,
        false,
        logout,
      ),
    );
  };

  const logout = () => {
    setLogin(false);
    dispatch(generalSaveAction(LOGOUT));
    handleBadgeCount({badge_count: 0});
  };

  return (
    <Modal ref={modal}>
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.container}>
          <Text style={styles.title}>{state.title}</Text>
          <Text style={styles.desc}>{state.desc}</Text>
          <View style={styles.containerRow}>
            <SmallBtn
              style={styles.btnCancel}
              bgColor={Colors.primary.blueyGrey}
              txtColor={Colors.primary.white}
              onPress={onCancel}
              useBoldTxt
              title="Cancel"
              txtStyle={AppStyles.gbSb(12, Colors.primary.white)}
            />
            <SmallBtn
              onPress={onAcceptance}
              style={styles.btnAccept}
              bgColor={state.acceptColor}
              txtColor={Colors.primary.white}
              useBoldTxt
              title={state.accept}
              txtStyle={AppStyles.gbSb(12, Colors.primary.white)}
            />
          </View>
        </View>
      </SafeAreaView>
    </Modal>
  );
};

const styles = {
  safeArea: {
    flex: 1,
    backgroundColor: 'rgba(1,1,1,0.7)',
    justifyContent: 'center',
  },
  container: {
    marginHorizontal: Metrics.baseMargin,
    justifyContent: 'center',
    backgroundColor: 'white',
    borderRadius: Metrics.smallMargin,
    width: '90%',
    alignItems: 'center',
    padding: Metrics.baseMargin,
  },
  title: {
    ...AppStyles.gbSb(18, Colors.primary.black),
    marginTop: Metrics.widthRatio(8),
  },
  desc: {
    ...AppStyles.gbRe(12, Colors.primary.blueyGrey),
    marginTop: Metrics.widthRatio(50),
    marginHorizontal: Metrics.doubleBaseMargin * 1.5,
    textAlign: 'center',
  },
  containerRow: {
    flexDirection: 'row',
    marginTop: Metrics.doubleBaseMargin * 2,
  },
  btnCancel: {
    flex: 1,
    marginRight: Metrics.smallMargin,
    height: Metrics.widthRatio(40),
  },
  btnAccept: {
    marginLeft: Metrics.smallMargin,
    flex: 1,
    height: Metrics.widthRatio(40),
  },
};
