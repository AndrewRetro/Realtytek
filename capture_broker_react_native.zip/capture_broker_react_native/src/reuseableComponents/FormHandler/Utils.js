import _ from 'lodash';
import {INPUT_TYPES} from './Constants';

// const specialCharTsest = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;

const isContainingSpecialChar = string => /[^A-Za-z0-9]/.test(string);

const isContainingUpperCase = str => {
  return /[A-Z]/.test(str);
};

const isContainingLowerCase = str => /[a-z]/.test(str);

const isContainingADigit = str => /[0-9]/.test(str);

function isEmpty(data: any) {
  return _.isEmpty(data);
}

function isEmailValid(email: string) {
  const re =
    /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);
}

function isValidURL(str) {
  var pattern = new RegExp(
    '^(https:\\/\\/)' + // protocol
      '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // domain name
      '((\\d{1,3}\\.){3}\\d{1,3}))' + // OR ip (v4) address
      '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
      '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
      '(\\#[-a-z\\d_]*)?$',
    'i',
  ); // fragment locator

  return !!pattern.test(str);
}

function isPasswordValid(password: string) {
  if (password.length < 8) {
    return false;
  }

  // if pass dont have any special letter return false
  if (!isContainingSpecialChar(password)) {
    return false;
  }
  // if pass dont have any upper case letter return false
  if (!isContainingUpperCase(password)) {
    return false;
  }
  // if pass dont have any lower case letter return false
  if (!isContainingLowerCase(password)) {
    return false;
  }

  // if pass dont have any lower case letter return false
  if (!isContainingADigit(password)) {
    return false;
  }

  return true;
}

function isInputValid(value, type, password) {
  switch (type) {
    case INPUT_TYPES.EMAIL: {
      return !isEmpty(value) && isEmailValid(value);
    }
    case INPUT_TYPES.PASSWORD: {
      return !isEmpty(value) && isPasswordValid(value);
    }
    case INPUT_TYPES.TEXT: {
      return !isEmpty(value);
    }
    case INPUT_TYPES.NUMBER: {
      return !isEmpty(value);
    }
    case INPUT_TYPES.CONFIRM_PASSWORD: {
      return !isEmpty(value) && value === password;
    }
    case INPUT_TYPES.WEBSITE: {
      return !isEmpty(value) && isValidURL(value);
    }
    default: {
      return true;
    }
  }
}

function getError(type, val, originalError) {
  const {EMAIL, PASSWORD, CONFIRM_PASSWORD, WEBSITE} = INPUT_TYPES;

  if (!val.length) {
    if (type === EMAIL) {
      return 'Email is required';
    }

    if (type === WEBSITE && !val.length) {
      return 'Website is required';
    }

    if (type === PASSWORD) {
      return 'Password is required';
    }

    if (type === CONFIRM_PASSWORD) {
      return 'Confirm password is required';
    }
  }

  if (type === WEBSITE && !isValidURL(val)) {
    return 'Enter a valid website url';
  }

  if (type === CONFIRM_PASSWORD && val.length < 6) {
    return 'Password length must be greater than 6 characters';
  }

  if (type === CONFIRM_PASSWORD && val.length >= 6) {
    return "Confirm password and password don't match";
  }

  if (type === PASSWORD) {
    if (val.length < 8) {
      return 'Password length must be greater than or equal to 8 characters';
    }
    if (!isContainingSpecialChar(val)) {
      return 'Password must contain at least one special character';
    }
    if (!isContainingUpperCase(val)) {
      return 'Password must contain at least one upper case character';
    }
    if (!isContainingLowerCase(val)) {
      return 'Password must contain at least one lower case character';
    }
    if (!isContainingADigit(val)) {
      return 'Password must contain at least one one digit';
    }
  }

  return originalError;
}

// showPassword is passed to input to as props
function isSecureTextEntry(childProps) {
  // handling password field
  if (
    childProps.type &&
    childProps.type === INPUT_TYPES.PASSWORD &&
    !childProps.showPassword
  ) {
    return true;
  }

  // handling confirm password field
  if (
    childProps.type &&
    childProps.type === INPUT_TYPES.CONFIRM_PASSWORD &&
    !childProps.showPassword
  ) {
    return true;
  }

  return false;
}

function getKeyboardType(childProps) {
  if (childProps.type) {
    switch (childProps.type) {
      case INPUT_TYPES.EMAIL: {
        return 'email-address';
      }
      case INPUT_TYPES.NUMBER: {
        return 'number-pad';
      }
      case INPUT_TYPES.PHONE: {
        return 'phone-pad';
      }
      default:
        return 'default';
    }
  }
  return 'default';
}

export {getKeyboardType, isInputValid, isSecureTextEntry, getError};
