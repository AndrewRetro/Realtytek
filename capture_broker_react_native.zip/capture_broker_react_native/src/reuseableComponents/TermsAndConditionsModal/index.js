import React, {Component} from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import {WebView} from 'react-native-webview';

import {Metrics, AppStyles, Images, Colors} from '@theme';
import Loader from '../Loader';
import ReusableModal from '../Modal';

export default class TermsAndConditionModal extends Component {
  show = () => this.modal.setModalVisibility(true);
  hide = () => this.modal.setModalVisibility(false);

  onAcceptTerms = () => {
    const {cbOnAcceptTerms} = this.props;
    // if (!isTermsAccepted) setTimeout(this.hide, 1000);
    cbOnAcceptTerms();
  };

  renderAcceptTerms = () => {
    const {isTermsAccepted, cbOnAcceptTerms, title} = this.props;
    return (
      <View
        style={{
          backgroundColor: 'white',

          paddingVertical: Metrics.smallMargin,
          justifyContent: 'center',
          flexDirection: 'row',
          alignItems: 'center',
          borderBottomLeftRadius: Metrics.smallMargin,
          borderBottomRightRadius: Metrics.smallMargin,
        }}>
        <Text
          style={[
            {
              paddingTop: 6,
              marginBottom: 2,
              marginLeft: 20,
              marginRight: 30,
              textDecorationColor: 'black',
              ...AppStyles.gbSb(16, Colors.primary.darkslateblue),
            },
          ]}>
          {title ? title : 'Accept terms and conditions'}
        </Text>

        <TouchableOpacity
          onPress={this.hide}
          style={{
            ...AppStyles.centerAligned,
            position: 'absolute',
            right: 6,
            top: 0,
            bottom: 0,
            flex: 1,
            backgroundColor: 'black',

            paddingHorizontal: Metrics.smallMargin,
          }}>
          <Image
            source={Images.icClose}
            style={{
              width: Metrics.widthRatio(20),
              height: Metrics.widthRatio(20),
            }}
          />
        </TouchableOpacity>
      </View>
    );
  };

  renderLoader = () => <Loader />;

  render() {
    const {url} = this.props;

    return (
      <ReusableModal ref={ref => (this.modal = ref)}>
        <View
          style={{
            flex: 1,
            backgroundColor: 'white',
            paddingTop: Metrics.doubleBaseMargin * 1.5,
          }}>
          {this.renderAcceptTerms()}
          <WebView
            source={{
              uri: url,
            }}
            style={{flex: 1}}
            startInLoadingState
            renderLoading={this.renderLoader}
          />
        </View>
      </ReusableModal>
    );
  }
}

const styles = {
  radio: {
    width: 20,
    height: 20,
    borderColor: '#000',
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  icCross: {
    width: Metrics.widthRatio(25),
    height: Metrics.widthRatio(25),
    resizeMode: 'contain',
  },
};
