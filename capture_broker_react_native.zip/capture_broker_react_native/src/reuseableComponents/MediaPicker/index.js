import React, {forwardRef, useCallback, useImperativeHandle} from 'react';
import {View, Image, StyleSheet, ScrollView} from 'react-native';

import {AppStyles, Metrics} from '../../theme';
import {
  selectMultipleImages,
  selectVideo,
  selectDoc,
  IMAGE_CONFIG,
} from './Utils';
import ButtonView from '../ButtonView';

const MediaPicker = forwardRef((props, ref) => {
  const {
    iconColor,
    numOfColumns,
    maxFiles,
    isDocumentPicker,
    isVideoPicker,
    isWithCoverImage,
    space,
    cbOnDocSelected,
  } = props;

  const [state, setState] = React.useState({
    imgs: [],
    docs: [],
    vid: '',
  });

  const blankSpace = space * (numOfColumns + 1);
  const margin = blankSpace / (numOfColumns + 1);
  // const margin = 0;
  const width =
    Metrics.screenWidth / numOfColumns - margin - margin / numOfColumns + 0.5;

  useImperativeHandle(ref, () => ({
    setImages: () => {},
    getDocs: () => state.docs,
  }));

  const showImagePicker = () =>
    selectMultipleImages({...IMAGE_CONFIG, maxFiles}).then(pickedImgs => {
      const imgs = [...state.imgs, ...pickedImgs];
      if (imgs.length > maxFiles) img.length = maxFiles;
      setState(state => ({...state, imgs}));
    });

  const showVideoPicker = () => {};

  const showDocumentPicker = () =>
    selectDoc().then(doc => {
      const docs = [...state.docs, ...doc];
      if (docs.length > maxFiles) docs.length = maxFiles;
      setState(state => ({...state, docs}));
      cbOnDocSelected && cbOnDocSelected();
    });

  const Picker = () => {
    const {imgs, docs} = state;

    if (isWithCoverImage && imgs.length < 1) return null;

    if (imgs.length == maxFiles) return null;

    if (isDocumentPicker && docs.length == maxFiles) return null;

    let onPickerPress;

    if (isDocumentPicker) {
      onPickerPress = showDocumentPicker;
    } else if (isVideoPicker) {
      onPickerPress = showVideoPicker;
    } else {
      onPickerPress = showImagePicker;
    }

    return (
      <ButtonView
        style={{
          height: width,
          width,
          marginLeft: margin,
          marginTop: margin,
          ...styles.containerIcPick,
        }}
        onPress={onPickerPress}>
        <Image
          source={require('./icon/ic_add.png')}
          style={{...styles.icPick, tintColor: iconColor}}
        />
      </ButtonView>
    );
  };

  const onDelete = useCallback(index => () => {
    const {imgs, docs, vid} = state;

    if (isDocumentPicker) {
      docs.splice(index, 1);
      setState(state => ({...state, docs}));
    } else if (isVideoPicker) {
      vid.splice(index, 1);
      setState(state => ({...state, vid}));
    } else {
      imgs.splice(index, 1);
      setState(state => ({...state, imgs}));
    }
  });

  const CoverImage = () => {
    const {imgs} = state;

    if (isWithCoverImage)
      return imgs.length ? (
        <View>
          <Image
            source={{uri: imgs[0].path}}
            style={{
              width: Metrics.screenWidth - space * 2,
              height: Metrics.screenWidth / 1.2 - space * 2,
              marginLeft: space,
              ...styles.containerCoverImg,
            }}
          />
          <IcDelete index={0} />
        </View>
      ) : (
        <ButtonView
          style={{
            width: Metrics.screenWidth - space * 2,
            height: Metrics.screenWidth / 1.2 - space * 2,
            marginLeft: space,
            ...styles.containerCoverImg,
          }}
          onPress={showImagePicker}>
          <Image
            source={require('./icon/ic_add.png')}
            style={{tintColor: iconColor}}
          />
        </ButtonView>
      );

    return null;
  };

  return (
    <ScrollView bounces={false}>
      <View style={styles.container}>
        <CoverImage />
        <Picker />
        <Picked
          iconColor={iconColor}
          margin={margin}
          width={width}
          docs={state.docs}
          imgs={state.imgs}
          onDelete={onDelete}
          isWithCoverImage={isWithCoverImage}
          isDocumentPicker={isDocumentPicker}
          isVideoPicker={isVideoPicker}
        />
      </View>
    </ScrollView>
  );
});

const Picked = ({
  isWithCoverImage,
  isDocumentPicker,
  isVideoPicker,
  docs,
  imgs,
  onDelete,
  width,
  margin,
  iconColor,
}) => {
  const Images = () =>
    imgs.map((img, index) => (
      <Img key={`${index}_img`} {...img} index={index} />
    ));

  const Img = ({path, index}) => {
    // if its with cover image then dont render 0 index
    if (!index && isWithCoverImage) return null;

    return (
      <View
        style={{
          height: width,
          width,
          marginLeft: margin,
          marginTop: margin,
          ...styles.containerImg,
        }}>
        <Image source={{uri: path}} style={styles.img} />
        <IcDelete index={index} />
      </View>
    );
  };
  const Vids = () => null;

  const Docs = () =>
    docs.map((doc, index) => <Doc key={doc.uri} index={index} />);

  const Doc = ({index}) => (
    <View
      style={{
        height: width,
        width,
        marginLeft: margin,
        marginTop: margin,
        ...styles.containerDoc,
      }}>
      <Image
        source={require('./icon/ic_doc.png')}
        style={{...styles.docImg, margin, tintColor: iconColor}}
      />
      <IcDelete index={index} />
    </View>
  );

  const IcDelete = ({index}) => {
    return (
      <ButtonView
        style={{
          top: margin / 2.5,
          right: margin / 2.5,
          ...styles.conatinerIcDelete,
        }}
        onPress={onDelete(index)}>
        <Image
          source={require('./icon/ic_cancel.png')}
          style={styles.icDelete}
        />
      </ButtonView>
    );
  };

  if (isDocumentPicker) {
    return <Docs />;
  } else if (isVideoPicker) {
    return <Vids />;
  } else {
    return <Images />;
  }
};

// Set default props
MediaPicker.defaultProps = {
  iconColor: '#2382fa',
  maxFiles: 6,
  numOfColumns: 4,
  isDocumentPicker: false,
  isVideoPicker: false,
  space: Metrics.baseMargin,
  isWithCoverImage: true,
};

export default MediaPicker;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  containerImg: {
    backgroundColor: 'white',
    ...AppStyles.heavyShadow,
  },
  img: {
    flex: 1,
    resizeMode: 'cover',
  },
  icPick: {
    width: 60,
    height: 60,
    resizeMode: 'contain',
  },
  containerIcPick: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    ...AppStyles.lightShadow,
  },
  conatinerIcDelete: {
    position: 'absolute',
    ...AppStyles.centerAligned,
    backgroundColor: 'red',
    width: Metrics.widthRatio(28),
    height: Metrics.widthRatio(28),
    borderRadius: Metrics.widthRatio(14),
  },
  icDelete: {
    width: Metrics.widthRatio(20),
    height: Metrics.widthRatio(20),
    resizeMode: 'contain',
  },
  docImg: {
    flex: 1,
    resizeMode: 'contain',
  },
  containerDoc: {
    backgroundColor: 'white',
    ...AppStyles.lightShadow,
    alignItems: 'center',
    justifyContent: 'center',
  },
  containerCoverImg: {
    alignItems: 'center',
    justifyContent: 'center',
  },
});
