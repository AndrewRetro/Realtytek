import React, {useCallback, useEffect, useRef} from 'react';
import {
  View,
  Text,
  SafeAreaView,
  Animated,
  TouchableWithoutFeedback,
  Easing,
  ActivityIndicator,
  Image,
} from 'react-native';
import {EventBusSingleton} from 'light-event-bus';

import Modal from '../Modal';

import {Metrics, Colors, AppStyles, Images} from '../../theme';

// redux imports
import {useDispatch} from 'react-redux';
import {request} from '@serviceAction';
import apis from '@apis';

import ButtonView from '../ButtonView';
import MediaPicker from '../MediaPicker';
import {USER} from '@actionTypes';

const AnimatedButtonView = Animated.createAnimatedComponent(ButtonView);

export default () => {
  const animHandle = useRef(new Animated.Value(0)).current;
  const initialState = useRef({
    isUploading: false,
    isErr: false,
    isSuccess: false,
    isDocSelected: false,
  }).current;
  const [state, setState] = React.useState(initialState);
  const modal = React.useRef();
  const dispatch = useDispatch();
  const refMediaPicker = useRef();

  React.useEffect(() => {
    EventBusSingleton.subscribe('showAddAgreementModal', () => {
      show();
    });
  }, []);

  const show = () => {
    modal.current.setModalVisibility(true);
    Animated.timing(animHandle, {
      toValue: 1,
      duration: 400,
      easing: Easing.bezier(0.38, 0.29, 1, -0.01),
      useNativeDriver: true,
    }).start();
  };

  const hide = () => {
    if (state.isUploading) return;

    Animated.timing(animHandle, {
      toValue: 0,
      duration: 100,
      useNativeDriver: true,
    }).start(() => modal.current.setModalVisibility(false));
  };

  const onUpload = () => {
    const doc = refMediaPicker.current.getDocs()[0];

    const payload = new FormData();
    payload.append('document_agrement', {
      uri: doc.uri,
      name: doc.name.split(' ').join('_'),
      type: doc.type,
    });

    dispatch(
      request(
        apis.uploadAgreementDoc,
        apis.serviceTypes.POST,
        payload,
        USER,
        false,
        false,
        res => {
          setState(s => ({
            ...s,
            isUploading: false,
            isErr: false,
            isSuccess: true,
          }));
          setTimeout(hide, 1000);
        },
        err => setState(s => ({...s, isUploading: false, isErr: true})),
      ),
    );

    setState(s => ({...s, isUploading: true, isErr: false}));
  };

  const resetState = useCallback(() => setState(initialState));

  const cbOnDocSelected = () => setState(s => ({...s, isDocSelected: true}));

  const transform = [
    {
      translateY: animHandle.interpolate({
        inputRange: [0, 1],
        outputRange: [300, 0],
      }),
    },
  ];

  return (
    <Modal ref={modal}>
      <TouchableWithoutFeedback style={{flex: 1}} onPress={hide}>
        <SafeAreaView style={styles.safeArea}>
          <TouchableWithoutFeedback>
            <Animated.View
              style={[
                styles.containerAnimated,
                {
                  transform,
                },
              ]}>
              <Text style={styles.title}>Upload agreement document</Text>
              <MediaPicker
                ref={refMediaPicker}
                isDocumentPicker
                isWithCoverImage={false}
                maxFiles={1}
                numOfColumns={3}
                cbOnDocSelected={cbOnDocSelected}
              />

              {state.isDocSelected && (
                <UpLoader
                  isErr={state.isErr}
                  isSuccess={state.isSuccess}
                  isUploading={state.isUploading}
                  onUpload={onUpload}
                  resetState={resetState}
                />
              )}
            </Animated.View>
          </TouchableWithoutFeedback>
        </SafeAreaView>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

const UpLoader = ({isUploading, onUpload, isErr, isSuccess, resetState}) => {
  const bounceHandle = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (isSuccess || isErr)
      Animated.timing(bounceHandle, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start(() => {
        setTimeout(resetState, 500);
      });

    // for resetting animation after compeletion
    // isErr && setTimeout(resetState, 500);
    // isSuccess && setTimeout(resetState, 500);
  }, [isErr, isSuccess]);

  const transform = [
    {
      scale: bounceHandle.interpolate({
        inputRange: [0, 0.5, 1],
        outputRange: [1, 1.5, 1],
      }),
    },
  ];

  return (
    <View style={styles.contianerUploader}>
      <AnimatedButtonView
        style={[
          {transform},
          {
            ...styles.btn,
            backgroundColor: isErr
              ? Colors.primary.vermillion
              : isSuccess
              ? Colors.primary.clearblue
              : '#8BC34A',
          },
        ]}
        onPress={onUpload}>
        {!isUploading && (
          <Image
            source={
              isErr
                ? Images.icClose
                : isSuccess
                ? Images.icCheck
                : Images.icUpload
            }
            style={styles.ic}
          />
        )}
        {isUploading && (
          <ActivityIndicator style={{position: 'absolute'}} color="white" />
        )}
      </AnimatedButtonView>
    </View>
  );
};
const styles = {
  safeArea: {
    flex: 1,
    justifyContent: 'center',
  },
  containerAnimated: {
    width: Metrics.screenWidth,
    backgroundColor: '#f5f5f5',
    height: Metrics.widthRatio(300),
    position: 'absolute',
    bottom: 0,
    paddingVertical: Metrics.baseMargin,
    ...AppStyles.lightShadow,
  },
  title: {
    ...AppStyles.gbSb(18, Colors.primary.dark),
    paddingLeft: Metrics.baseMargin,
  },

  contianerUploader: {
    ...AppStyles.centerAligned,
    width: Metrics.screenWidth,
  },
  btn: {
    ...AppStyles.roundImg(64),
    ...AppStyles.centerAligned,
    marginBottom: Metrics.doubleBaseMargin,
  },
  ic: {
    width: Metrics.widthRatio(30),
    height: Metrics.widthRatio(30),
    resizeMode: 'contain',
    tintColor: 'white',
  },
};
