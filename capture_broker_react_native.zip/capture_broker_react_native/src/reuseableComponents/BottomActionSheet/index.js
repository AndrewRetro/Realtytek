import React from 'react';
import {SafeAreaView} from 'react-native';
import PropTypes from 'prop-types';
import {ActionSheetCustom as ActionSheet} from 'react-native-actionsheet';
import defaultStyles from './DefaultStyles';

export default class BottomActionSheet extends React.PureComponent {
  static propTypes = {
    title: PropTypes.string,
    message: PropTypes.string,
    options: PropTypes.array,
    cbOnPressActionSheet: PropTypes.func,
  };

  static defaultProps = {
    cancelButtonIndex: 0,
    destructiveButtonIndex: 0,
    title: '',
    message: '',
    options: ['Cancel', 'Choose'],
    cbOnPressActionSheet: () => {},
  };

  showActionSheet = () => {
    this.ActionSheet.show();
  };

  handlePress = index => {
    const {cbOnPressActionSheet, options} = this.props;
    cbOnPressActionSheet(index, options);
  };

  render() {
    const {cancelButtonIndex, destructiveButtonIndex, title, message, options} =
      this.props;

    return (
      <SafeAreaView
      // style={{flex: 1}}
      >
        <ActionSheet
          ref={rf => {
            this.ActionSheet = rf;
          }}
          title={title}
          message={message}
          options={options}
          cancelButtonIndex={cancelButtonIndex}
          destructiveButtonIndex={destructiveButtonIndex}
          onPress={this.handlePress}
          styles={defaultStyles(false)}
          tintColor={'#000'}
        />
      </SafeAreaView>
    );
  }
}
