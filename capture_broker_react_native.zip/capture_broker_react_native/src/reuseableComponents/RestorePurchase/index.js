import React, {useEffect, useRef} from 'react';

import {BigBtn} from '@components';
import {useSubscriptionValidation} from '@hooks';
import {Metrics} from '@theme';

const RestorePurchase = () => {
  const exportedRestorePurchase = useRef(null);

  useEffect(() => {
    useSubscriptionValidation(restorePurchase => {
      exportedRestorePurchase.current = {restorePurchase};
    });
  }, []);

  return null;
};

export default RestorePurchase;
