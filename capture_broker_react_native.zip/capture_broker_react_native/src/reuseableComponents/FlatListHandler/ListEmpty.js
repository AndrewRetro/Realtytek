import React from 'react';
import {View, Text} from 'react-native';
import LottieView from 'lottie-react-native';
import {Metrics} from '@theme';

const ListEmpty = () => (
  <View style={styles.container}>
    <View style={styles.containerIcon}>
      <LottieView autoPlay loop source={require('./lottie_empty.json')} />
    </View>
    <Text style={styles.description}>No data found</Text>
  </View>
);

const styles = {
  containerIcon: {
    width: Metrics.widthRatio(120),
    height: Metrics.widthRatio(120),
  },
  icon: {width: 120, height: 120, resizeMode: 'contain', tintColor: '#A2A9B7'},
  container: {
    padding: 64,
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  description: {marginTop: 8, fontSize: 19, color: '#A2A9B7'},
};

export default ListEmpty;
