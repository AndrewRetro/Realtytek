//
//  index.js:
//  BoilerPlate
//
//  Created by Retrocube on 10/4/2019, 9:27:23 AM.
//  Copyright © 2019 Retrocube. All rights reserved.
//
import React, {Component} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Image,
  ActivityIndicator,
} from 'react-native';
import PropTypes from 'prop-types';
import {AppStyles, Colors, Fonts, Metrics} from '../../theme';
import ButtonView from '../ButtonView';

export default class MaterialTextField extends Component {
  static propTypes = {
    label: PropTypes.string,
    error: PropTypes.string,
    isEmpty: PropTypes.bool,
    onFocus: PropTypes.func,
    rightIcon: PropTypes.any,
    outlined: PropTypes.bool,
    useBigSpace: PropTypes.bool,
    rightText: PropTypes.string,
    onRightPress: PropTypes.func,
    activeColor: PropTypes.string,
    inactiveColor: PropTypes.string,
    returnKeyType: PropTypes.string,
    onSubmitEditing: PropTypes.func,
    activeTextColor: PropTypes.string,
    labelBackgroundColor: PropTypes.string,
    style: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    textInputStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
    isShowLoader: PropTypes.bool,
    autoFocus: PropTypes.bool,
    isPriceInput: PropTypes.bool,
    onChangeText: PropTypes.func,
  };

  static defaultProps = {
    value: '',
    label: '',
    style: {},
    rightText: '',
    error: 'Error',
    rightIcon: null,
    outlined: false,
    onFocus: () => {},
    textInputStyle: {},
    useBigSpace: false,
    activeColor: '#000',
    inactiveColor: '#aaa',
    onRightPress: () => {},
    returnKeyType: 'default',
    onSubmitEditing: () => {},
    labelBackgroundColor: '#fff',
    activeTextColor: Colors.primary.darkslateblue,
    isShowLoader: false,
    autoFocus: false,
    isPriceInput: false,
    onChangeText: null,
  };

  constructor(props, context) {
    super(props, context);
    this.state = {
      isFocused: false,
      error: props.error || '',
      val: props.value ? props.value : '',
      maxHeight: 0,
      minHeight: 52,
      expanded: false,
      isError: props.isError,
    };
  }

  txtInputStyle = {
    minHeight: 52,
    height: this.props.multiline ? (this.props.useBigSpace ? 150 : 84) : 52,
    color: '#000',
    paddingLeft: 15,
    paddingTop: 5,
    paddingBottom: 5,
    paddingRight: 15,
    alignSelf: 'stretch',
    flex: 1,
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkslateblue,
    }),
  };

  componentDidMount() {
    if (this.props.onRef != null) {
      this.props.onRef(this.validate);
    }
  }

  handleFocus = () => {
    this.setState({isFocused: true});
    this.props.onFocus();
  };

  handleBlur = () => {
    this.setState({isFocused: false});
    this.props.onBlur && this.props.onBlur();
  };

  setError = (isError, error = this.state.error) => {
    this.setState({error, isError});
  };

  setText = value => {
    this.setState({val: value});
  };

  getValue = () => this.state.val;

  focus = () => {
    this.textInput.focus();
  };

  setFocus = () => {
    this.focus();
  };

  onChangeText = text => {
    this.props.isPriceInput
      ? this.onChangePrice(text)
      : this.setState({val: text, isError: false});
    this.props.onChangeText && this.props.onChangeText(text);
  };

  onChangePrice = text => {
    if (text[0] !== ' ' && text[0] !== '0') {
      this.setState({val: text.trim(), isError: false});
    }
  };

  renderRightIcon = () => {
    const {rightIcon, isShowLoader} = this.props;

    if (rightIcon || isShowLoader)
      return (
        <ButtonView
          style={{
            width: 20,
            alignItems: 'center',
            justifyContent: 'center',
            marginRight: Metrics.baseMargin,
          }}
          onPress={this.props.onRightPress}>
          {isShowLoader ? (
            <ActivityIndicator size="small" />
          ) : (
            <Image
              style={{
                width: Metrics.widthRatio(25),
                height: Metrics.widthRatio(25),
              }}
              source={this.props.rightIcon}
            />
          )}
        </ButtonView>
      );
  };

  render() {
    return (
      <View style={[{marginTop: 25}, this.props.style]}>
        {this.props.label ? (
          <Text style={styles.labelTxt}>{this.props.label}</Text>
        ) : null}
        <View
          style={
            this.state.isFocused
              ? styles.containerActive
              : this.props.label
              ? styles.simpleContainer
              : styles.container
          }>
          {this.props.leftIcon && (
            <View
              style={{
                alignItems: 'center',
                justifyContent: 'center',
                marginLeft: Metrics.baseMargin,
              }}>
              <Image style={styles.icLeft} source={this.props.leftIcon} />
            </View>
          )}
          <TextInput
            ref={ref => (this.textInput = ref)}
            style={[
              this.txtInputStyle,
              this.props.textInputStyle,
              {color: this.props.activeTextColor},
            ]}
            autoCorrect={false}
            blurOnSubmit={this.props.blurOnSubmit}
            value={this.state.val}
            onBlur={this.handleBlur}
            onFocus={this.handleFocus}
            placeholder={this.props.placeholder}
            editable={this.props.editable}
            maxLength={this.props.maxLength}
            keyboardType={this.props.keyboardType}
            multiline={this.props.multiline && true}
            returnKeyType={this.props.returnKeyType}
            selectionColor={this.props.selectionColor}
            onSubmitEditing={this.props.onSubmitEditing}
            secureTextEntry={this.props.secureTextEntry}
            onChangeText={this.onChangeText}
            autoCapitalize="none"
            autoFocus={this.props.autoFocus}
            placeholderTextColor={Colors.primary.lightgreyblue}
            textContentType="oneTimeCode"
          />
          {this.renderRightIcon()}
        </View>
        {this.state.isError && (
          <Text style={styles.errorStyle}>{this.state.error}</Text>
        )}
      </View>
    );
  }

  componentDidUpdate(prevProps) {
    if (this.props.value !== prevProps.value) {
      this.setState({val: this.props.value});
    }
    if (this.props.isError !== prevProps.isError) {
      this.setState({isError: this.props.isError});
    }
  }
}
const styles = StyleSheet.create({
  iconStyle: {
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 15,
  },
  errorStyle: {
    marginTop: 5,
    ...AppStyles.gbRe(10, Colors.primary.vermillion),
  },
  container: {
    borderRadius: 5,
    flexDirection: 'row',
    backgroundColor: `${Colors.primary.bluegrey}0D`,
    borderWidth: 1,
    borderColor: `${Colors.primary.bluegrey}0D`,
  },
  simpleContainer: {
    borderRadius: 5,
    flexDirection: 'row',
    backgroundColor: Colors.primary.white,
  },
  containerActive: {
    borderRadius: 5,
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: Colors.primary.brightlightblue,
    backgroundColor: `${Colors.primary.brightlightblue}26`,
  },
  labelTxt: {
    ...Fonts.font({
      size: 14,
      color: Colors.primary.darkTwo,
    }),
    marginBottom: Metrics.smallMargin,
  },
  icLeft: {
    width: Metrics.widthRatio(20),
    height: Metrics.widthRatio(20),
    resizeMode: 'contain',
  },
});
