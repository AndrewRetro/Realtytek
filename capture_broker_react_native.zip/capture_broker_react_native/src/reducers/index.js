//
//  index.js:
//  BoilerPlate
//
//  Created by Retrocube on 10/4/2019, 9:21:40 AM.
//  Copyright © 2019 Retrocube. All rights reserved.
//
import {combineReducers} from 'redux';
import serviceReducer from './serviceReducer';
import {
  USER,
  LOGOUT,
  LEADS,
  SEARCH,
  PROPERTIES,
  MY_PROPERTIES,
  BUYERS,
  RECOMENDED_HOMES,
  APPOINTMENTS_CONFIRMED,
  APPOINTMENTS_PENDING,
  APPOINTMENTS_REJECTED,
  TOURED_HOMES,
  UNDER_CONTRACT,
  NOTIFICATIONS,
} from '../actions/ActionTypes';
import badgeCount from './badgeCount';

const appReducer = combineReducers({
  user: serviceReducer(USER),
  leads: serviceReducer(LEADS),
  search: serviceReducer(SEARCH),
  properties: serviceReducer(PROPERTIES),
  myProperties: serviceReducer(MY_PROPERTIES),
  buyers: serviceReducer(BUYERS),
  recommendedHomes: serviceReducer(RECOMENDED_HOMES),
  touredHomes: serviceReducer(TOURED_HOMES),
  appointmentsConfirmed: serviceReducer(APPOINTMENTS_CONFIRMED),
  appointmentsPending: serviceReducer(APPOINTMENTS_PENDING),
  appointmentsRejected: serviceReducer(APPOINTMENTS_REJECTED),
  underContract: serviceReducer(UNDER_CONTRACT),
  notifications: serviceReducer(NOTIFICATIONS),
  badgeCount,
});

const rootReducer = (state, action) => {
  if (action.type === LOGOUT) {
    let newState = {};
    for (let key of Object.keys(state)) {
      newState[key] = {
        ...state[key],
        data: [],
        meta: {current_page: 0, last_page: 0},
      };
    }
    state = {
      ...newState,
    };
  }
  return appReducer(state, action);
};

export default rootReducer;
